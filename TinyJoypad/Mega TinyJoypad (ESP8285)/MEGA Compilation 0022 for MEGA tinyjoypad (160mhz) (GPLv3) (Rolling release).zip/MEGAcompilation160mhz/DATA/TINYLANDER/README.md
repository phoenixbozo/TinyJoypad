# TinyLanderV1.0
Tiny Lander like Lunar Lander for ATTiny85 at 16MHz
I am a big fan of the tiny joypad platform.
This is my first game for the ATTiny85... it was a lot of fun to develop it..
based on the many templates (examples) provided by the platform:
https://www.tinyjoypad.com/tiny-joypad-shematic
Big thanks to all of them! :)
