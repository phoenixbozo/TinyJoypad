//      >>>>>  T-I-N-Y  S-I-M-O-N for ATTINY10  GPL v3 <<<<
//                  Programmer: Daniel C 2018
//             Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                     https://www.tinyjoypad.com

//  Tiny SIMON is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>

#include <avr/pgmspace.h>

#define INPUT 0
#define OUTPUT 1
#define HIGH 1
#define LOW 0
#define A0 4
#define A1 5
#define A2 6
#define A3 7


const uint8_t Chaine [] PROGMEM = {\
0,1,0,2,1,0,0,3,3,2,0,1,0,2,3,1,0,3,2,1,\
3,2,1,2,1,3,0,2,0,3,1,2,0,2,3,0,1,2,3,2,\
3,2,3,1,1,2,1,0,2,0,1,2,1,1,3,0,2,3,2,2,\
2,1,0,1,2,0,3,2,1,0,2,3,2,1,0,2,3,3,2,0,\
1,1,2,1,3,3,2,0,0,1,0,2,0,1,3,2,3,0,0,1,\
3,2,0,1,2,0,1,2,3,1,0,2,0,3,0,2,3,2,1,2,\
2,1,0,3,0,2,3,2,3,1,2,2,0,0,2,1,0,2,0,1,\
1,2,0,2,1,0,1,1,0,3,2,0,2,2,2,2,0,3,1,2,\
3,2,2,3,1,3,3,3,0,2,1,0,1,1,2,3,0,2,0,1};


void delay (uint8_t millis) {
for (volatile uint16_t i = 34*millis; i>0; i--);
}

uint8_t analogRead(void){
ADCSRA = ADCSRA | 1<<ADSC; // Start
while (ADCSRA & 1<<ADSC); // Wait while conversion in progress
return ADCL; // Copy result to temp
}


