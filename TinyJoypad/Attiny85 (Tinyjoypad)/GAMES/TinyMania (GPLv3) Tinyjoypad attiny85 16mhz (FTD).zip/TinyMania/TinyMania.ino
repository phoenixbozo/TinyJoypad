//       >>>>>  T-I-N-Y  M-A-N-I-A for ATTINY85 GPL v3 <<<<<
//                    Programmer: Daniel C 2026
//             Contact EMAIL: electro_l.i.b@tinyjoypad.com
//  https://github.com/phoenixbozo/TinyJoypad/tree/main/TinyJoypad
//                    https://WWW.TINYJOYPAD.COM
//          https://sites.google.com/view/arduino-collection

//  Tiny-Mania is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

//for TINY JOYPAD rev2 (attiny85)
//the code work at 16MHZ internal
//Program the chip with an arduino uno in "Arduino as ISP" mode.
//Use TinyCore -> https://raw.githubusercontent.com/damellis/attiny/ide-1.6.x-boards-manager/package_damellis_attiny_index.json


#include "ELECTROLIB.h"
#include "FastTinyDriver.h"

const uint8_t LEVEL_ [21][15] PROGMEM = {
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
    {0,0,1,1,1,1,1,1,1,1,1,1,1,0,0 },
    {0,0,1,0,0,1,0,1,0,1,0,0,1,0,0 },
    {0,0,2,0,0,1,0,1,0,1,0,0,2,0,0 },
    {0,0,1,0,0,1,1,1,1,1,0,0,1,0,0 },
    {0,0,1,1,1,1,0,4,0,1,1,1,1,0,0 },
    {0,0,0,1,0,1,0,3,0,1,0,1,0,0,0 },
    {0,0,0,1,0,1,0,0,0,1,0,1,0,0,0 },
    {0,0,1,1,1,1,1,1,1,1,1,1,1,0,0 },
    {0,0,1,0,0,1,0,1,0,1,0,0,1,0,0 },
    {0,0,1,0,1,1,0,1,0,1,1,0,1,0,0 },
    {0,0,1,0,1,0,0,1,0,0,1,0,1,0,0 },
    {0,0,1,1,1,1,1,3,1,1,1,1,1,0,0 },
    {0,0,1,0,0,1,0,1,0,1,0,0,1,0,0 },
    {0,0,1,0,0,1,0,1,0,1,0,0,1,0,0 },
    {0,0,2,0,0,1,0,1,0,1,0,0,2,0,0 },
    {0,0,1,0,0,1,1,1,1,1,0,0,1,0,0 },
    {0,0,1,1,1,1,0,0,0,1,1,1,1,0,0 },
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 }
};

//INTRO
const uint8_t  Vertical2 [] PROGMEM= {
1,8,0xff
};

const uint8_t  Horizon2 [] PROGMEM= {
1,8,0x01,
};

const uint8_t  Start2 [] PROGMEM= {
19,8,
0x17,0x15,0x1D,0x00,0x01,0x1F,0x01,0x00,0x1F,0x05,0x1F,0x00,0x1F,0x05,0x1B,0x00,0x01,0x1F,0x01,
};

const uint8_t  TinyMania2 [] PROGMEM= {
43,8,
0x03,0x03,0xFF,0x03,0x03,0xF4,0x00,0xF8,0x0C,0x04,0xFC,0x00,0x0F,0x1A,0xDC,0xDC,0x1E,0x0F,0x00,0xFF,
0x0F,0x3C,0x70,0x3C,0x0F,0xFF,0x00,0xF4,0x94,0xDC,0xFC,0x00,0xF8,0x0C,0x04,0xFC,0x00,0xF4,0x00,0xF4,
0x94,0xDC,0xFC,
};

const uint8_t  PIX [] PROGMEM= {1,1,0b00000001,};

const uint8_t animFruits[] PROGMEM={0, 1, 2, 3, 3, 2, 1, 0};

const uint8_t  Fruits [] PROGMEM= {
7,8,
0x00,0x20,0x30,0x08,0x2C,0x32,0x00,//white image 1
0x20,0x50,0x48,0x74,0x52,0x4D,0x32,//mask image 1

0x00,0x20,0x70,0x7C,0x54,0x20,0x00,//white image 2
0x20,0x50,0x8C,0x82,0xAA,0x56,0x20,//mask image 2

0x00,0x40,0x40,0x70,0x58,0x3C,0x00,
0xC0,0xA0,0xB0,0x88,0xA4,0x42,0x3E,

0x00,0x38,0x50,0x26,0x52,0x38,0x00,
0x38,0x44,0xAE,0xD9,0xAD,0x46,0x38,

0x00,0x38,0x7C,0x74,0x64,0x38,0x00,
0x7C,0xC6,0x82,0x8A,0x9A,0xC6,0x7C,

0x00,0x38,0x44,0x44,0x4C,0x38,0x00,
0x7C,0xC6,0xBA,0xBA,0xB2,0xC6,0x7C,
};

const uint8_t  BLOCK1 [] PROGMEM = {
9,7,
0x78,0x5E,0x6B,0x59,0x69,0x59,0x7D,0x1F,0x07,

0x00,0x20,0x14,0x26,0x16,0x26,0x02,0x00,0x00,
};

const uint8_t  BLOCK2 [] PROGMEM= {
9,7,
0x78,0x64,0x62,0x61,0x67,0x7E,0x3C,0x0C,0x00,

0x00,0x18,0x1C,0x1E,0x18,0x01,0x42,0x72,0x1C,
};

const uint8_t *Blocks [2] = {BLOCK1,BLOCK2};

const uint8_t  DOT [] PROGMEM= {
9,7,
0x00,0x00,0x00,0x00,0x08,0x00,0x00,0x00,0x00,

0x00,0x00,0x00,0x08,0x14,0x08,0x00,0x00,0x00,
};

const uint8_t  BIGDOT [] PROGMEM= {
9,7,
0x00,0x00,0x00,0x08,0x1C,0x08,0x00,0x00,0x00,

0x00,0x00,0x08,0x14,0x22,0x14,0x08,0x00,0x00,
};

const uint8_t Jump[] PROGMEM= { //jump anim seq
  0, 2,  4,  
  7,  8,  8, 
   9,  9,  
  9,  9, 
  9,9,9,9, 
   8,  8,  
  6,  5,  3, 
   2, 1, 
  0, 1, 0
};

const uint8_t  PAC [] PROGMEM= {
7,8,
0x00,0x1C,0x3E,0x2E,0x2A,0x0C,0x00,
0x1C,0x22,0x41,0x51,0x55,0x32,0x1C,

0x00,0x1C,0x3E,0x2E,0x2A,0x04,0x00,
0x1C,0x22,0x41,0x51,0x55,0x2A,0x04,

0x00,0x1C,0x3E,0x26,0x02,0x00,0x00,
0x1C,0x22,0x41,0x59,0x75,0x22,0x00,

0x00,0x1C,0x2A,0x2E,0x3A,0x1C,0x00,
0x1C,0x22,0x55,0x51,0x45,0x22,0x1C,

0x00,0x0C,0x2A,0x2E,0x2A,0x1C,0x00,
0x1C,0x32,0x55,0x51,0x55,0x22,0x1C,

0x00,0x0C,0x0A,0x0E,0x2A,0x1C,0x00,
0x1C,0x32,0x75,0x71,0x55,0x22,0x1C,

0x00,0x0C,0x2A,0x2E,0x3E,0x1C,0x00,
0x1C,0x32,0x55,0x51,0x41,0x22,0x1C,

0x00,0x04,0x2A,0x2E,0x3E,0x1C,0x00,
0x04,0x2A,0x55,0x51,0x41,0x22,0x1C,

0x00,0x00,0x02,0x26,0x3E,0x1C,0x00,
0x00,0x22,0x75,0x59,0x41,0x22,0x1C,

0x00,0x1C,0x3E,0x3E,0x3A,0x1C,0x00,
0x1C,0x22,0x41,0x41,0x45,0x22,0x1C,

0x00,0x1C,0x3E,0x3E,0x3A,0x0C,0x00,
0x1C,0x22,0x41,0x41,0x45,0x32,0x1C,

0x00,0x1C,0x3E,0x3E,0x3A,0x04,0x00,
0x1C,0x22,0x41,0x41,0x45,0x3A,0x1C,
};

const uint8_t  GHOST [] PROGMEM= {
7,8,
0x00,0x3C,0x1E,0x3E,0x3A,0x1C,0x00,
0x3C,0x42,0x21,0x41,0x45,0x22,0x7C,

0x00,0x1C,0x3E,0x1E,0x3A,0x3C,0x00,
0x7C,0x22,0x41,0x21,0x45,0x42,0x3C,

0x00,0x3C,0x1E,0x3E,0x1A,0x3C,0x00,
0x3C,0x42,0x21,0x41,0x25,0x42,0x7C,

0x00,0x3C,0x1A,0x3E,0x3A,0x1C,0x00,
0x3C,0x42,0x25,0x41,0x45,0x22,0x7C,

0x00,0x1C,0x3A,0x1E,0x3A,0x3C,0x00,
0x7C,0x22,0x45,0x21,0x45,0x42,0x3C,

0x00,0x3C,0x1A,0x3E,0x1A,0x3C,0x00,
0x3C,0x42,0x25,0x41,0x25,0x42,0x7C,

0x00,0x3C,0x1A,0x3E,0x3E,0x1C,0x00,
0x3C,0x42,0x25,0x41,0x41,0x22,0x7C,

0x00,0x1C,0x3A,0x1E,0x3E,0x3C,0x00,
0x7C,0x22,0x45,0x21,0x41,0x42,0x3C,

0x00,0x3C,0x1A,0x3E,0x1E,0x3C,0x00,
0x3C,0x42,0x25,0x41,0x21,0x42,0x7C,

0x00,0x3C,0x1E,0x3E,0x3E,0x1C,0x00,
0x3C,0x42,0x21,0x41,0x41,0x22,0x7C,

0x00,0x1C,0x3E,0x1E,0x3E,0x3C,0x00,
0x7C,0x22,0x41,0x21,0x41,0x42,0x3C,

0x00,0x3C,0x1E,0x3E,0x1E,0x3C,0x00,
0x3C,0x42,0x21,0x41,0x21,0x42,0x7C,
};

const uint8_t  GhostsGobTime [] PROGMEM= {
7,8,
0x3C,0x42,0x21,0x41,0x45,0x22,0x7C,
0x00,0x3C,0x1E,0x3E,0x3A,0x1C,0x00,

0x7C,0x22,0x41,0x21,0x45,0x42,0x3C,
0x00,0x1C,0x3E,0x1E,0x3A,0x3C,0x00,

0x3C,0x42,0x21,0x41,0x25,0x42,0x7C,
0x00,0x3C,0x1E,0x3E,0x1A,0x3C,0x00,

0x3C,0x42,0x25,0x41,0x45,0x22,0x7C,
0x00,0x3C,0x1A,0x3E,0x3A,0x1C,0x00,

0x7C,0x22,0x45,0x21,0x45,0x42,0x3C,
0x00,0x1C,0x3A,0x1E,0x3A,0x3C,0x00,

0x3C,0x42,0x25,0x41,0x25,0x42,0x7C,
0x00,0x3C,0x1A,0x3E,0x1A,0x3C,0x00,

0x3C,0x42,0x25,0x41,0x41,0x22,0x7C,
0x00,0x3C,0x1A,0x3E,0x3E,0x1C,0x00,

0x7C,0x22,0x45,0x21,0x41,0x42,0x3C,
0x00,0x1C,0x3A,0x1E,0x3E,0x3C,0x00,

0x3C,0x42,0x25,0x41,0x21,0x42,0x7C,
0x00,0x3C,0x1A,0x3E,0x1E,0x3C,0x00,

0x3C,0x42,0x21,0x41,0x41,0x22,0x7C,
0x00,0x3C,0x1E,0x3E,0x3E,0x1C,0x00,

0x7C,0x22,0x41,0x21,0x41,0x42,0x3C,
0x00,0x1C,0x3E,0x1E,0x3E,0x3C,0x00,

0x3C,0x42,0x21,0x41,0x21,0x42,0x7C,
0x00,0x3C,0x1E,0x3E,0x1E,0x3C,0x00,
};

const uint8_t  GhostsGobbed [] PROGMEM= {
7,8,
0x00,0x00,0x00,0x00,0x04,0x00,0x00,
0x00,0x00,0x00,0x04,0x0A,0x04,0x00,

0x00,0x00,0x00,0x00,0x04,0x00,0x00,
0x00,0x00,0x00,0x04,0x0A,0x04,0x00,

0x00,0x00,0x00,0x00,0x04,0x00,0x00,
0x00,0x00,0x00,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x00,0x00,0x00,
0x00,0x04,0x0A,0x04,0x00,0x00,0x00,

0x00,0x00,0x04,0x00,0x00,0x00,0x00,
0x00,0x04,0x0A,0x04,0x00,0x00,0x00,

0x00,0x00,0x04,0x00,0x00,0x00,0x00,
0x00,0x04,0x0A,0x04,0x00,0x00,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,

0x00,0x00,0x04,0x00,0x04,0x00,0x00,
0x00,0x04,0x0A,0x04,0x0A,0x04,0x00,
};

const uint8_t  police [] PROGMEM= {//number 0 - 9
//  4,8, 
0x00,0x7C,0x44,0x7C,
0x00,0x00,0x00,0x7C,
0x00,0x74,0x54,0x5C,
0x00,0x44,0x54,0x7C,
0x00,0x1C,0x10,0x7C,
0x00,0x5C,0x54,0x74,
0x00,0x7C,0x54,0x74,
0x00,0x04,0x04,0x7C,
0x00,0x7C,0x54,0x7C,
0x00,0x5C,0x54,0x7C,
};

const uint8_t FD[] PROGMEM ={
0b00000000,
0b00010000,
0b00011000,
0b00111000,
0b00111100,
0b01111100,
0b01111110,
0b11111110,
0b11111111,
};

const uint8_t  MiniPac [] PROGMEM= {
0x3C,0x7E,0x66,0x42,0x00,0x00
};

const uint8_t DeadSong[] PROGMEM = {
  54, 102,  255,  0,  255,  90,  255,  0,  255,  80,  255,  0,  255,  72,  50,  62,  50,  72,  50,
  62,  50,  72,  50,  62,  50,  72,  50,  62,  50,  72,  50,  62,  50,  72,  50,  62,  50,  72, 50,
  62,  50,  72,  50,  62,  50,  72,  50, 62,  50,  72,  50,  62,  50,  72,  50,
};

const uint8_t * GhostPic[3]={GHOST,GhostsGobTime,GhostsGobbed};

#define NbLvl 7

//Level Dimention
#define LEVELW 15
#define LEVELH 21
#define LEVELW_1 14
#define LEVELH_1 20

//Bonus Position
#define BnsPosX 7
#define BnsPosY 9

//Ghosts Respawn spot
#define RespawnX 7
#define RespawnY 6

//Pac Position
#define PacPosX 7
#define PacPosY 13

//Total Dots in LVL
#define Total_Dots 112

#define NUM_GHOST 7
#define JUMPINGGHOST 4

#define DriftX 7
#define DriftY 4

#define UP_    0
#define RIGHT_ 1
#define DOWN_  2
#define LEFT_  3

//PUBLIC VAR

uint8_t Digits[5];

bool Blink=0;
uint8_t INGAME;
uint8_t GobModeTimer=0;
uint8_t JmpSeq=0;
uint8_t JmpTrig=2;
uint8_t JmpPos=0;

uint8_t VBuffer[4][64] = {0};
int8_t CamX=0,CamY=0;
uint8_t FRM=2;
uint8_t DIR=0;

uint8_t RDC=0;

const uint8_t Rnd_Array[] PROGMEM={0,2,1,3,3,2,1,0,3,2,0,1,1,3,2,2,};
/*
unsigned long currentMillis=0;
unsigned long MemMillis=0;
#define FPS_Limiter(TIME_BY_FRAME) while((currentMillis-MemMillis)<TIME_BY_FRAME){currentMillis=millis();}MemMillis=currentMillis
*/
typedef struct {
uint8_t TotalDotsCollected;
uint8_t PacLives;
uint8_t NbGhosts;
uint8_t GobDotTimer;
uint8_t Lvl;
uint8_t BLKs;
uint8_t GhostSpeed;
uint8_t PacSpeedTimer;
} GPlayVar;

typedef struct {
uint8_t Type;
uint8_t Speed;
uint8_t SkipMode;
uint8_t active;
uint8_t health;
int8_t DecalageX, DecalageY;
int8_t GridX, GridY;
int8_t Xdir;
int8_t Ydir;
} SPRITES;

typedef struct {
uint8_t Left;
uint8_t Right;
uint8_t Up;
uint8_t Down;
} CTRL_;

typedef struct {
const uint8_t posX=BnsPosX;
const uint8_t posY=BnsPosY;
uint8_t Delivery;
uint8_t Timer;
uint8_t Anim;
uint8_t BonusOrder;
uint8_t Fruit;
} BNS;

typedef struct {
uint8_t Active;
uint8_t Frame;
uint8_t IngameTrigger;
} Transition;

SPRITES MainSprite;
SPRITES Ghosts[NUM_GHOST];

CTRL_ Ctrl;

BNS Bonus;

GPlayVar GP;

Transition Fade;

void BonusDelivery(void) {
  Bonus.Delivery = (Bonus.BonusOrder) ? (RD_4() > 1) ? 5 : 6 : (Bonus.Fruit + 1);
  Bonus.Timer = 255;
  Bonus.BonusOrder = !Bonus.BonusOrder;
}

void setup() {
  TINYJOYPAD_INIT();
  TinyOLED_init();
  InitNewGame();
  Fade.Active = 2;
  Fade.Frame = 0;
  Fade.IngameTrigger = false;
  INGAME = false;
  Fade2White(0);
}

void CopyDotInTab(void) {
  for (uint8_t y_ = 0; y_ < LEVELH; y_++) {
    for (uint8_t x_ = 0; x_ < LEVELW; x_++) {
      if ((GetLevelCell(x_, y_)) && (GetLevelCell(x_, y_) != 3) && (GetLevelCell(x_, y_) != 4)) {
        WriteBit(x_, y_, 1);
      } else {
        WriteBit(x_, y_, 0);
      }
    }
  }
}

void InitSpk(uint8_t Type_, SPRITES *SPK_) {
  SPK_->Type = Type_;
  SPK_->active = 0;
  SPK_->SkipMode = 0;
  SPK_->health = 0;
  SPK_->DecalageX = 0;
  SPK_->DecalageY = 0;
  SPK_->GridX = PacPosX;
  SPK_->GridY = PacPosY;
  SPK_->Xdir = 0;
  SPK_->Ydir = 0;
}

void AdjGamePlay() {
  GP.BLKs = ((GP.Lvl % 2) != 0);
  GP.GhostSpeed = Mymap(GP.Lvl, 0, NbLvl, 2, 0);
  GP.NbGhosts = Mymap(GP.Lvl, 0, NbLvl, 4, NUM_GHOST);
  GP.GobDotTimer = Mymap(GP.Lvl, 0, NbLvl, 255, 100);
}

void MENU_FADESELECT() {
  switch (Fade.IngameTrigger) {
    case 0: /*intro*/ break;
    case 1:
      InitNewGame();
      _delay_ms(500);
      break;
    case 2: RESTART_LEVEL(); break;
    case 3: NEXT_LEVEL(); break;
    default: break;
  }
}

void Always_Init() {
  GP.GobDotTimer = 0;
  GP.PacSpeedTimer = 0;
  Bonus.Timer = 0;
  Bonus.Delivery = 0;
  JmpSeq = 0;
  JmpTrig = 2;
  JmpPos = 0;
  GobModeTimer = 0;
  FRM = 0;
  resetCtrl();
}

void NEXT_LEVEL() {
  GP.Lvl = (GP.Lvl < NbLvl) ? GP.Lvl + 1 : NbLvl;
  InitNewLevel();
  Bonus.Fruit = (GP.Lvl < 3) ? Bonus.Fruit + 1 : (GP.Lvl - 4);
  _delay_ms(1000);
}

void RESTART_LEVEL() {
  Always_Init();
  AdjGamePlay();
  InitSpk(1, &MainSprite);
  for (uint8_t t = 0; t < GP.NbGhosts; t++) {
    InitSpk(0, &Ghosts[t]);
    Ghosts[t].GridY -= 6;
    Ghosts[t].Speed = GP.GhostSpeed;
  }
  if (GP.PacLives > 0) {
    GP.PacLives--;
  } else {
    Fade2Black(0);
  }
  _delay_ms(800);
}

void InitNewLevel() {
  Always_Init();
  GP.TotalDotsCollected = 0;
  Bonus.BonusOrder = 0;
  AdjGamePlay();
  InitSpk(1, &MainSprite);
  CopyDotInTab();
  for (uint8_t t = 0; t < GP.NbGhosts; t++) {
    InitSpk(0, &Ghosts[t]);
    Ghosts[t].GridY -= 6;
    Ghosts[t].Speed = GP.GhostSpeed;
  }
}

void InitNewGame() {
  GP.PacLives = 3;
  GP.Lvl = 0;
  Bonus.Fruit = 0;
  InitNewLevel();
  reset_Scores();
  _delay_ms(500);
}

#define LVL_WIDTH_BITS LEVELW
#define LVL_HEIGHT LEVELH
#define LVL_SIZE_BYTES ((LVL_WIDTH_BITS * LVL_HEIGHT + 7) / 8)

uint8_t LvLMem[LVL_SIZE_BYTES];

void WriteBit(int x, int y, uint8_t value) {
  if (x < 0 || x >= LVL_WIDTH_BITS || y < 0 || y >= LVL_HEIGHT) {
    return;
  }

  int bit_index = y * LVL_WIDTH_BITS + x;
  int byte_index = bit_index / 8;
  int bit_in_byte = bit_index % 8;

  if (value) {
    LvLMem[byte_index] |= (1 << bit_in_byte);
  } else {
    LvLMem[byte_index] &= ~(1 << bit_in_byte);
  }
}

uint8_t ReadBit(int x, int y) {
  if (x < 0 || x >= LVL_WIDTH_BITS || y < 0 || y >= LVL_HEIGHT) {
    return 0;
  }

  int bit_index = y * LVL_WIDTH_BITS + x;
  int byte_index = bit_index / 8;
  int bit_in_byte = bit_index % 8;

  return (LvLMem[byte_index] >> bit_in_byte) & 1u;
}

void GobEnding() {
  for (uint8_t t = 0; t < GP.NbGhosts; t++) {
    if (Ghosts[t].health == 1) Ghosts[t].health = 0;
  }
}

void GobTimer() {
  if (GobModeTimer != 0) {
    GobModeTimer--;
    if (GobModeTimer == 0) { GobEnding(); }
  }
  Blink = !Blink;
}

void ANIM(void) {
  if (DIR != 0) {
    DIR--;
  } else {
    DIR = 1;
    if (FRM != 2) {
      FRM++;
    } else {
      FRM = 0;
    }
   if (Fade.Active==0) Bonus.Anim = (Bonus.Anim < 7) ? Bonus.Anim + 1 : 0;
    if (Bonus.Timer > 0) {
      Bonus.Timer--;
      if (Bonus.Timer == 0) { Bonus.Delivery = 0; }
    }
  }
}

uint8_t GetLevelCell(int8_t x_, int8_t y_) {
  return pgm_read_byte(&LEVEL_[y_][x_]);
}

void Trim_Xpos(SPRITES *SPK_) {
  SPK_->DecalageX = -SPK_->DecalageY / 2;
}

void Go2Left(SPRITES *SPK_) {
  if (SPK_->DecalageX > -(DriftX - 1)) {
    if (GetLevelCell(SPK_->GridX - 1, SPK_->GridY)) { SPK_->DecalageX--; }
  } else {
    if (GetLevelCell(SPK_->GridX - 1, SPK_->GridY)) {
      SPK_->DecalageX = 0;
      SPK_->GridX--;
    }
  }
}

void Go2Right(SPRITES *SPK_) {
  if (SPK_->DecalageX < 0) {
    SPK_->DecalageX++;
  } else {
    if (GetLevelCell(SPK_->GridX + 1, SPK_->GridY)) {
      SPK_->DecalageX = -(DriftX - 1);
      SPK_->GridX++;
    }
  }
}

void Go2Up(SPRITES *SPK_) {
  if (SPK_->DecalageY > -(DriftY - 1)) {
    if (GetLevelCell(SPK_->GridX, SPK_->GridY - 1)) { SPK_->DecalageY--; }
  } else {
    if (GetLevelCell(SPK_->GridX, SPK_->GridY - 1)) {
      SPK_->DecalageY = 0;
      SPK_->GridY--;
    }
  }
  Trim_Xpos(SPK_);
}

void Go2Down(SPRITES *SPK_) {
  if (SPK_->DecalageY < 0) {
    SPK_->DecalageY++;
  } else {
    if (GetLevelCell(SPK_->GridX, SPK_->GridY + 1)) {
      if (GetLevelCell(SPK_->GridX, SPK_->GridY + 1) == 4 && SPK_->Type == 1) return;
      SPK_->DecalageY = -(DriftY - 1);
      SPK_->GridY++;
    }
  }
  Trim_Xpos(SPK_);
}

uint8_t MainAnim(SPRITES *SPK_) {
  if (SPK_->Xdir == 1) {
    return FRM;
  } else if (SPK_->Xdir == -1) {
    return 6 + FRM;
  } else if (SPK_->Ydir == 1) {
    return 3 + FRM;
  } else if (SPK_->Ydir == -1) {
    return 9 + FRM;
  }
  return 0;
}

void ASA() {  //Auto recentering
  CamX = -5 + MainSprite.GridX;
  CamY = -4 + MainSprite.GridY;
}

uint8_t CheckGrid(uint8_t X_, uint8_t Y_) {
  if (X_ > LEVELW_1) return 0;
  if (Y_ > LEVELH_1) return 0;
  return pgm_read_byte(&LEVEL_[Y_][X_]);
}

uint8_t GobAnim(SPRITES *SPK_) {
  if ((SPK_->health == 2) || (SPK_->health == 0)) return SPK_->health;
  if ((GobModeTimer > 0) && (GobModeTimer < 80)) {
    if (Blink) {
      return SPK_->health;
    } else {
      return 0;
    }
  } else {
    return SPK_->health;
  }
}

void DrawLevel() {
  ASA();
  int8_t ScrX = -MainSprite.DecalageX;
  int8_t ScrY = -MainSprite.DecalageY;
  int8_t offsetX = -4;
  int8_t offsetY = 3;
  for (int8_t y = -2 + CamY; y < 10 + CamY; y++) {
    for (int8_t x = -2 + CamX; x < 12 + CamX; x++) {
      if ((x <= LEVELW_1) && (x >= 0) && (y <= LEVELH - 1) && (y >= 0)) {
        if (CheckGrid(x, y) == 0) {
          drawSprite2Bit(x * DriftX - offsetX - (CamX * DriftX) + ScrX, y * DriftY - (CamY * DriftY) + ScrY - offsetY, Blocks[GP.BLKs], 0, true);
        }
        if (ReadBit(x, y)) {
          switch (GetLevelCell(x, y)) {
            case 1: drawSprite2Bit(x * DriftX - offsetX - (CamX * DriftX) + ScrX, y * DriftY - (CamY * DriftY) + ScrY - offsetY, DOT, 0, true); break;

            case 2: drawSprite2Bit(x * DriftX - offsetX - (CamX * DriftX) + ScrX, y * DriftY - (CamY * DriftY) + ScrY - offsetY, BIGDOT, 0, true); break;
            default: break;
          }
        }

        if ((Bonus.posX == x) && (Bonus.posY == y) && (Bonus.Delivery)) {
          drawSprite2Bit(x * DriftX - offsetX - (CamX * DriftX) + ScrX, y * DriftY - (CamY * DriftY) + ScrY - pgm_read_byte(&animFruits[Bonus.Anim]) - offsetY, Fruits, Bonus.Delivery - 1, true);
        }

        if ((MainSprite.GridX == x) && (MainSprite.GridY == y)) {
          drawSprite2Bit((x * DriftX) - (CamX * DriftX) + 1 - offsetX, (y * DriftY) - (CamY * DriftY) - JmpPos - offsetY, PAC, MainAnim(&MainSprite), true);
        }
        for (uint8_t GC = 0; GC < GP.NbGhosts; GC++) {
          if ((Ghosts[GC].GridX == x) && (Ghosts[GC].GridY == y)) {
            drawSprite2Bit((x * DriftX) - (CamX * DriftX) + 1 - offsetX + ScrX + Ghosts[GC].DecalageX, (y * DriftY) - (CamY * DriftY) + ScrY + Ghosts[GC].DecalageY - offsetY - ((GC == JUMPINGGHOST) ? JmpPos : 0), GhostPic[GobAnim(&Ghosts[GC])], MainAnim(&Ghosts[GC]), true);
          }
        }
      }
    }
    offsetX += 2;
  }
  if (Bonus.Delivery) {
    drawSprite2Bit(57, -1, Fruits, Bonus.Delivery - 1, true);
  }
}

uint8_t NeutralPosition(SPRITES *SPK_) {
  if (SPK_->DecalageX == 0 && SPK_->DecalageY == 0) return 1;
  return 0;
}

uint8_t Move_Ok(uint8_t Dir_, SPRITES *SPK_) {
  uint8_t x = SPK_->GridX;
  uint8_t y = SPK_->GridY;
  uint8_t cell;

  switch (Dir_) {
    case UP_:
      cell = pgm_read_byte(&LEVEL_[y - 1][x]);
      return cell != 0;

    case RIGHT_:
      cell = pgm_read_byte(&LEVEL_[y][x + 1]);
      return cell != 0;

    case DOWN_:
      cell = pgm_read_byte(&LEVEL_[y + 1][x]);
      return (cell != 0) && !((cell == 4) && (SPK_->Type == 1));

    case LEFT_:
      cell = pgm_read_byte(&LEVEL_[y][x - 1]);
      return cell != 0;

    default:
      return 0;
  }
}

void ReverseGhosts(SPRITES *SPK_) {
  SPK_->Xdir = -SPK_->Xdir;
  SPK_->Ydir = -SPK_->Ydir;
}

void PLAY_MUSIC(const uint8_t *Music_) {
  uint8_t t, to_ = pgm_read_byte(&Music_[0]);
  for (t = 1; t < to_; t = t + 2) {
    Sound(pgm_read_byte(&Music_[t]), pgm_read_byte(&Music_[t + 1]));
  }
}

void SoundSystem(uint8_t Val_) {
  switch (Val_) {
    case 1:  //gub sound
      for (uint8_t Sn1 = 1; Sn1 < 125; Sn1 += 4) {
        Sound(Sn1, 3);
        _delay_ms(1);
        Sound(Sn1 + 125, 2);
      }
      break;
    case 2:  //petit dot
      Sound(40, 4);
      Sound(200, 4);
      break;
    case 3:  //big dot
      Sound(10, 12);
      Sound(250, 12);
      Sound(100, 12);
      Sound(10, 12);
      break;
    case 4:
      SoundSystem(1);
      _delay_ms(1000);
      PLAY_MUSIC(DeadSong);
      break;  //dead anim sound
    case 5:
      for (uint8_t q = 1; q < 30; q++) {
        Sound(20, 35);
        Sound(200, 45);
      }
      break;  //Next Level
    default: break;
  }
}

void ActivateGobTimer() {
  GobModeTimer = GP.GobDotTimer;
  for (uint8_t t = 0; t < GP.NbGhosts; t++) {
    if (Ghosts[t].health == 0) {
      Ghosts[t].health = 1;
      ReverseGhosts(&Ghosts[t]);
    }
  }
}

void BonusCollected() {
  Bonus.Delivery = 0;
  Bonus.Timer = 0;
  Bonus.Anim = 0;
}

void BonusPickup() {
  switch (Bonus.Delivery) {
    case 1:
    case 2:
    case 3:
    case 4:
      Scores(255);
      BonusCollected();
      SoundSystem(1);
      break;
    case 5:
      Scores(255);
      ActivateGobTimer();
      BonusCollected();
      SoundSystem(3);
      break;
    case 6:
      Scores(255);
      GP.PacSpeedTimer = 255;
      BonusCollected();
      SoundSystem(3);
      break;
    default: break;
  }
}

void CheckCollectible(void) {
  if (JmpPos > 2) return;
  if (ReadBit(MainSprite.GridX, MainSprite.GridY) == 1) {
    if (GetLevelCell(MainSprite.GridX, MainSprite.GridY) == 2) {
      ActivateGobTimer();
      SoundSystem(3);
      Scores(30);
    } else {
      SoundSystem(2);
      Scores(15);
    }
    GP.TotalDotsCollected++;
    if (GP.TotalDotsCollected == Total_Dots) {
      _delay_ms(500);
      SoundSystem(5);
      _delay_ms(500);
      Fade2Black(3);
    }
    WriteBit(MainSprite.GridX, MainSprite.GridY, 0);
  }
  if ((MainSprite.GridX == BnsPosX) && (MainSprite.GridY == BnsPosY) && (Bonus.Delivery)) { BonusPickup(); }
}

uint8_t CheckDirection(SPRITES *SPK_) {
  switch (SPK_->Xdir) {
    case 1:
      return LEFT_;
    case -1:
      return RIGHT_;
    default:
      switch (SPK_->Ydir) {
        case 1:
          return UP_;
        case -1:
          return DOWN_;
        default:
          return LEFT_;
      }
  }
}

uint8_t TrackPointX(SPRITES *SPK_) {
  return (SPK_->health != 0) ? 7 : MainSprite.GridX;
}

uint8_t TrackPointY(SPRITES *SPK_) {
  return (SPK_->health != 0) ? 5 : MainSprite.GridY;
}

void TrackDirection(SPRITES *SPK_) {
  if (Move_Ok(LEFT_, SPK_)) {
    if (Ctrl.Left != 3) Ctrl.Left = (TrackPointX(SPK_) < SPK_->GridX) ? 1 : 2;
  } else {
    Ctrl.Left = 0;
  }
  if (Move_Ok(RIGHT_, SPK_)) {
    if (Ctrl.Right != 3) Ctrl.Right = (TrackPointX(SPK_) > SPK_->GridX) ? 1 : 2;
  } else {
    Ctrl.Right = 0;
  }
  if (Move_Ok(UP_, SPK_)) {
    if (Ctrl.Up != 3) Ctrl.Up = (TrackPointY(SPK_) < SPK_->GridY) ? 1 : 2;
  } else {
    Ctrl.Up = 0;
  }
  if (Move_Ok(DOWN_, SPK_)) {
    if (Ctrl.Down != 3) Ctrl.Down = (TrackPointY(SPK_) > SPK_->GridY) ? 1 : 2;
  } else {
    Ctrl.Down = 0;
  }
}

void SetCtrl(uint8_t Pos_, uint8_t Val_) {
  switch (Pos_) {
    case UP_: Ctrl.Up = Val_; break;
    case RIGHT_: Ctrl.Right = Val_; break;
    case DOWN_: Ctrl.Down = Val_; break;
    case LEFT_: Ctrl.Left = Val_; break;
  }
}

void FixPriority(uint8_t Val_) {
  Ctrl.Left = (Ctrl.Left == Val_) ? 1 : 0;
  Ctrl.Right = (Ctrl.Right == Val_) ? 1 : 0;
  Ctrl.Up = (Ctrl.Up == Val_) ? 1 : 0;
  Ctrl.Down = (Ctrl.Down == Val_) ? 1 : 0;
}

void FixCtrl(void) {

  if (Ctrl.Left == 1 || Ctrl.Right == 1 || Ctrl.Up == 1 || Ctrl.Down == 1) {
    FixPriority(1);
    return;
  }

  if (Ctrl.Left == 2 || Ctrl.Right == 2 || Ctrl.Up == 2 || Ctrl.Down == 2) {
    FixPriority(2);
    return;
  }

  if (Ctrl.Left == 3 || Ctrl.Right == 3 || Ctrl.Up == 3 || Ctrl.Down == 3) {
    FixPriority(3);
    return;
  }
}

uint8_t RD_4() {
  RDC = (RDC < 15) ? RDC + 1 : 0;
  return pgm_read_byte(&Rnd_Array[RDC]);
}

void resetCtrl(void) {
  Ctrl.Down = 0;
  Ctrl.Up = 0;
  Ctrl.Left = 0;
  Ctrl.Right = 0;
}

void SetMove(uint8_t Move_) {
  resetCtrl();
  switch (Move_) {
    case LEFT_: Ctrl.Left = 1; break;
    case RIGHT_: Ctrl.Right = 1; break;
    case UP_: Ctrl.Up = 1; break;
    case DOWN_: Ctrl.Down = 1; break;
  }
}

void RandomDirection() {
  for (uint8_t t = 0; t < 4; t++) {
    switch (RD_4()) {
      case LEFT_:
        if ((Ctrl.Left == 1) || (Ctrl.Left == 2)) {
          SetMove(LEFT_);
          return;
        };
        break;
      case RIGHT_:
        if ((Ctrl.Right == 1) || (Ctrl.Right == 2)) {
          SetMove(RIGHT_);
          return;
        };
        break;
      case UP_:
        if ((Ctrl.Up == 1) || (Ctrl.Up == 2)) {
          SetMove(UP_);
          return;
        };
        break;
      case DOWN_:
        if ((Ctrl.Down == 1) || (Ctrl.Down == 2)) {
          SetMove(DOWN_);
          return;
        };
        break;
    }
  }

  if (Ctrl.Left == 3) {
    SetMove(LEFT_);
    return;
  }
  if (Ctrl.Right == 3) {
    SetMove(RIGHT_);
    return;
  }
  if (Ctrl.Up == 3) {
    SetMove(UP_);
    return;
  }
  if (Ctrl.Down == 3) {
    SetMove(DOWN_);
    return;
  }
}

void GhostsDirectionProcess(SPRITES *SPK_) {

  Ctrl = (CTRL_){ 1, 1, 1, 1 };
  SetCtrl(CheckDirection(SPK_), 3);
  TrackDirection(SPK_);

  if (RD_4() > 2) {
    RandomDirection();
  } else {
    FixCtrl();
  }
}

void ControlUpdate(SPRITES *SPK_) {
  if (SPK_->Type == 1) {
    resetCtrl();
    Ctrl.Left = TINYJOYPAD_LEFT;
    Ctrl.Right = TINYJOYPAD_RIGHT;
    Ctrl.Up = TINYJOYPAD_UP;
    Ctrl.Down = TINYJOYPAD_DOWN;
  } else {
    if ((SPK_->GridX == RespawnX) && (SPK_->GridY == RespawnY)) {
      if (SPK_->health == 2) { SPK_->health = 0; }
    }
    GhostsDirectionProcess(SPK_);
  }
}

void SelectDirection(SPRITES *SPK_) {
  uint8_t N_ = NeutralPosition(SPK_);
  if (N_ == 0) {
    return;
  } else {
    ControlUpdate(SPK_);
    if ((Ctrl.Left) && (Move_Ok(3, SPK_))) {
      SPK_->Xdir = -1;
      SPK_->Ydir = 0;
    }
    if ((Ctrl.Right) && (Move_Ok(1, SPK_))) {
      SPK_->Xdir = 1;
      SPK_->Ydir = 0;
    }
    if ((Ctrl.Up) && (Move_Ok(0, SPK_))) {
      SPK_->Ydir = -1;
      SPK_->Xdir = 0;
    }
    if ((Ctrl.Down) && (Move_Ok(2, SPK_))) {
      SPK_->Ydir = 1;
      SPK_->Xdir = 0;
    }
  }
}

void UpdateMove(SPRITES *SPK_) {
  if (SPK_->Xdir == -1) Go2Left(SPK_);
  if (SPK_->Xdir == 1) Go2Right(SPK_);
  if (SPK_->Ydir == -1) Go2Up(SPK_);
  if (SPK_->Ydir == 1) Go2Down(SPK_);
  if (NeutralPosition(&MainSprite)) { CheckCollectible(); }
}

void MainPlayerUpdate() {
  if ((BUTTON_DOWN) && (JmpTrig == 2)) { JmpTrig = 1; }

  SelectDirection(&MainSprite);
  UpdateMove(&MainSprite);

  if (GP.PacSpeedTimer) {
    SelectDirection(&MainSprite);
    UpdateMove(&MainSprite);
    if (GP.PacSpeedTimer) GP.PacSpeedTimer--;
  }
}

void GhostsUpdate() {
  for (uint8_t t = 0; t < GP.NbGhosts; t++) {
    if ((Ghosts[t].SkipMode == 0) || (Ghosts[t].health == 2)) {
      SelectDirection(&Ghosts[t]);
      UpdateMove(&Ghosts[t]);
      Ghosts[t].SkipMode = Ghosts[t].Speed;
    } else {
      if (Ghosts[t].SkipMode != 0) { Ghosts[t].SkipMode--; }
    }
  }
}

static inline int8_t fast_abs(int8_t x) {
  int8_t mask = x >> 7;
  return (x ^ mask) - mask;
}

static inline uint8_t Pac_collision(void) {
#define sprite1x (((MainSprite.GridX) * (DriftX - 1)) + MainSprite.DecalageX)
#define sprite1y (((MainSprite.GridY) * (DriftY - 1)) + MainSprite.DecalageY)
#define sprite2x(T_) ((Ghosts[T_].GridX * (DriftX - 1)) + Ghosts[T_].DecalageX)
#define sprite2y(T_) ((Ghosts[T_].GridY * (DriftY - 1)) + Ghosts[T_].DecalageY)

  for (uint8_t t = 0; t < GP.NbGhosts; t++) {

    int16_t x_distance = sprite1x - sprite2x(t);
    int16_t y_distance = sprite1y - sprite2y(t);
    int8_t z_distance = (JmpPos);

    if (abs(x_distance) <= 2 && abs(y_distance) <= 2) {

      if ((abs(z_distance) <= 2) || (t == JUMPINGGHOST)) {

        if (Ghosts[t].health == 0) {
          return 1;
        } else if (Ghosts[t].health == 1) {
          Ghosts[t].health = 2;
          SoundSystem(1);
          _delay_ms(250);
          Scores(250);
        }
      }
    }
  }
  return 0;
}

void RefreshJump(void) {
  if (JmpTrig == 1) {
    JmpPos = pgm_read_byte(&Jump[JmpSeq]);
    if (JmpSeq < 23) {
      JmpSeq++;
    } else {
      JmpSeq = 0;
      JmpTrig = 2;
    }
  }
}

void intro(void) {
  for (uint8_t y = 0; y < 32; y += 3) {

    drawSprite2Bit(0, y, Vertical2, 0, false);
    drawSprite2Bit(2, y, Vertical2, 0, false);

    drawSprite2Bit(63, y, Vertical2, 0, false);
    drawSprite2Bit(61, y, Vertical2, 0, false);

    drawSprite2Bit(4, y, Vertical2, 0, false);
    drawSprite2Bit(59, y, Vertical2, 0, false);

    drawSprite2Bit(1, y + FRM, PIX, 0, false);
    drawSprite2Bit(62, y + FRM, PIX, 0, false);
  }

  for (uint8_t y = 4; y < 59; y++) {
    drawSprite2Bit(y, 0, Horizon2, 0, false);
    drawSprite2Bit(y, 15, Horizon2, 0, false);
    drawSprite2Bit(y, 17, Horizon2, 0, false);
    drawSprite2Bit(y, 31, Horizon2, 0, false);
  }

  drawSprite2Bit(9 + pgm_read_byte(&animFruits[Bonus.Anim]), 4, TinyMania2, 0, false);
  if (Bonus.Anim > 3) drawSprite2Bit(23, 22, Start2, 0, false);
  drawSprite2Bit(13, 23, Fruits, 3, false);
  drawSprite2Bit(52, 18, GHOST, 3 + FRM, false);
  drawSprite2Bit(5, 18, PAC, FRM, false);
  drawSprite2Bit(43, 23, Fruits, 0, false);
  if ((BUTTON_DOWN) && (Fade.Active == 0)) {
    Sound(100, 255);
    while (1) {
      if (BUTTON_UP) {
        Sound(20, 255);
        break;
      }
    }
    Fade2Black(1);
  }
  _delay_ms(13);
}

void Fade2White(uint8_t Val_) {
  Fade.Active = 2;
  Fade.IngameTrigger = Val_;
}

void Fade2Black(uint8_t Val_) {
  Fade.Active = 1;
  Fade.IngameTrigger = Val_;
}

void UpdateFadeSequence() {
  switch (Fade.Active) {
    case 1:
      if (Fade.Frame != 0) {
        Fade.Frame--;
      } else {
        if (Fade.Active == 1) {
          Fade.Active = 2;
          INGAME = Fade.IngameTrigger;
          MENU_FADESELECT();
        }
      }
      break;
    case 2:
      if (Fade.Frame != 8) {
        Fade.Frame++;
      } else {
        INGAME = Fade.IngameTrigger;
        Fade.Active = 0;
      }
      break;
    default: break;
  }
}

static inline void i2c_Mixers(uint8_t out_) {
  uint8_t Val_ = out_ & (pgm_read_byte(&FD[Fade.Frame]));
  i2c_write(Val_);
}

void loop() {
  for (uint16_t i = 0; i < 256; i++) ((uint8_t *)VBuffer)[i] = 0x00;
  if (INGAME) {
    if (Fade.Active == 0) {
      if (Pac_collision()) {
        SoundSystem(4);
        _delay_ms(1000);
        Fade2Black(2);
      }
      if (Fade.Active == 0) {
        MainPlayerUpdate();
        GhostsUpdate();
        RefreshJump();
      }
    }
    DrawLevel();
  } else {
    intro();
  }
  GobTimer();
  UpdateFadeSequence();
  Tiny_Flip();
  ANIM();
  //FPS_Limiter(33);
}

static inline uint8_t SliceByte(uint8_t page, uint8_t data) {
  uint8_t nibble = (page & 1) ? (data >> 4) : (data & 0x0F);
  static const uint8_t expand[16] PROGMEM = {
    0b00000000, 0b00000011, 0b00001100, 0b00001111,
    0b00110000, 0b00110011, 0b00111100, 0b00111111,
    0b11000000, 0b11000011, 0b11001100, 0b11001111,
    0b11110000, 0b11110011, 0b11111100, 0b11111111
  };
  return pgm_read_byte(&expand[nibble]);
}

void reset_Scores() {
  Digits[0] = 0;
  Digits[1] = 0;
  Digits[2] = 0;
  Digits[3] = 0;
  Digits[4] = 0;
  BonusCollected();
}

void Scores(uint8_t Add_) {
  for (uint8_t i = 0; i < Add_; i++) {
    Digits[4]++;
    if (Digits[4] > 9) {
      Digits[4] = 0;
      // Propagation à Digit10
      Digits[3]++;
      if (Digits[3] > 9) {
        Digits[3] = 0;
        // Propagation à Digit100
        Digits[2]++;
        if (Digits[2] > 9) {
          Digits[2] = 0;
          // Propagation à Digit1000
          Digits[1]++;
          BonusDelivery();
          if (Digits[1] > 9) {
            Digits[1] = 0;
            // Propagation à Digit10000
            Digits[0]++;
            if (Digits[0] > 9) {
              // réinitialiser à 0
              Digits[0] = 0;
            }
          }
        }
      }
    }
  }
}

static inline void Recup_Digital(uint8_t *Pos_, uint8_t *Digit_) {
  uint8_t index = *Pos_ + (4 * Digits[*Digit_]);
  uint8_t value = pgm_read_byte(&police[0] + index);
  i2c_Mixers(value);

  if (*Pos_ < 3) {
    (*Pos_)++;
  } else {
    (*Digit_)++;
    *Pos_ = 0;
  }
}

static inline void Recup_Lives(uint8_t *Pos_) {
  i2c_Mixers(pgm_read_byte(&MiniPac[0] + *Pos_));
  if (*Pos_ < 5) {
    (*Pos_)++;
  } else {
    *Pos_ = 0;
  }
}

static inline void Tiny_Flip() {
  uint8_t pos_ = 0;
  uint8_t pos2_ = 0;
  uint8_t Dig_ = 0;

  for (uint8_t p = 0; p < 8; p++) {
    ssd1306_selectPage(p);
    uint8_t buf_page = p >> 1;

    for (uint8_t x = 0; x < 64; x++) {
      uint8_t out = SliceByte(p, VBuffer[buf_page][x]);

      if ((p == 7) && (INGAME)) {
        if (x > 53) {
          Recup_Digital(&pos_, &Dig_);
          Recup_Digital(&pos_, &Dig_);
        } else if (x + 1 < (3 * (GP.PacLives))) {
          Recup_Lives(&pos2_);
          Recup_Lives(&pos2_);
        } else {
          i2c_Mixers(out);
          i2c_Mixers(out);
        }
      } else {
        i2c_Mixers(out);
        i2c_Mixers(out);
      }
    }
  }
  i2c_stop();
}

inline void drawSprite2Bit(int8_t x0, int8_t y0, const uint8_t *sprite, uint8_t frame, bool Mono) {
  uint8_t w = pgm_read_byte(sprite++);
  uint8_t h = pgm_read_byte(sprite++);

  uint8_t pages = (h + 7) >> 3;
  uint16_t plane_size = (uint16_t)w * pages;
  uint16_t frame_size = plane_size * 2;

  sprite += frame * frame_size;

  const uint8_t *white = sprite;
  const uint8_t *black = sprite + plane_size;

  if (x0 >= 64 || y0 >= 32 || x0 + w <= 0 || y0 + h <= 0)
    return;

  for (int8_t x = 0; x < w; x++) {
    int8_t sx = x0 + x;
    if (sx < 0 || sx >= 64) continue;

    for (uint8_t p = 0; p < pages; p++) {
      uint16_t offset = (uint16_t)x + (uint16_t)p * w;

      uint8_t wb = pgm_read_byte(white + offset);
      uint8_t bb = pgm_read_byte(black + offset);

      if (!wb && !bb) continue;

      uint8_t baseY = p << 3;
      uint8_t maxBit = (h - baseY > 8) ? 8 : h - baseY;

      for (uint8_t bit = 0; bit < maxBit; bit++) {
        uint8_t mask = 1 << bit;
        int8_t sy = y0 + baseY + bit;

        if (sy < 0 || sy >= 32) continue;

        if ((bb & mask) && (Mono))
          VBuffer[sy >> 3][sx] &= ~(1 << (sy & 7));
        else if (wb & mask)
          VBuffer[sy >> 3][sx] |= (1 << (sy & 7));
      }
    }
  }
}
