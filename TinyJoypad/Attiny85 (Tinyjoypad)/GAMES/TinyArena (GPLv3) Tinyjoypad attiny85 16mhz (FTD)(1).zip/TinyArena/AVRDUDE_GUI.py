# ================================================
#  Flasher ATtiny85 – Version finale avec popup commande by Daniel C.(Électro L.I.B) 2025 GPLv3
# ================================================

import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext
import subprocess
import sys
import os
import serial.tools.list_ports

# ----------------- CONFIG -----------------
BAUDRATE = "19200"

CLOCK_OPTIONS = {
    "8 MHz (vitesse normale – recommandé)": {
        "desc": "Fréquence officielle – 100 % stable",
        "lfuse": "0xE2", "hfuse": "0xDF", "efuse": "0xFF"
    },
    "1 MHz (basse consommation)": {
        "desc": "Idéal pour les projets sur pile",
        "lfuse": "0x62", "hfuse": "0xDF", "efuse": "0xFF"
    },
    "16.5 MHz (PLL – rapide)": {
        "desc": "Overclock via PLL interne",
        "lfuse": "0xE1", "hfuse": "0xD9", "efuse": "0xFF"
    },
    "20 MHz (overclock très stable)": {
        "desc": "+150 % de vitesse – fonctionne sur 99 % des puces",
        "lfuse": "0xF1", "hfuse": "0xD9", "efuse": "0xFF"
    }
}

# ----------------- FONCTIONS -----------------
def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def lister_ports():
    ports = serial.tools.list_ports.comports()
    liste = []
    for p in sorted(ports, key=lambda x: x.device):
        texte = p.device
        if p.description and p.description != "n/a":
            texte += f" – {p.description}"
        liste.append(texte)
    return liste if liste else ["Aucun port détecté"]

def actualiser_ports():
    ports = lister_ports()
    port_combobox['values'] = ports
    if ports and ports[0] != "Aucun port détecté":
        for p in ports:
            if any(mot in p.lower() for mot in ["arduino", "usbserial", "usbmodem", "acm", "usb", "uno"]):
                port_combobox.set(p)
                maj_commande()
                return
        port_combobox.current(0)
    else:
        port_combobox.set("Aucun port détecté")
    maj_commande()

def get_port_seul():
    sel = port_combobox.get()
    if not sel or "Aucun" in sel:
        return ""
    return sel.split(" – ")[0].split(" (")[0]

def select_hex_file():
    dossier = get_script_directory()
    fichier = filedialog.askopenfilename(
        title="Sélectionner le fichier .hex",
        initialdir=dossier,
        filetypes=[("Fichiers HEX", "*.hex"), ("Tous les fichiers", "*.*")]
    )
    if fichier:
        hex_entry.delete(0, tk.END)
        hex_entry.insert(0, fichier)
        maj_commande()

# === Mise à jour automatique de la commande ===
def maj_commande(*args):
    port = get_port_seul()
    hex_file = hex_entry.get().strip()
    choix = clock_var.get()
    fuses = CLOCK_OPTIONS[choix]

    if not port or not hex_file or not os.path.isfile(hex_file):
        commande_preview.set("Commande incomplète : port ou fichier manquant")
        return

    cmd = [
        "avrdude", "-v", "-c", "arduino", "-p", "attiny85",
        "-P", port, "-b", BAUDRATE, "-e",
        "-U", f"flash:w:\"{hex_file}\":i",
        "-U", f"lfuse:w:{fuses['lfuse']}:m",
        "-U", f"hfuse:w:{fuses['hfuse']}:m",
        "-U", f"efuse:w:{fuses['efuse']}:m"
    ]
    commande_complete = " ".join(cmd)
    commande_preview.set(commande_complete[:200] + ("..." if len(commande_complete) > 200 else ""))

# === Popup avec la commande complète + bouton Copier ===
def afficher_commande_popup():
    port = get_port_seul()
    hex_file = hex_entry.get().strip()
    choix = clock_var.get()
    if not port or not hex_file or not os.path.isfile(hex_file):
        messagebox.showwarning("Manque info", "Sélectionne un port ET un fichier .hex valide d'abord !")
        return

    fuses = CLOCK_OPTIONS[choix]
    cmd = [
        "avrdude", "-v", "-c", "arduino", "-p", "attiny85",
        "-P", port, "-b", BAUDRATE, "-e",
        "-U", f"flash:w:\"{hex_file}\":i",
        "-U", f"lfuse:w:{fuses['lfuse']}:m",
        "-U", f"hfuse:w:{fuses['hfuse']}:m",
        "-U", f"efuse:w:{fuses['efuse']}:m"
    ]
    commande = " ".join(cmd)

    popup = tk.Toplevel(root)
    popup.title("Commande avrdude complète")
    popup.geometry("920x380")
    popup.transient(root)
    popup.grab_set()

    txt = scrolledtext.ScrolledText(popup, font=("Consolas", 11), wrap=tk.WORD)
    txt.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
    txt.insert(tk.END, commande)
    txt.config(state="disabled")

    def copier():
        popup.clipboard_clear()
        popup.clipboard_append(commande)
        popup.update()
        btn_copier.config(text="Copié !")

    frame_btn = ttk.Frame(popup)
    frame_btn.pack(pady=10)
    btn_copier = ttk.Button(frame_btn, text="Copier dans le presse-papier", command=copier)
    btn_copier.pack(side=tk.LEFT, padx=10)
    ttk.Button(frame_btn, text="Fermer", command=popup.destroy).pack(side=tk.RIGHT, padx=10)

def flash_attiny():
    port = get_port_seul()
    if not port:
        messagebox.showerror("Erreur", "Sélectionne un port série !")
        return
    hex_file = hex_entry.get().strip()
    if not os.path.isfile(hex_file):
        messagebox.showerror("Erreur", "Fichier .hex invalide !")
        return

    choix = clock_var.get()
    fuses = CLOCK_OPTIONS[choix]

    if not messagebox.askyesno("Prêt ?", f"{choix}\n→ {fuses['desc']}\n\nAppuie sur RESET de l'Uno maintenant !"):
        return

    cmd = [
        "avrdude", "-v", "-c", "arduino", "-p", "attiny85",
        "-P", port, "-b", BAUDRATE, "-e",
        "-U", f"flash:w:{hex_file}:i",
        "-U", f"lfuse:w:{fuses['lfuse']}:m",
        "-U", f"hfuse:w:{fuses['hfuse']}:m",
        "-U", f"efuse:w:{fuses['efuse']}:m"
    ]

    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=50)
        if r.returncode == 0:
            messagebox.showinfo("SUCCÈS", f"ATtiny85 flashé en {choix} !")
        else:
            messagebox.showerror("Échec", f"Erreur {r.returncode}\n\n{r.stderr[-900:]}")
    except FileNotFoundError:
        messagebox.showerror("avrdude manquant", "Installe avrdude ou ajoute-le au PATH")
    except subprocess.TimeoutExpired:
        messagebox.showerror("Timeout", "Réessaie en appuyant sur RESET au bon moment")

# ----------------- INTERFACE -----------------
root = tk.Tk()
root.title("Flasher ATtiny85 – Version finale 2025")
root.geometry("960x760")
root.minsize(880, 700)

style = ttk.Style()
style.theme_use("clam")

main = ttk.Frame(root, padding=30)
main.pack(fill=tk.BOTH, expand=True)

ttk.Label(main, text="Programmateur ATtiny85 (Arduino Uno ISP)", 
          font=("Helvetica", 19, "bold")).pack(pady=(0, 25))

# Fichier .hex
frame_hex = ttk.Frame(main)
frame_hex.pack(fill=tk.X, pady=12)
ttk.Label(frame_hex, text="Fichier .hex :", width=18, font=("Helvetica", 10, "bold")).pack(side=tk.LEFT)
hex_entry = ttk.Entry(frame_hex, font=("Consolas", 11))
hex_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
hex_entry.bind("<KeyRelease>", maj_commande)
ttk.Button(frame_hex, text="Parcourir…", command=select_hex_file).pack(side=tk.RIGHT)

# Port série
frame_port = ttk.Frame(main)
frame_port.pack(fill=tk.X, pady=15)
ttk.Label(frame_port, text="Port série :", width=18, font=("Helvetica", 10, "bold")).pack(side=tk.LEFT)
port_combobox = ttk.Combobox(frame_port, state="readonly", font=("Consolas", 11))
port_combobox.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=10)
port_combobox.bind("<<ComboboxSelected>>", maj_commande)
ttk.Button(frame_port, text="Actualiser", command=actualiser_ports).pack(side=tk.RIGHT)

# Fréquence
frame_clock = ttk.Frame(main)
frame_clock.pack(fill=tk.X, pady=15)
ttk.Label(frame_clock, text="Fréquence :", font=("Helvetica", 10, "bold")).pack(side=tk.LEFT)
clock_var = tk.StringVar(value="8 MHz (vitesse normale – recommandé)")
clock_var.trace("w", maj_commande)
ttk.OptionMenu(frame_clock, clock_var, clock_var.get(), *CLOCK_OPTIONS.keys()).pack(side=tk.LEFT, padx=20)

# Aperçu de la commande
commande_preview = tk.StringVar(value="Sélectionne port + fichier pour voir la commande")
ttk.Label(main, textvariable=commande_preview, font=("Consolas", 10), foreground="#0066cc", 
          relief="sunken", padding=10, anchor="w").pack(fill=tk.X, pady=15)

# Boutons
frame_btns = ttk.Frame(main)
frame_btns.pack(pady=20)
ttk.Button(frame_btns, text="Afficher la commande complète", command=afficher_commande_popup).pack(side=tk.LEFT, padx=15)
ttk.Button(frame_btns, text="PROGRAMMER L'ATTINY85", command=flash_attiny).pack(side=tk.RIGHT, padx=15, ipadx=30, ipady=10)

# Infos branchement
ttk.Label(main, text=
    "• Sketch ArduinoISP chargé sur l'Uno\n"
    "• Condensateur 10 µF entre RESET et GND sur l'Uno\n"
    "• Branchements : 10→RESET | 11→MOSI | 12→MISO | 13→SCK | VCC | GND\n"
    "• Appuie sur RESET juste avant de cliquer sur PROGRAMMER",
    foreground="#333", justify=tk.LEFT, font=("Helvetica", 10)).pack(pady=25, anchor="w")

ttk.Label(root, text="Version finale 2025 – avec popup commande + copier", 
          foreground="gray60", font=("Helvetica", 9)).pack(side=tk.BOTTOM, pady=12)

# Démarrage
actualiser_ports()
root.mainloop()
