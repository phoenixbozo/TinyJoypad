//           >>>>>  T-I-N-Y  B-E-R-T for ARDUBOY  GPL v3 <<<<
//                   Programmer: Daniel C 2019-2021
//              Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                    https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection

//  Tiny_Bert is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
// Reference in file "COPYING.txt".
-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-


The Tiny_Bert source code include commands referencing to librairy 
Arduboy2 who is not include in the source code.

Reference in file "Arduboy2_library_LICENSE.txt".
https://github.com/MLXXXp/Arduboy2

A HEX file "TINY_BERT.ino.leonardo.hex" is provided with the source code which includes
compiled code from the Arduboy2 library.
Reference in the file "Arduboy2_library_LICENSE.txt".
