//            >>>>>  0x0Emul for Arduboy  GPL v3 <<<<<
//                    Programmer: Daniel C 2024
//             Contact EMAIL: electro_l.i.b@tinyjoypad.com
//  https://github.com/phoenixbozo/TinyJoypad/tree/main/TinyJoypad
//                    https://WWW.TINYJOYPAD.COM
//          https://sites.google.com/view/arduino-collection

//   0x0Emul is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
// Reference in file "COPYING.txt".
// -__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-

// The 0x0Emul source code include commands referencing to librairy 
// Arduboy2 and ArduboyPlaytune who is not include in the source code.

// Reference in file "Arduboy2_library_LICENSE.txt".
// https://github.com/MLXXXp/Arduboy2

// A HEX file "0x0Emul.ino.hex" is provided with the source code which includes
// compiled code from the Arduboy2 library an ArduboyPlaytune.
// Reference in the file "Arduboy2_library_LICENSE.txt".

/* 0x0Emul is a program that interprets hexadecimal code from data created with ABasm by Fuopy retrieved from the EEPROM.
   ABasm (Fuopy) App: https://github.com/fuopy/ABasm */

/* It includes 3 features:

1- Retrieve the code present in the EEPROM and send it to the Arduino IDE terminal.
(Connect Arduboy to PC, open Arduino IDE terminal, press LEFT_BUTTON in the menu, and hold B_BUTTON DOWN for 2 seconds)

2- Allows installing in the EEPROM a code present in the menu of 0x0Emul for reediting with ABasm by Fuopy.
(Select a game on the 0x0Emul menu, press RIGHT_BUTTON in the menu, and hold B_BUTTON DOWN for 2 seconds)

3- Emulate the program or game in HEX format.*/

// To add a Hex code for emulation, the settings are adjusted in the HexProg.h file associated with the main source file 0x0Emul.ino.
