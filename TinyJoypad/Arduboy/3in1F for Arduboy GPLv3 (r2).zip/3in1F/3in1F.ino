//                >>>>>  3in1F for ARDUBOY  GPL v3 <<<<
//                  Programmer: Daniel Champagne 2026
//            Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                    https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection

//  3in1F is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

// 3in1F = Reference in file "COPYING.txt".
// 
// -__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-


// The 3in1F source code include commands referencing to librairy 
// Arduboy2 who is not include in the source code.

// Reference in file "Arduboy2_library_LICENSE.txt".
// https://github.com/MLXXXp/Arduboy2

// A HEX file is provided with the source code which includes
// compiled code from the Arduboy2 library.
// Reference in the file "Arduboy2_library_LICENSE.txt".

#include <Arduboy2.h> // https://github.com/MLXXXp/Arduboy2
Arduboy2Base arduboy;
#include "PIC_3in1F.h"
#include "Tiny-SQuest/Tiny-SQuest.h"
#include "TinyDoc/TinyDoc.h"
#include "TinyArena/TinyArena.h"

//public var
int8_t POS_Cursor;

void setup() {
arduboy.begin();
}

int8_t Trig_3in1F=0;

void loop() {
POS_Cursor=13;


while(1){
if (TINYJOYPAD_LEFT) {Trig_3in1F=-1;}
if (TINYJOYPAD_RIGHT) {Trig_3in1F=1;}

if ((BUTTON_DOWN)&&(Trig_3in1F==0)) {Select_GAMES_3in1F();}
Check_POS_3in1F();
Tiny_Flip_3in1F();
}
}
////////////////////////////////// main end /////////////////////////////////

void Select_GAMES_3in1F(){
switch(POS_Cursor){
  case(13):UNPUSH_WAIT();loop_TSQUEST();break;
  case(56):UNPUSH_WAIT();loop_TDOC();break;
  case(99):UNPUSH_WAIT();loop_TARENA();break;
  default:break;
}
}

void UNPUSH_WAIT(void){
Sound(100,255);
while(1){
if (BUTTON_UP) {Sound(1,255);break;}
}
}

uint8_t Check_POS_3in1F(){ 
if (Trig_3in1F==1) POS_Cursor=(POS_Cursor<99)?POS_Cursor+1:99;
if (Trig_3in1F==-1) POS_Cursor=(POS_Cursor>13)?POS_Cursor-1:13;
  switch(POS_Cursor){
   case(13):Trig_3in1F=0;return 1;break;
   case(56):Trig_3in1F=0;return 1;break;
   case(99):Trig_3in1F=0;return 1;break;
   default:return 0;break;
  }
}

uint8_t Menu_3in1F(uint8_t xPASS,uint8_t yPASS){

return (yPASS>5)?0x00:pgm_read_byte(&MENU_3in1F[xPASS+(yPASS*128)]);
}

uint8_t Selector_3in1F(uint8_t xPASS,uint8_t yPASS){
return blitzSprite(POS_Cursor,55,xPASS,yPASS,0,T_SUBMAIN_TSQUEST);
}

uint8_t Recupe_3in1F(uint8_t xPASS,uint8_t yPASS){
return (Menu_3in1F(xPASS,yPASS)|(Selector_3in1F(xPASS,yPASS)));
}

void Tiny_Flip_3in1F(void){
uint8_t y,x; 
for (y = 0; y < 8; y++){ 
for (x = 0; x <128; x++){
arduboy.SPItransfer(Recupe_3in1F(x,y));}
}}

