#!/bin/bash

# Compilation...
./c.sh picopad20
