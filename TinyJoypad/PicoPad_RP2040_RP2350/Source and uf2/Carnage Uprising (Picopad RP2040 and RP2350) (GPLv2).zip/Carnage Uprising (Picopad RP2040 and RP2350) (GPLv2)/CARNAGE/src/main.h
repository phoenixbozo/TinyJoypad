// >>>>> Carnage Uprising for PicoPad RP2040 & RP2350+  GPLv2 <<<<<
//                    Programmer: Daniel C 2025
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection
//
// Carnage Uprising is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2.0 as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// The full license text is available in the file "GPL-2.0.txt".
//
// This source code includes commands referencing the PicoLibSDK library,
// which is not included in this source distribution.
//
// A compiled .uf2 file "CARNAGE.UF2" is provided, which includes code from
// the PicoLibSDK library by Miroslav Nemecek (https://github.com/Panda381/PicoLibSDK).
// PicoLibSDK includes code from the Raspberry Pi Pico SDK (under BSD 3-Clause License)
// and floating-point mathematics library by Mark Owen (under GNU General Public License version 2.0).
// See "PicoLibSDK_Readme.txt" for details on PicoLibSDK licensing and usage.
//
// Thanks to Miroslav Nemecek for PicoLibSDK, Mark Owen for the floating-point
// mathematics library, and Raspberry Pi for the Pico SDK.
// -__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__
 
#ifndef _MAIN_H
#define _MAIN_H

#define TINYJOYPAD_LEFT   (KeyPressed(KEY_LEFT))
#define TINYJOYPAD_RIGHT (KeyPressed(KEY_RIGHT))
#define TINYJOYPAD_DOWN (KeyPressed(KEY_DOWN))
#define TINYJOYPAD_UP (KeyPressed(KEY_UP))
#define BUTTON_A  (KeyPressed(KEY_A))
#define BUTTON_B  (KeyPressed(KEY_B))
#define BUTTON_X  (KeyPressed(KEY_X))
#define BUTTON_Y  (KeyPressed(KEY_Y))
#define BUTTON_DOWN ( (KeyPressed(KEY_A))||(KeyPressed(KEY_B)) )
#define BUTTON_UP ( (!KeyPressed(KEY_A)) && (!KeyPressed(KEY_B)) )

//snd
extern const u8 fire[1313];
extern const u8 ouu1[15042];
extern const u8 ouu2[21931];
extern const u8 ouu3[10925];
extern const u8 ouu4[21500];
extern const u8 ouu5[29546];
extern const u8 loop[353619]; //ingame song
extern const u8 intro[160210]; //intro song
extern const u8 Button[1281]; //Menu Button sound
extern const u8 go[84396]; //Game Over sound
extern const u8 pickup[7947]; //pickup sound
extern const u8 helico[119257]; //pickup sound
extern const u8 explod[15485]; //pickup sound
extern const u8 congrats[92245]; //Congrats sound
extern const u8 logo[110336]; //logo sound

// format: 8-bit paletted pixel graphics

//STATIC IMAGES
#define splash_W 320
#define splash_W_FULL 320
#define splash_H 240
extern const u16 splash_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 splash[76800]/* __attribute__ ((aligned(4)))*/;


#define menu_W 320
#define menu_W_FULL 320
#define menu_H 240
extern const u16 menu_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 menu[76800]/* __attribute__ ((aligned(4)))*/;

#define gopic_W 320
#define gopic_W_FULL 320
#define gopic_H 240
extern const u16 gopic_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 gopic[76800]/* __attribute__ ((aligned(4)))*/;

#define win_W 320
#define win_W_FULL 320
#define win_H 240
extern const u16 win_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 win[76800]/* __attribute__ ((aligned(4)))*/;

#define ico_W 179
#define ico_W_FULL 180
#define ico_H 20
extern const u16 ico_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 ico[3960]/* __attribute__ ((aligned(4)))*/;


// 2 or 3 layer Sprites particularity
#define hut_W 359
#define hut_W_FULL 360
#define hut_H 120
extern const u16 hut_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 hut[43200]/* __attribute__ ((aligned(4)))*/;

#define arbre_W 251
#define arbre_W_FULL 252
#define arbre_H 86
extern const u16 arbre_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 arbre[21672]/* __attribute__ ((aligned(4)))*/;


#define arbremort_W 251
#define arbremort_W_FULL 252
#define arbremort_H 86
extern const u16 arbremort_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 arbremort[21672]/* __attribute__ ((aligned(4)))*/;

#define sapin_W 251
#define sapin_W_FULL 252
#define sapin_H 86
extern const u16 sapin_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 sapin[21672]/* __attribute__ ((aligned(4)))*/;

#define beton_W 95
#define beton_W_FULL 96
#define beton_H 32
extern const u16 beton_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 beton[3072]/* __attribute__ ((aligned(4)))*/;

#define truck_W 150
#define truck_W_FULL 152
#define truck_H 38
extern const u16 truck_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 truck[5776]/* __attribute__ ((aligned(4)))*/;

#define h_W 239
#define h_W_FULL 240
#define h_H 96
extern const u16 h_Pal[2]/* __attribute__ ((aligned(4)))*/;
extern const u8 h[23040]/* __attribute__ ((aligned(4)))*/;

#define h0_W 239
#define h0_W_FULL 240
#define h0_H 96
extern const u16 h0_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 h0[23040]/* __attribute__ ((aligned(4)))*/;

#define h1_W 239
#define h1_W_FULL 240
#define h1_H 96
extern const u16 h1_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 h1[23040]/* __attribute__ ((aligned(4)))*/;

#define h2_W 239
#define h2_W_FULL 240
#define h2_H 96
extern const u16 h2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 h2[23040]/* __attribute__ ((aligned(4)))*/;

#define tank1_W 359
#define tank1_W_FULL 360
#define tank1_H 68
extern const u16 tank1_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tank1[24480]/* __attribute__ ((aligned(4)))*/;

#define plane_W 359
#define plane_W_FULL 360
#define plane_H 120
extern const u16 plane_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 plane[43200]/* __attribute__ ((aligned(4)))*/;


// 2 layer Sprites Pickups

#define jacket_W 63
#define jacket_W_FULL 64
#define jacket_H 32
extern const u16 jacket_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 jacket[2048]/* __attribute__ ((aligned(4)))*/;

#define amo0_W 63
#define amo0_W_FULL 64
#define amo0_H 32
extern const u16 amo0_Pal[168]/* __attribute__ ((aligned(4)))*/;
extern const u8 amo0[2048]/* __attribute__ ((aligned(4)))*/;

#define amo1_W 63
#define amo1_W_FULL 64
#define amo1_H 32
extern const u16 amo1_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 amo1[2048]/* __attribute__ ((aligned(4)))*/;

#define amo2_W 63
#define amo2_W_FULL 64
#define amo2_H 32
extern const u16 amo2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 amo2[2048]/* __attribute__ ((aligned(4)))*/;

#define amo3_W 63
#define amo3_W_FULL 64
#define amo3_H 32
extern const u16 amo3_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 amo3[2048]/* __attribute__ ((aligned(4)))*/;

#define radio_W 63
#define radio_W_FULL 64
#define radio_H 32
extern const u16 radio_Pal[201]/* __attribute__ ((aligned(4)))*/;
extern const u8 radio[2048]/* __attribute__ ((aligned(4)))*/;

#define bat_W 63
#define bat_W_FULL 64
#define bat_H 32
extern const u16 bat_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 bat[2048]/* __attribute__ ((aligned(4)))*/;

#define bidon_W 63
#define bidon_W_FULL 64
#define bidon_H 32
extern const u16 bidon_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 bidon[2048]/* __attribute__ ((aligned(4)))*/;


//static sprite
#define box_W 119
#define box_W_FULL 120
#define box_H 40
extern const u16 box_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 box[4800]/* __attribute__ ((aligned(4)))*/;

//static sprite
#define line_W 95
#define line_W_FULL 96
#define line_H 32
extern const u16 line_Pal[2]/* __attribute__ ((aligned(4)))*/;
extern const u8 line[3072]/* __attribute__ ((aligned(4)))*/;

//anim sprite
#define soldier_W 151
#define soldier_W_FULL 152
#define soldier_H 240
extern const u16 soldier_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 soldier[36480]/* __attribute__ ((aligned(4)))*/;

#define soldier2_W 151
#define soldier2_W_FULL 152
#define soldier2_H 240
extern const u16 soldier2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 soldier2[36480]/* __attribute__ ((aligned(4)))*/;

// Function prototypes
u16 ReturnCorectSelect(u8 Item,u8 Select);
void MenuIntro(void);
void DrawTypeofSprite(s16 X_, s16 Y_,u8 Sprite_);
bool isPositionValid(float x, float y, const uint8_t* level);
void frm_Main_Soldier_Refresh(void);
void DrawMainSoldier(s16 x_,s16 y_, s8 Direction_);
void DrawMultiLayerSprite(s16 x_, s16 y_,u8 Sprite_) ;
void DrawSprite(s16 x_, s16 y_, u8 frm_,u8 Sprite_) ;
s16 Decalage_X(s16 x_,s8 Height_,u8 Alt_);
s16 Decalage_Y(s16 y_,s8 Height_,u8 Alt_);
void applyRecoil(float *x, float *y, bool *isRecoiling, float *recoilTimer, float recoilDuration, s8 recoilDirection, float recoilDistance, float dt, const uint8_t* level);
float map(float x, float in_min, float in_max, float out_min, float out_max);
uint16_t getpixel( int x, int y);
void putpixel(int x, int y, uint16_t color);
void FadeOutToBlack(void);
void FadeInFromBlack(const u8 *PIC_,const u16 *PIC_PAL_);
void SND_Fade_Up(void);
void SND_Fade_Down(void);
void Draw_ICO_Display(u16 x_,u16 y_,u8 Pic_);
void Draw_Metal_Jacket(void);
void Draw_Amos(void);
void Draw_Mission(u8 Mis_);
void Mission_Completed(void);
void Draw_Kill_Count(void);
void Draw_OBJ_LVL(void);
void Draw_Ico(u16 x_,u16 y_,u8 Pic_);
void SND_Fade_Up_InGame(void);
void Draw_Shade_Ico(u16 x_,u16 y_,u8 Pic_);
void Return_to_Menu(const uint8_t *PIC_,const uint16_t *PIC_PAL_,const uint8_t* SND_,int length_);
#endif // _MAIN_H
