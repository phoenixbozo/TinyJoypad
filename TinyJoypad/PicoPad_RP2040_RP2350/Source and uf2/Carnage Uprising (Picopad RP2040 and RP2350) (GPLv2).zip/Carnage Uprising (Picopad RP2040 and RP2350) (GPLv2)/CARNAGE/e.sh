#!/bin/bash
# Export to hardware...

export TARGET="CARNAGE"
../../../_e1.sh
