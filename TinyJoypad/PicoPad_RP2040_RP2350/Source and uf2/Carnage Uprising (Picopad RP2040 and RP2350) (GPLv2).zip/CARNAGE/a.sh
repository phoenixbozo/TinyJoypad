#!/bin/bash
# All Re-Compilation...

bash d.sh
bash c.sh
bash e.sh
