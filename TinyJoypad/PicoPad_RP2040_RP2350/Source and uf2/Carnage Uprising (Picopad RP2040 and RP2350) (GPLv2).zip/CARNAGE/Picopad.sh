#!/bin/bash

# Compilation...
./c.sh
