#!/bin/bash

# Compilation...

export TARGET="CARNAGE"
export GRPDIR="CARNAGE"
export MEMMAP=""

../../../_c1.sh "$1"
