// >>>>> Carnage Uprising for PicoPad RP2040 & RP2350+  GPLv2 <<<<<
//                    Programmer: Daniel C 2025
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection
//
// Carnage Uprising is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2.0 as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// The full license text is available in the file "GPL-2.0.txt".
//
// This source code includes commands referencing the PicoLibSDK library,
// which is not included in this source distribution.
//
// A compiled .uf2 file "CARNAGE.UF2" is provided, which includes code from
// the PicoLibSDK library by Miroslav Nemecek (https://github.com/Panda381/PicoLibSDK).
// PicoLibSDK includes code from the Raspberry Pi Pico SDK (under BSD 3-Clause License)
// and floating-point mathematics library by Mark Owen (under GNU General Public License version 2.0).
// See "PicoLibSDK_Readme.txt" for details on PicoLibSDK licensing and usage.
//
// Thanks to Miroslav Nemecek for PicoLibSDK, Mark Owen for the floating-point
// mathematics library, and Raspberry Pi for the Pico SDK.
// -__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__
 
#include "../include.h"
#include "main.h"
#include <math.h>
#include <stdlib.h>

//#define DRAW_FPS

//Helico Sprites particularity Animated
const u8 *COP[4]={&h[0],&h0[0],&h1[0],&h2[0]};
const u16 *COP_PAL[4]={&h_Pal[0],&h0_Pal[0],&h1_Pal[0],&h2_Pal[0]};

// Sprites particularity
const u16 SpkCollectible[TotalMulLayerSpk]={0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,1,0,0,1,1,1,0,0}; //0=NA 1=collectible
const u8 SpkType[TotalMulLayerSpk]={0,3,3,3,0,3,3,2,3,2,2,2,2,2,0,2,3,3,2,2,2,1,1}; //0=NA 1=Simple Layer PSK 3=Triple Layer
const u8 SpkAlt[TotalMulLayerSpk]={0,2,1,2,0,2,0,0,0,1,1,1,1,2,0,1,1,0,1,1,1,0,0}; //Altitude overlap 0=min 2=max
const u8 *PIC[TotalMulLayerSpk]={&sapin[0],&sapin[0],&arbre[0],&hut[0],&soldier2[0],&arbremort[0],&box[0],&truck[0],&beton[0],&amo0[0],&amo1[0],&amo2[0],&amo3[0],COP[0],&sapin[0],&jacket[0],&tank1[0],&plane[0],&radio[0],&bat[0],&bidon[0],&line[0],&soldier[0]};
const u16 *PIC_PAL[TotalMulLayerSpk]={&sapin_Pal[0],&sapin_Pal[0],&arbre_Pal[0],&hut_Pal[0],&soldier2_Pal[0],&arbremort_Pal[0],&box_Pal[0],&truck_Pal[0],&beton_Pal[0],&amo0_Pal[0],&amo1_Pal[0],&amo2_Pal[0],&amo3_Pal[0],COP_PAL[0],&sapin_Pal[0],&jacket_Pal[0],&tank1_Pal[0],&plane_Pal[0],&radio_Pal[0],&bat_Pal[0],&bidon_Pal[0],&line_Pal[0],&soldier_Pal[0]};
const u8 MARGE_DE_DETECTION[TotalMulLayerSpk]={26,26,26,16,0,30,8,8,8,MDC,MDC,MDC,MDC,70,0,MDC,16,60,MDC,MDC,MDC,64,30};
const u16 SPK_W[TotalMulLayerSpk]={84,84,84,120,30,84,40,75,32,32,32,32,32,120,84,32,120,120,32,32,32,96,30};
const u16 SPK_H[TotalMulLayerSpk]={86,86,86,120,30,84,40,38,32,32,32,32,32,96,86,32,68,120,32,32,32,32,30};
const u16 Pic_W_FULL[TotalMulLayerSpk]={sapin_W_FULL,sapin_W_FULL,arbre_W_FULL,hut_W_FULL,soldier2_W_FULL,arbremort_W_FULL,box_W_FULL,truck_W_FULL,beton_W_FULL,amo0_W_FULL,amo1_W_FULL,amo2_W_FULL,amo3_W_FULL,h_W_FULL,sapin_W_FULL,jacket_W_FULL,tank1_W_FULL,plane_W_FULL,radio_W_FULL,bat_W_FULL,bidon_W_FULL,line_W_FULL,soldier_W_FULL};

const u8 *Level_Select[MAX_LEVEL] = {&Level_X[0],&Level_1[0],&Level_2[0],&Level_3[0],&Level_4[0],&Level_5[0],&Level_6[0],&Level_7[0],&Level_8[0],&Level_9[0],&Level_10[0],&Level_11[0]};
const u8 *Level_Use=Level_Select[LVL_Playing];

#define WALKING_SPEED 0.13f; // 120 ms par frame

// Constantes pour les ennemis
#define MAX_ENEMIES 40
#define MAX_ENEMY_PROJECTILES 10
#define ENEMY_PROJECTILE_STEP 4.0f // Pas de déplacement des projectiles ennemis
#define MAX_PROJECTILE_DISTANCE 80.0f // Distance maximale des projectiles
#define SHOOT_DISTANCE 160 // Distance de Tire
#define ENEMY_FIRE_RATE  1.4f; // Cadence de tir (secondes entre chaque tir)
#define MIN_DISTANCE_TO_PLAYER 40.0f // Distance minimale de 40 pixels
#define RANDOM_MOVE_DURATION 1.0f // Durée du mouvement aléatoire (1 seconde)

// Constantes globales
#define MAX_BLOOD_PARTICLES 400 // Nombre maximum de particules de sang
#define BLOODPARTICLES 100
#define BLT 0.1f//blood life time
#define DEATHTIMER 2.0f
#define HALFDEATHTIMER 1.0f
#define BLINKTIMER 0.1f
#define RECOIL_DIST 40.0f
#define RECOIL_SPD 0.14f

const s16 TILE_SIZE = 32;
const s16 SCREEN_WIDTH = 320;
const s16 SCREEN_HEIGHT = 240;
const float CAMERA_LAG = 0.05f;
const u8 PLAYER_W = 30;
const u8 PLAYER_H = 30;
const float MOVE_STEP_PLAYER = 1.4; // Pas de déplacement pour joueur 
const float MOVE_STEP_ENNEMIS = 1.0; // Pas de déplacement pour ennemis
const float TARGET_FPS = 60.0f;
const float FRAME_TIME = 1.0f / TARGET_FPS;

// Constantes pour les projectiles
#define MAX_PROJECTILES 10
#define PROJECTILE_STEP 4 // Pas de déplacement des projectiles
#define FIRE_RATE 0.4f // Temps entre chaque tir en secondes


// Variables globales
u8 MetalJacket=0;
u8 Heli_Mode=0; //Exit Heli mode
u8 LvL_Completed=0; //LvL_Completed
u8 LVL_Playing=0;
u8 Heli_FRM_Number=0; //Heli anim var
u8 enemyCount = 0; // Nombre d'ennemis dans le niveau
u8 enemyKillCount = 0; // Nombre d'ennemis abattus
float SNDUP=0; //SND Vol fade
float restartDelayTimer = 0.0f; // Timer pour le délai de 5 secondes
s8 frm_Main_Soldier_Div=0;
s8 frm_Main_Soldier=0;
s8 Soldier_Joy_Direction=0;
s8 Soldier_Direction=0;
bool isFireDirectionLocked = false; // État du verrouillage de la direction de tir
s8 lockedFireDirection = 0; // Direction de tir verrouillée

// Position du joueur
bool playerAlive = true;
bool playerIsDead = false;
float playerDeathTimer = 0.0f;
bool playerBlinkState = true;
float playerBlinkTimer = 0.0f;
float playerX =0;
float playerY =0;

// Player recoil state
bool playerIsRecoiling = false;
float playerRecoilTimer = 0.0f;
float playerRecoilDuration = RECOIL_SPD; // 0.14 seconds for recoil animation
s8 playerRecoilDirection = 0;
float playerRecoilDistance = RECOIL_DIST; // Fixed to 40 pixels
float playerRecoilStartX = 0.0f; // X position at start of player recoil
float playerRecoilStartY = 0.0f; // Y position at start of player recoil

// Position réelle de la caméra
float cameraX = 0.0f;
float cameraY = 0.0f;

// Variables pour le calcul des FPS
float fpsAccumulator = 0.0f; // Accumule le temps pour le calcul des FPS
float currentFPS = 0.0f;     // FPS calculé

// Variables pour le contrôle des frames
u32 lastTime = 0;
float accumulator = 0.0f;


// Valeurs associées aux directions
#define UP    1  // 0001
#define DOWN  2  // 0010
#define LEFT  4  // 0100
#define RIGHT 8  // 1000

// Constantes pour les armes
#define MAX_WEAPONS 4

typedef struct {
    u8 type;                // Type de projectile (0: Balle, 1: Shotgun, 2: Grenade)
    float fireRate;         // Temps entre chaque tir (secondes)
    float projectileSpeed;  // Vitesse du projectile (pixels par frame)
    float maxDistance;      // Distance maximale du projectile
    s16 maxAmmo;           // Munitions maximales (-1 pour infini)
    s16 currentAmmo;       // Munitions restantes
    u8 pellets;            // Nombre de projectiles pour shotgun (1 pour autres)
    float explosionRadius;  // Rayon d'explosion pour grenade (0 pour autres)
} Weapon;

    // Commentaires :
    // - type (0) : Identifiant de l'arme, 0 indique un pistolet (arme de base).
    // - fireRate (0.4f) : Intervalle de 0,4 seconde entre chaque tir (2,5 tirs par seconde).
    // - bulletSpeed (4.0f) : Vitesse des balles = 4 pixels par frame (à 60 FPS, ~240 pixels/s).
    // - bulletRange (80.0f) : Les balles parcourent 80 pixels avant de disparaître.
    // - maxAmmo (-1) : Munitions illimitées (pas de limite de chargeur).
    // - currentAmmo (-1) : Munitions actuelles illimitées (pas besoin de recharger).
    // - bulletsPerShot (1) : Tire 1 balle par coup (tir unique).
    // - spreadAngle (0.0f) : Pas de dispersion (balle va tout droit).

Weapon weapons[MAX_WEAPONS] = {
    {0, 0.4f, 4.0f, 70.0f, 0, 0, 1, 0.0f},    // Pistolet (0 au départ)
    {0, 0.2f, 4.0f, 100.0f, 200, 0, 1, 0.0f},  // Mitrailleuse (max 100, 0 au départ)
    {1, 0.8f, 3.5f, 100.0f, 80, 0, 3, 0.0f},    // Shotgun (max 40, 0 au départ)
    {2, 1.0f, 2.0f, 120.0f, 40, 0, 1, 45.0f}   // Grenade (max 20, 0 au départ)
};
u8 currentWeaponIndex = 0;

// Shooting mode variables
bool fireButtonReleased = true; // Tracks if fire button (BUTTON_B) is released
float fireTimer = 0.0f;        // Timer for fire rate
//timer float modeSwitchTimer = 0.0f;  // Timer for mode switch feedback
#define MODE_SWITCH_DISPLAY_TIME 2.0f
#define FIRE_RATE 0.4f         // Time between shots (seconds)

// Constants for explosions
#define MAX_EXPLOSIONS 5
#define EXPLOSION_DURATION 0.5f // Duration of explosion animation (seconds)
#define EXPLOSION_MAX_RADIUS 45.0f // Matches grenade explosionRadius

// Structure for an explosion effect
typedef struct {
    float x, y;          // Center of explosion
    bool active;         // Is the explosion active?
    float timer;         // Time remaining for animation
    float maxRadius;     // Maximum radius of explosion
} Explosion;

// Global array for explosions
Explosion explosions[MAX_EXPLOSIONS];

typedef struct {
    float x, y;         // Position
    float vx, vy;       // Vélocité
    float lifetime;     // Durée de vie restante (en secondes)
    bool active;        // Particule active ou non
    uint16_t color;     // Couleur (nuance de rouge)
} BloodParticle;

BloodParticle bloodParticles[MAX_BLOOD_PARTICLES];

// Structure pour un ennemi
typedef struct {
    float x, y;       // Position
    bool active;      // État actif/inactif
    bool isDead;      // État mort
    float deathTimer; // Timer pour frame de mort
    bool blinkState;  // État clignotement
    float blinkTimer; // Timer pour clignotement
    s8 direction;     // Direction
    s8 frame;         // Frame d'animation
    s8 frameDiv;      // Compteur pour animation
    s8 frmchange;     // Trigger pour changement de frame
    float fireTimer;  // Timer pour la cadence de tir
    // Recoil state
    bool isRecoiling; // Is the enemy in recoil animation
    float recoilTimer; // Time progress of recoil
    float recoilDuration; // Total duration of recoil animation
    s8 recoilDirection; // Direction of recoil (same as projectile)
    float recoilDistance; // Total distance to travel
    float recoilStartX; // X position at start of recoil
    float recoilStartY; // Y position at start of recoil
    // Random movement state
    bool isMovingRandomly; // Si l'ennemi bouge aléatoirement
    float randomMoveTimer; // Timer pour le mouvement aléatoire
    s8 randomDirection;   // Direction aléatoire choisie
      float animTimer;      // Timer pour l'animation (nouveau)
} Enemy;

// Tableau global pour les ennemis
Enemy enemies[MAX_ENEMIES];

// Structure pour un projectile
typedef struct {
    float x, y;
    s8 direction;     // Direction (0 to 7)
    bool active;
    float distanceTraveled; // Distance traveled
    u8 type;          // 0: Regular bullet, 1: Shotgun pellet, 2: Grenade
    float explosionRadius; // For grenades, radius of explosion
    u8 weaponIndex;   // Index de l'arme qui a tiré ce projectile
} Projectile;

// Structure pour les projectiles ennemis
typedef struct {
    float x, y;
    s8 direction;     // Direction (0 à 7)
    bool active;
    float distanceTraveled; // Distance parcourue
} EnemyProjectile;


typedef struct {
    s16 x, y;      // Position dans la carte (en coordonnées de tiles)
    u8 tileType;   // Type de tile collectible (ex. 9, 10, 11, 12)
    bool collected; // État : true si ramassé, false sinon
} Collectible;

Collectible collectibles[MAX_COLLECTIBLES];
u16 collectibleCount = 0; // Compteur de collectibles

// Tableau global pour les projectiles ennemis
EnemyProjectile enemyProjectiles[MAX_ENEMY_PROJECTILES];

// Projectiles
Projectile projectiles[MAX_PROJECTILES];

u8 OBJECTIFS[4]={0,0,0,0};

void INIT_OBJ_LVL(void){
for (u8 t=0;t<4;t++){
OBJECTIFS[t]=0;
	}
}

u8 SND_Chan=1;

void  SND_ouu(void) {
  switch  (rand() % 5) {
  case(0):PlaySoundChan(SND_Chan,ouu1,15042,0,1,1,SNDFORM_PCM,1);break;
  case(1):PlaySoundChan(SND_Chan,ouu2,21931,0,1,1,SNDFORM_PCM,1);break;
  case(2):PlaySoundChan(SND_Chan,ouu3,10925,0,1,1,SNDFORM_PCM,1);break;
  case(3):PlaySoundChan(SND_Chan,ouu4,21500,0,1,1,SNDFORM_PCM,1);break;
  case(4):PlaySoundChan(SND_Chan,ouu5,29546,0,1,1,SNDFORM_PCM,1);break;
  default:break;
}
SND_Chan=(SND_Chan<3)?SND_Chan+1:1;
}

void SND_SHOOT(void){
PlaySoundChan(SND_Chan,fire,1313,0,1,1,SNDFORM_PCM,1);
SND_Chan=(SND_Chan<3)?SND_Chan+1:1;
}

// Fonction pour créer une couleur RGB
__attribute__((always_inline)) inline uint16_t color(uint8_t R, uint8_t G, uint8_t B) {
    return ((R & 0x1F) << 11) | ((G & 0x3F) << 5) | (B & 0x1F);
}

void initExplosions() {
    for (int i = 0; i < MAX_EXPLOSIONS; i++) {
        explosions[i].active = false;
        explosions[i].timer = 0.0f;
        explosions[i].x = 0.0f;
        explosions[i].y = 0.0f;
        explosions[i].maxRadius = EXPLOSION_MAX_RADIUS;
    }
}

void initBloodParticles() {
    for (int i = 0; i < MAX_BLOOD_PARTICLES; i++) {
        bloodParticles[i].active = false;
        bloodParticles[i].x = 0.0f;
        bloodParticles[i].y = 0.0f;
        bloodParticles[i].vx = 0.0f;
        bloodParticles[i].vy = 0.0f;
        bloodParticles[i].lifetime = 0.0f;
        bloodParticles[i].color = color(31, 0, 0);
    }
}

// Initialiser les projectiles
void initProjectiles() {
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        projectiles[i].active = false;
        projectiles[i].distanceTraveled = 0.0f;
        projectiles[i].type = 0;
        projectiles[i].explosionRadius = 0.0f;
        projectiles[i].weaponIndex = 0;
    }
}

void switchWeaponY(bool checkAmmo) {
    if (checkAmmo && weapons[currentWeaponIndex].currentAmmo == 0 && weapons[currentWeaponIndex].maxAmmo != -1) {
        // Sauvegarder l'index de départ pour éviter une boucle infinie
        u8 startIndex = currentWeaponIndex;
        // Passer à l'arme précédente
        currentWeaponIndex = (currentWeaponIndex - 1 + MAX_WEAPONS) % MAX_WEAPONS;
        // Continuer à chercher une arme avec des munitions
        while (weapons[currentWeaponIndex].currentAmmo == 0 && weapons[currentWeaponIndex].maxAmmo != -1) {
            currentWeaponIndex = (currentWeaponIndex - 1 + MAX_WEAPONS) % MAX_WEAPONS;
            // Si on revient à l'index de départ, aucune arme n'a de munitions
            if (currentWeaponIndex == startIndex) {
                currentWeaponIndex = 0; // Revenir au pistolet par défaut
                break;
            }
        }
    } else {
        // Changement manuel d'arme
        currentWeaponIndex = (currentWeaponIndex - 1 + MAX_WEAPONS) % MAX_WEAPONS;
    }

    fireButtonReleased = true; // Réinitialiser pour éviter de bloquer le tir
    fireTimer = 0.0f; // Réinitialiser le timer de tir
}

void switchWeaponX(bool checkAmmo) {
    if (checkAmmo && weapons[currentWeaponIndex].currentAmmo == 0 && weapons[currentWeaponIndex].maxAmmo != -1) {
        // Sauvegarder l'index de départ pour éviter une boucle infinie
        u8 startIndex = currentWeaponIndex;
        // Passer à l'arme suivante
        currentWeaponIndex = (currentWeaponIndex + 1) % MAX_WEAPONS;
        // Continuer à chercher une arme avec des munitions
        while (weapons[currentWeaponIndex].currentAmmo == 0 && weapons[currentWeaponIndex].maxAmmo != -1) {
            currentWeaponIndex = (currentWeaponIndex + 1) % MAX_WEAPONS;
            // Si on revient à l'index de départ, aucune arme n'a de munitions
            if (currentWeaponIndex == startIndex) {
                currentWeaponIndex = 0; // Revenir au pistolet par défaut
                break;
            }
        }
    } else {
        // Changement manuel d'arme
        currentWeaponIndex = (currentWeaponIndex + 1) % MAX_WEAPONS;
    }

    fireButtonReleased = true; // Réinitialiser pour éviter de bloquer le tir
    fireTimer = 0.0f; // Réinitialiser le timer de tir
}

void initEnemyProjectiles() {
    for (int i = 0; i < MAX_ENEMY_PROJECTILES; i++) {
        enemyProjectiles[i].active = false;
        enemyProjectiles[i].distanceTraveled = 0.0f;
    }
}

// Initialiser les ennemis
void initEnemies(const uint8_t* level_) {
	enemyCount=0;
    for (int i = 0; i < MAX_ENEMIES; i++) {
        enemies[i].active = false;
        enemies[i].isDead = false;
        enemies[i].deathTimer = 0.0f;
        enemies[i].blinkState = true;
        enemies[i].blinkTimer = 0.0f;
        enemies[i].x = 0;
        enemies[i].y = 0;
        enemies[i].direction = 0;
        enemies[i].frame = 0;
        enemies[i].frameDiv = 0;
        enemies[i].fireTimer = 0.0f;
        enemies[i].isRecoiling = false;
        enemies[i].recoilTimer = 0.0f;
        enemies[i].recoilDuration = RECOIL_SPD;
        enemies[i].recoilDirection = 0;
        enemies[i].recoilDistance = RECOIL_DIST;
        enemies[i].recoilStartX = 0.0f;
        enemies[i].recoilStartY = 0.0f;
        enemies[i].isMovingRandomly = false;
        enemies[i].randomMoveTimer = 0.0f;
        enemies[i].randomDirection = 0;
    }

    for (s16 y = 0; y < level_[1]; y++) {
        for (s16 x = 0; x < level_[0]; x++) {
            if (level_[2 + (x + (y * level_[0]))] == 4) {
                if (enemyCount < MAX_ENEMIES) {
                    enemies[enemyCount].x = x * TILE_SIZE;
                    enemies[enemyCount].y = y * TILE_SIZE;
                    enemies[enemyCount].active = true;
                    enemies[enemyCount].direction = 0;
                    enemies[enemyCount].fireTimer = ENEMY_FIRE_RATE;
                    enemies[enemyCount].animTimer = 0.0f; // Initialiser pour chaque ennemi
                    enemyCount++;
                }
                
            }
        }
    }
}

// Vérifier les collisions entre projectiles du joueur et ennemis
__attribute__((always_inline)) inline void checkPlayerProjectileCollisions() {
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        if (projectiles[i].active) {
            for (int j = 0; j < MAX_ENEMIES; j++) {
                if (enemies[j].active && !enemies[j].isDead && !enemies[j].isRecoiling) {
                    if (projectiles[i].type == 2) {
                        // Grenade : Déclencher une explosion lors de la collision
                        float px = projectiles[i].x;
                        float py = projectiles[i].y;
                        float ex = enemies[j].x;
                        float ey = enemies[j].y;
                        if (px >= ex && px <= ex + PLAYER_W &&
                            py >= ey && py <= ey + PLAYER_H) {
                            // Créer une explosion
                            for (int k = 0; k < MAX_EXPLOSIONS; k++) {
                                if (!explosions[k].active) {
                                    explosions[k].x = projectiles[i].x;
                                    explosions[k].y = projectiles[i].y;
                                    explosions[k].active = true;
                                    explosions[k].timer = EXPLOSION_DURATION;
                                    explosions[k].maxRadius = projectiles[i].explosionRadius;
                                    break;
                                }
                            }
                            projectiles[i].active = false; // Désactiver la grenade
                            break;
                        }
                    } else {
                        // Projectile normal ou shotgun : Collision rectangulaire
                        float px = projectiles[i].x;
                        float py = projectiles[i].y;
                        float ex = enemies[j].x;
                        float ey = enemies[j].y;
                        if (px >= ex && px <= ex + PLAYER_W &&
                            py >= ey && py <= ey + PLAYER_H) {
                            if (!enemies[j].isRecoiling) {
                                SND_ouu();
                                enemyKillCount++;
                            }
                            enemies[j].isRecoiling = true;
                            enemies[j].recoilTimer = 0.0f;
                            enemies[j].recoilDirection = projectiles[i].direction;
                            enemies[j].recoilStartX = enemies[j].x;
                            enemies[j].recoilStartY = enemies[j].y;
                            enemies[j].isDead = true;
                            enemies[j].deathTimer = DEATHTIMER;
                            enemies[j].blinkTimer = BLINKTIMER;
                            enemies[j].blinkState = true;
                            enemies[j].frame = 3;
                            projectiles[i].active = false;

                            // Générer des particules de sang
                            for (int k = 0; k < BLOODPARTICLES; k++) { //  particules par impact
                                for (int m = 0; m < MAX_BLOOD_PARTICLES; m++) {
                                    if (!bloodParticles[m].active) {
                                        bloodParticles[m].x = enemies[j].x + PLAYER_W / 2;
                                        bloodParticles[m].y = enemies[j].y + PLAYER_H / 2;
                                        // Vélocité aléatoire
                                        float angle = (float)(rand() % 360) * M_PI / 180.0f;
                                        float speed = 20.0f + (float)(rand() % 20); // Vitesse entre 20 et 40
                                        bloodParticles[m].vx = cosf(angle) * speed;
                                        bloodParticles[m].vy = sinf(angle) * speed;
                                        bloodParticles[m].lifetime = BLT + (float)(rand() % 100) / 200.0f; // 0.5 à 1s
                                        bloodParticles[m].color = color(31 - (rand() % 15), 0, 0); // Nuances de rouge
                                        bloodParticles[m].active = true;
                                        break;
                                    }
                                }
                            }

                            break;
                        }
                    }
                }
            }
        }
    }
}

// Vérifier les collisions entre projectiles ennemis et joueur
__attribute__((always_inline)) inline void checkEnemyProjectileCollisions() {
    if (!playerAlive || playerIsDead || playerIsRecoiling) return;

    for (int i = 0; i < MAX_ENEMY_PROJECTILES; i++) {
        if (enemyProjectiles[i].active) {
            float px = enemyProjectiles[i].x;
            float py = enemyProjectiles[i].y;
            float playerLeft = playerX;
            float playerRight = playerX + PLAYER_W;
            float playerTop = playerY;
            float playerBottom = playerY + PLAYER_H;

            if (px >= playerLeft && px <= playerRight &&
                py >= playerTop && py <= playerBottom) {
                if (MetalJacket != 0) {
                    MetalJacket--;
                    if (playerIsRecoiling == false) SND_ouu();
                    playerIsRecoiling = true;
                    playerRecoilTimer = 0.0f;
                    playerRecoilDirection = enemyProjectiles[i].direction;
                    playerRecoilStartX = playerX;
                    playerRecoilStartY = playerY;
                    playerDeathTimer = DEATHTIMER;
                    playerBlinkTimer = BLINKTIMER;
                    playerBlinkState = true;
                    enemyProjectiles[i].active = false;

                    // Générer des particules de sang
                    for (int j = 0; j < BLOODPARTICLES; j++) { // particules par impact
                        for (int k = 0; k < MAX_BLOOD_PARTICLES; k++) {
                            if (!bloodParticles[k].active) {
                                bloodParticles[k].x = playerX + PLAYER_W / 2;
                                bloodParticles[k].y = playerY + PLAYER_H / 2;
                                // Vélocité aléatoire
                                float angle = (float)(rand() % 360) * M_PI / 180.0f;
                                float speed = 20.0f + (float)(rand() % 20); // Vitesse entre 20 et 40
                                bloodParticles[k].vx = cosf(angle) * speed;
                                bloodParticles[k].vy = sinf(angle) * speed;
                                bloodParticles[k].lifetime = BLT + (float)(rand() % 100) / 200.0f; // 0.5 à 1s
                                bloodParticles[k].color = color(31 - (rand() % 15), 0, 0); // Nuances de rouge
                                bloodParticles[k].active = true;
                                break;
                            }
                        }
                    }

                    break;
                } else {
                    if (playerIsRecoiling == false) SND_ouu();
                    playerIsRecoiling = true;
                    playerRecoilTimer = 0.0f;
                    playerRecoilDirection = enemyProjectiles[i].direction;
                    playerRecoilStartX = playerX;
                    playerRecoilStartY = playerY;
                    playerIsDead = true;
                    playerDeathTimer = DEATHTIMER;
                    playerBlinkTimer = BLINKTIMER;
                    playerBlinkState = true;
                    frm_Main_Soldier = 3;
                    enemyProjectiles[i].active = false;

                    // Générer des particules de sang
                    for (int j = 0; j < 5; j++) {
                        for (int k = 0; k < MAX_BLOOD_PARTICLES; k++) {
                            if (!bloodParticles[k].active) {
                                bloodParticles[k].x = playerX + PLAYER_W / 2;
                                bloodParticles[k].y = playerY + PLAYER_H / 2;
                                float angle = (float)(rand() % 360) * M_PI / 180.0f;
                                float speed = 20.0f + (float)(rand() % 20);
                                bloodParticles[k].vx = cosf(angle) * speed;
                                bloodParticles[k].vy = sinf(angle) * speed;
                                bloodParticles[k].lifetime = BLT + (float)(rand() % 100) / 200.0f;
                                bloodParticles[k].color = color(31 - (rand() % 5), 0, 0);
                                bloodParticles[k].active = true;
                                break;
                            }
                        }
                    }

                    break;
                }
            }
        }
    }
}

__attribute__((always_inline)) inline void checkExplosionCollisions() {
    for (int i = 0; i < MAX_EXPLOSIONS; i++) {
        if (explosions[i].active) {
            // Calculer le rayon actuel de l'explosion (basé sur le temps restant)
            float t = explosions[i].timer / EXPLOSION_DURATION;
            float currentRadius = explosions[i].maxRadius * (1.0f - t); // Rayon croissant

            for (int j = 0; j < MAX_ENEMIES; j++) {
                if (enemies[j].active && !enemies[j].isDead && !enemies[j].isRecoiling) {
                    // Calculer la distance entre le centre de l'explosion et l'ennemi
                    float dx = enemies[j].x + PLAYER_W / 2 - explosions[i].x;
                    float dy = enemies[j].y + PLAYER_H / 2 - explosions[i].y;
                    float distance = sqrtf(dx * dx + dy * dy);

                    // Si l'ennemi est dans le rayon de l'explosion
                    if (distance <= currentRadius) {
                        // Appliquer les effets de la mort
                        if (!enemies[j].isRecoiling) {
                            SND_ouu();
                            enemyKillCount++;
                        }
                        enemies[j].isRecoiling = true;
                        enemies[j].recoilTimer = 0.0f;
                        // Déterminer la direction du recul (basée sur la position relative)
                        s8 recoilDirection = 0;
                        float angle = atan2f(dy, dx);
                        if (angle < 0) angle += 2 * M_PI; // Normaliser l'angle
                        recoilDirection = (s8)((angle * 8.0f) / (2 * M_PI)) % 8;
                        enemies[j].recoilDirection = recoilDirection;
                        enemies[j].recoilStartX = enemies[j].x;
                        enemies[j].recoilStartY = enemies[j].y;
                        enemies[j].isDead = true;
                        enemies[j].deathTimer = DEATHTIMER;
                        enemies[j].blinkTimer = BLINKTIMER;
                        enemies[j].blinkState = true;
                        enemies[j].frame = 3;

                        // Générer des particules de sang
                        for (int k = 0; k < BLOODPARTICLES; k++) { // particules par impact
                            for (int m = 0; m < MAX_BLOOD_PARTICLES; m++) {
                                if (!bloodParticles[m].active) {
                                    bloodParticles[m].x = enemies[j].x + PLAYER_W / 2;
                                    bloodParticles[m].y = enemies[j].y + PLAYER_H / 2;
                                    float angle = (float)(rand() % 360) * M_PI / 180.0f;
                                    float speed = 20.0f + (float)(rand() % 20);
                                    bloodParticles[m].vx = cosf(angle) * speed;
                                    bloodParticles[m].vy = sinf(angle) * speed;
                                    bloodParticles[m].lifetime = BLT + (float)(rand() % 100) / 200.0f;
                                    bloodParticles[m].color = color(31 - (rand() % 5), 0, 0);
                                    bloodParticles[m].active = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Apply recoil animation
__attribute__((always_inline)) inline void applyRecoil(float *x, float *y, bool *isRecoiling, float *recoilTimer, float recoilDuration, s8 recoilDirection, float recoilDistance, float dt, const uint8_t* level) {
    if (!*isRecoiling) return;

    bool isPlayer = (*x == playerX && *y == playerY);
    Enemy *enemy = NULL;
    if (!isPlayer) {
        for (int i = 0; i < MAX_ENEMIES; i++) {
            if (enemies[i].x == *x && enemies[i].y == *y && enemies[i].isRecoiling) {
                enemy = &enemies[i];
                break;
            }
        }
        if (!enemy) {
            *isRecoiling = false;
            return;
        }
    }

    *recoilTimer += dt;
    float t = *recoilTimer / recoilDuration;
    if (t >= 1.0f) {
        *isRecoiling = false;
        *recoilTimer = 0.0f;
        if (isPlayer) {
            frm_Main_Soldier = 4;
        } else {
            enemy->frame = 4;
        }
        return;
    }

    if (isPlayer) {
        frm_Main_Soldier = 3;
    } else {
        enemy->frame = 3;
    }

    float deltaX = 0.0f;
    float deltaY = 0.0f;
    float distance = t * recoilDistance;
    if (distance > recoilDistance) distance = recoilDistance;

    switch (recoilDirection) {
        case 0: deltaX = distance; break;
        case 1: deltaX = distance * 0.707f; deltaY = -distance * 0.707f; break;
        case 2: deltaY = -distance; break;
        case 3: deltaX = -distance * 0.707f; deltaY = -distance * 0.707f; break;
        case 4: deltaX = -distance; break;
        case 5: deltaX = -distance * 0.707f; deltaY = distance * 0.707f; break;
        case 6: deltaY = distance; break;
        case 7: deltaX = distance * 0.707f; deltaY = distance * 0.707f; break;
    }

    float newX, newY;
    if (isPlayer) {
        newX = playerRecoilStartX + deltaX;
        newY = playerRecoilStartY + deltaY;
        
            if (isPositionValid(newX, playerY, Level_Use)) {
        *x = newX;
    }
    if (isPositionValid(playerX, newY, Level_Use)) {
        *y = newY;
    }

	
    } else {
        newX = enemy->recoilStartX + deltaX;
        newY = enemy->recoilStartY + deltaY;
        *x = newX;
    *y = newY;
    }


}

// Fonction pour générer une direction aléatoire
__attribute__((always_inline)) inline s8 getRandomDirection() {
    return rand() % 8; // Retourne une direction entre 0 et 7
}

// Mettre à jour les ennemis
__attribute__((always_inline)) inline void updateEnemies(float dt) {
    for (int i = 0; i < MAX_ENEMIES; i++) {
        if (enemies[i].active) {
            if (enemies[i].isDead) {
                enemies[i].deathTimer -= dt;
                enemies[i].blinkTimer -= dt;

                if (enemies[i].deathTimer <= HALFDEATHTIMER) {
                    if (enemies[i].blinkTimer <= 0.0f) {
                        enemies[i].blinkState = !enemies[i].blinkState;
                        enemies[i].blinkTimer = BLINKTIMER;
                    }
                }

                applyRecoil(&enemies[i].x, &enemies[i].y, &enemies[i].isRecoiling, &enemies[i].recoilTimer, enemies[i].recoilDuration, enemies[i].recoilDirection, enemies[i].recoilDistance, dt, Level_Use);

                if (enemies[i].deathTimer <= 0.0f) {
                    enemies[i].active = false;
                    enemies[i].isDead = false;
                    enemies[i].isRecoiling = false;
                }
                continue;
            }

            if (enemies[i].isRecoiling) {
                applyRecoil(&enemies[i].x, &enemies[i].y, &enemies[i].isRecoiling, &enemies[i].recoilTimer, enemies[i].recoilDuration, enemies[i].recoilDirection, enemies[i].recoilDistance, dt, Level_Use);
                continue;
            }

            s16 screenX = (s16)(enemies[i].x - cameraX);
            s16 screenY = (s16)(enemies[i].y - cameraY);
            if (screenX >= -PLAYER_W && screenX <= SCREEN_WIDTH + PLAYER_W &&
                screenY >= -PLAYER_H && screenY <= SCREEN_HEIGHT + PLAYER_H) {
                s8 joyDirection = 0;

                float dx = playerX - enemies[i].x;
                float dy = playerY - enemies[i].y;
                float distance = sqrtf(dx * dx + dy * dy);

                if (enemies[i].isMovingRandomly) {
                    enemies[i].randomMoveTimer -= dt;
                    if (enemies[i].randomMoveTimer <= 0.0f) {
                        enemies[i].isMovingRandomly = false;
                    } else {
                        joyDirection = enemies[i].randomDirection;
                    }
                } else if (distance <= MIN_DISTANCE_TO_PLAYER) {
                    enemies[i].isMovingRandomly = true;
                    enemies[i].randomMoveTimer = RANDOM_MOVE_DURATION;
                    enemies[i].randomDirection = getRandomDirection();
                    joyDirection = enemies[i].randomDirection;
                } else {
                    if (dx > 5 || dx < -5) {
                        if (dx > 0) joyDirection |= RIGHT;
                        else joyDirection |= LEFT;
                    }
                    if (dy > 5 || dy < -5) {
                        if (dy > 0) joyDirection |= DOWN;
                        else joyDirection |= UP;
                    }
                }

                float newX = enemies[i].x;
                float newY = enemies[i].y;
                float moveStep = MOVE_STEP_ENNEMIS;

                // Normalisation pour les mouvements diagonaux
                if ((joyDirection & (LEFT | RIGHT)) && (joyDirection & (UP | DOWN))) {
                    moveStep *= 0.707f; // Réduire la vitesse en diagonale (1/√2)
                }

                if (joyDirection & RIGHT) newX += moveStep;
                if (joyDirection & LEFT) newX -= moveStep;
                if (joyDirection & DOWN) newY += moveStep;
                if (joyDirection & UP) newY -= moveStep;

                if (isPositionValid(newX, enemies[i].y, Level_Use)) {
                    enemies[i].x = newX;
                    enemies[i].frmchange = 1;
                }
                if (isPositionValid(enemies[i].x, newY, Level_Use)) {
                    enemies[i].y = newY;
                    enemies[i].frmchange = 1;
                }

                if (!enemies[i].isRecoiling) {
                    switch (joyDirection) {
                        case UP: enemies[i].direction = 2; break;
                        case DOWN: enemies[i].direction = 6; break;
                        case LEFT: enemies[i].direction = 4; break;
                        case RIGHT: enemies[i].direction = 0; break;
                        case UP | LEFT: enemies[i].direction = 3; break;
                        case UP | RIGHT: enemies[i].direction = 1; break;
                        case DOWN | LEFT: enemies[i].direction = 5; break;
                        case DOWN | RIGHT: enemies[i].direction = 7; break;
                        default: break;
                    }
                }

                enemies[i].fireTimer -= dt;
                if (enemies[i].fireTimer <= 0.0f && distance < SHOOT_DISTANCE && enemies[i].direction >= 0 && enemies[i].direction <= 7) {
                    for (int j = 0; j < MAX_ENEMY_PROJECTILES; j++) {
                        if (!enemyProjectiles[j].active) {
                            float offsetX = 0.0f;
                            float offsetY = 0.0f;
                            switch (enemies[i].direction) {
                                case 0: offsetX = 28; offsetY = 20; break;
                                case 1: offsetX = 28; offsetY = 9; break;
                                case 2: offsetX = 20; offsetY = 1; break;
                                case 3: offsetX = 9; offsetY = 1; break;
                                case 4: offsetX = 1; offsetY = 9; break;
                                case 5: offsetX = 1; offsetY = 20; break;
                                case 6: offsetX = 9; offsetY = 28; break;
                                case 7: offsetX = 20; offsetY = 28; break;
                            }
                            enemyProjectiles[j].x = enemies[i].x + offsetX;
                            enemyProjectiles[j].y = enemies[i].y + offsetY;
                            enemyProjectiles[j].direction = enemies[i].direction;
                            enemyProjectiles[j].active = true;
                            SND_SHOOT();
                            enemyProjectiles[j].distanceTraveled = 0.0f;
                            enemies[i].fireTimer = ENEMY_FIRE_RATE;
                            break;
                        }
                    }
                }
            }
        }
    }
}

// Mettre à jour les projectiles ennemis
__attribute__((always_inline)) inline void updateEnemyProjectiles(float dt) {
    for (int i = 0; i < MAX_ENEMY_PROJECTILES; i++) {
        if (enemyProjectiles[i].active) {
            float deltaX = 0.0f;
            float deltaY = 0.0f;
            float distanceStep = PROJECTILE_STEP; // Consistent step for all directions
            switch (enemyProjectiles[i].direction) {
                case 0: deltaX = PROJECTILE_STEP; break; // Right
                case 1: deltaX = PROJECTILE_STEP * 0.707f; deltaY = -PROJECTILE_STEP * 0.707f; break; // Up-Right
                case 2: deltaY = -PROJECTILE_STEP; break; // Up
                case 3: deltaX = -PROJECTILE_STEP * 0.707f; deltaY = -PROJECTILE_STEP * 0.707f; break; // Up-Left
                case 4: deltaX = -PROJECTILE_STEP; break; // Left
                case 5: deltaX = -PROJECTILE_STEP * 0.707f; deltaY = PROJECTILE_STEP * 0.707f; break; // Down-Left
                case 6: deltaY = PROJECTILE_STEP; break; // Down
                case 7: deltaX = PROJECTILE_STEP * 0.707f; deltaY = PROJECTILE_STEP * 0.707f; break; // Down-Right
            }
            enemyProjectiles[i].x += deltaX;
            enemyProjectiles[i].y += deltaY;
            enemyProjectiles[i].distanceTraveled += distanceStep;

            if (enemyProjectiles[i].x < 0 || enemyProjectiles[i].x > Level_Use[0] * TILE_SIZE ||
                enemyProjectiles[i].y < 0 || enemyProjectiles[i].y > Level_Use[1] * TILE_SIZE ||
                enemyProjectiles[i].distanceTraveled > MAX_PROJECTILE_DISTANCE) {
                enemyProjectiles[i].active = false;
            }
        }
    }
}

// Dessiner les projectiles ennemis
__attribute__((always_inline)) inline void drawEnemyProjectiles() {
    for (int i = 0; i < MAX_ENEMY_PROJECTILES; i++) {
        if (enemyProjectiles[i].active) {
            s16 screenX = (s16)(enemyProjectiles[i].x - cameraX);
            s16 screenY = (s16)(enemyProjectiles[i].y - cameraY);
            DrawFillCircle(screenX, screenY, 2, color(31, 0, 0));
        }
    }
}

// Dessiner les ennemis
__attribute__((always_inline)) inline void drawEnemies() {
    for (int i = 0; i < MAX_ENEMIES; i++) {
        if (enemies[i].active) {
            if (enemies[i].isDead && enemies[i].deathTimer <= HALFDEATHTIMER && !enemies[i].blinkState) {
                continue;
            }
            s16 screenX = (s16)(enemies[i].x - cameraX);
            s16 screenY = (s16)(enemies[i].y - cameraY);
            if (screenX >= -PLAYER_W && screenX <= SCREEN_WIDTH + PLAYER_W &&
                screenY >= -PLAYER_H && screenY <= SCREEN_HEIGHT + PLAYER_H) {
                s8 frame = enemies[i].frame;
                DrawBlitPal(soldier2, soldier2_Pal,
                            (frame * PLAYER_W), enemies[i].direction * PLAYER_H,
                            screenX, screenY,
                            PLAYER_W, PLAYER_H,
                            soldier2_W_FULL, COL_WHITE);
            }
        }
    }
}

__attribute__((always_inline)) inline void RecupSPK(void) {
    float playerLeft = playerX;
    float playerRight = playerX + PLAYER_W;
    float playerTop = playerY;
    float playerBottom = playerY + PLAYER_H;

    for (u16 i = 0; i < collectibleCount; i++) {
        if (!collectibles[i].collected) {
            // Calculer la boîte de collision du collectible
            float collectibleLeft = (float)(collectibles[i].x * TILE_SIZE) + MARGE_DE_DETECTION[collectibles[i].tileType];
            float collectibleRight = (float)(collectibles[i].x * TILE_SIZE) + SPK_W[collectibles[i].tileType] - MARGE_DE_DETECTION[collectibles[i].tileType];
            float collectibleTop = (float)(collectibles[i].y * TILE_SIZE) + MARGE_DE_DETECTION[collectibles[i].tileType];
            float collectibleBottom = (float)(collectibles[i].y * TILE_SIZE) + SPK_H[collectibles[i].tileType] - MARGE_DE_DETECTION[collectibles[i].tileType];

            // Vérifier le chevauchement des boîtes
            if (playerLeft < collectibleRight && playerRight > collectibleLeft &&
                playerTop < collectibleBottom && playerBottom > collectibleTop) {
                collectibles[i].collected = true; // Marquer comme ramassé
                // Ajouter des munitions ou des effets
                switch (collectibles[i].tileType) {
					
					case 18:OBJECTIFS[1]+=1;break;
					case 19:OBJECTIFS[2]+=1;break;
					case 20:OBJECTIFS[3]+=1;break;
					
				    case 15: // Jacket (Protection temporaire)
                        MetalJacket+=5;
                        if (MetalJacket>5) {
                          MetalJacket=5;
                        }
                        break; 
                    case 10: // Amo1 (pour mitrailleuse)
                        weapons[1].currentAmmo += 50;
                        if (weapons[1].currentAmmo > weapons[1].maxAmmo) {
                            weapons[1].currentAmmo = weapons[1].maxAmmo;
                        }
                        break;
                    case 11: // Amo2 (pour shotgun)
                        weapons[2].currentAmmo += 20;
                        if (weapons[2].currentAmmo > weapons[2].maxAmmo) {
                            weapons[2].currentAmmo = weapons[2].maxAmmo;
                        }
                        break;
                    case 12: // Amo3 (pour grenade)
                        weapons[3].currentAmmo += 5;
                        if (weapons[3].currentAmmo > weapons[3].maxAmmo) {
                            weapons[3].currentAmmo = weapons[3].maxAmmo;
                        }
                        break;
                    case 9: // Amo0 (pour pistolet)
                        weapons[0].maxAmmo = -1; // Munitions illimitées
                        weapons[0].currentAmmo = -1;
                        break;
                }
                // Jouer un son pour indiquer la collecte
                PlaySoundChan(SND_Chan, pickup, 7947, 0, 1, 1, SNDFORM_PCM, 1);
                SND_Chan = (SND_Chan < 3) ? SND_Chan + 1 : 1;
                break; // Sortir après avoir ramassé un collectible
            }
        }
    }
}

// Vérifie si une position est valide avec collision rectangulaire
bool isPositionValid(float x, float y, const uint8_t* level) {
    float playerLeft = x;
    float playerRight = x + PLAYER_W;
    float playerTop = y;
    float playerBottom = y + PLAYER_H;

    float mapWidth = level[0] * TILE_SIZE;
    float mapHeight = level[1] * TILE_SIZE;

    if (playerLeft < 0 || playerRight > mapWidth ||
        playerTop < 0 || playerBottom > mapHeight) {
        return false;
    }

    s16 centerTileX = (s16)(x / TILE_SIZE);
    s16 centerTileY = (s16)(y / TILE_SIZE);

    s16 startX = centerTileX - 4;
    s16 endX = centerTileX + 4;
    s16 startY = centerTileY - 4;
    s16 endY = centerTileY + 4;

    if (startX < 0) startX = 0;
    if (startY < 0) startY = 0;
    if (endX >= level[0]) endX = level[0] - 1;
    if (endY >= level[1]) endY = level[1] - 1;

    for (s16 gy = startY; gy <= endY; gy++) {
        for (s16 gx = startX; gx <= endX; gx++) {
            uint8_t tile = level[2 + (gx + (gy * level[0]))];
            if (tile > 0 && tile != 4 && tile!=14) {
                float sapinLeft = (float)(gx * TILE_SIZE) + MARGE_DE_DETECTION[tile];
                float sapinRight = (float)(gx * TILE_SIZE) + SPK_W[tile] - MARGE_DE_DETECTION[tile];
                float sapinTop = (float)(gy * TILE_SIZE) + MARGE_DE_DETECTION[tile];
                float sapinBottom = (float)(gy * TILE_SIZE) + SPK_H[tile] - MARGE_DE_DETECTION[tile];

                if (playerLeft < sapinRight && playerRight > sapinLeft &&
                    playerTop < sapinBottom && playerBottom > sapinTop) {
  if (SpkCollectible[tile]) {
        // Les collectibles sont traversables, donc on continue la boucle
        continue; // Passe au tile suivant sans bloquer
    } else {
        return false; // Objet non collectible, bloque le joueur
    }

                   
                }
            }
        }
    }
    return true;
}

// Tirer un projectile
__attribute__((always_inline)) inline void shootProjectile() {
    // Vérifier si on peut tirer
    if (fireTimer > 0.0f || !BUTTON_B) {
        return;
    }

    Weapon *weapon = &weapons[currentWeaponIndex];

    // Si aucune arme n'a de munitions et le pistolet n'est pas illimité, ne pas tirer
    if (weapon->currentAmmo == 0 && weapon->maxAmmo != -1) {
        bool hasAmmo = false;
        for (int i = 0; i < MAX_WEAPONS; i++) {
            if (weapons[i].currentAmmo > 0 || weapons[i].maxAmmo == -1) {
                hasAmmo = true;
                break;
            }
        }
        if (!hasAmmo) {
            return; // Bloquer le tir si aucune arme n'a de munitions
        }
        switchWeaponX(true); // Passer à l'arme suivante si plus de munitions
        return;
    }

    // Exiger le relâchement du bouton pour le pistolet (index 0) et le shotgun (type 1)
    if ((currentWeaponIndex == 0 && weapon->type == 0 && weapon->pellets == 1) || weapon->type == 1) {
        if (!fireButtonReleased) {
            return;
        }
    }

    s8 shootDirection = isFireDirectionLocked ? lockedFireDirection : Soldier_Direction;
    float offsetX = 0.0f, offsetY = 0.0f;
    switch (shootDirection) {
        case 0: offsetX = 28; offsetY = 20; break;
        case 1: offsetX = 28; offsetY = 9; break;
        case 2: offsetX = 20; offsetY = 1; break;
        case 3: offsetX = 9; offsetY = 1; break;
        case 4: offsetX = 1; offsetY = 9; break;
        case 5: offsetX = 1; offsetY = 20; break;
        case 6: offsetX = 9; offsetY = 28; break;
        case 7: offsetX = 20; offsetY = 28; break;
    }

    int projectilesFired = 0;
    if (weapon->type == 1) {
        // Shotgun : Tirer plusieurs projectiles avec dispersion
        for (int i = 0; i < MAX_PROJECTILES && projectilesFired < weapon->pellets; i++) {
            if (!projectiles[i].active) {
                projectiles[i].x = playerX + offsetX;
                projectiles[i].y = playerY + offsetY;
                s8 spreadDirection = shootDirection;
                if (projectilesFired == 0) {
                    spreadDirection = (shootDirection - 1) & 7; // Dispersion gauche
                } else if (projectilesFired == 2) {
                    spreadDirection = (shootDirection + 1) & 7; // Dispersion droite
                }
                projectiles[i].direction = spreadDirection;
                projectiles[i].active = true;
                projectiles[i].type = weapon->type;
                projectiles[i].distanceTraveled = 0.0f;
                projectiles[i].weaponIndex = currentWeaponIndex;
                projectilesFired++;
            }
        }
    } else {
        // Autres armes : Tirer un seul projectile
        for (int i = 0; i < MAX_PROJECTILES; i++) {
            if (!projectiles[i].active) {
                projectiles[i].x = playerX + offsetX;
                projectiles[i].y = playerY + offsetY;
                projectiles[i].direction = shootDirection;
                projectiles[i].active = true;
                projectiles[i].type = weapon->type;
                projectiles[i].distanceTraveled = 0.0f;
                projectiles[i].explosionRadius = weapon->explosionRadius;
                projectiles[i].weaponIndex = currentWeaponIndex;
                projectilesFired++;
                break;
            }
        }
    }

    if (projectilesFired > 0) {
        SND_SHOOT();
        fireTimer = weapon->fireRate;
        // Réinitialiser fireButtonReleased pour le pistolet (index 0) et le shotgun (type 1)
        if ((currentWeaponIndex == 0 && weapon->type == 0 && weapon->pellets == 1) || weapon->type == 1) {
            fireButtonReleased = false;
        }
        // Réduire les munitions
        if (weapon->maxAmmo != -1) {
            weapon->currentAmmo--;
        }
    }
}

__attribute__((always_inline)) inline void updateBloodParticles(float dt) {
    for (int i = 0; i < MAX_BLOOD_PARTICLES; i++) {
        if (bloodParticles[i].active) {
            // Mettre à jour la position
            bloodParticles[i].x += bloodParticles[i].vx * dt;
            bloodParticles[i].y += bloodParticles[i].vy * dt;
            // Réduire la durée de vie
            bloodParticles[i].lifetime -= dt;
            // Appliquer une légère décélération (optionnel)
            bloodParticles[i].vx *= 0.95f;
            bloodParticles[i].vy *= 0.95f;
            // Désactiver si la durée de vie est écoulée
            if (bloodParticles[i].lifetime <= 0.0f) {
                bloodParticles[i].active = false;
            }
        }
    }
}

// Mettre à jour les projectiles
__attribute__((always_inline)) inline void updateProjectiles(float dt) {
    if (fireTimer > 0.0f) {
        fireTimer -= dt;
        if (fireTimer < 0.0f) fireTimer = 0.0f;
    }

    int activeProjectiles = 0;
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        if (projectiles[i].active) {
            activeProjectiles++;
            Weapon *weapon = &weapons[projectiles[i].weaponIndex];
            float deltaX = 0.0f;
            float deltaY = 0.0f;
            float distanceStep = weapon->projectileSpeed;
            switch (projectiles[i].direction) {
                case 0: deltaX = weapon->projectileSpeed; break;
                case 1: deltaX = weapon->projectileSpeed * 0.707f; deltaY = -weapon->projectileSpeed * 0.707f; break;
                case 2: deltaY = -weapon->projectileSpeed; break;
                case 3: deltaX = -weapon->projectileSpeed * 0.707f; deltaY = -weapon->projectileSpeed * 0.707f; break;
                case 4: deltaX = -weapon->projectileSpeed; break;
                case 5: deltaX = -weapon->projectileSpeed * 0.707f; deltaY = weapon->projectileSpeed * 0.707f; break;
                case 6: deltaY = weapon->projectileSpeed; break;
                case 7: deltaX = weapon->projectileSpeed * 0.707f; deltaY = weapon->projectileSpeed * 0.707f; break;
            }
            projectiles[i].x += deltaX;
            projectiles[i].y += deltaY;
            projectiles[i].distanceTraveled += distanceStep;

            if (projectiles[i].x < 0 || projectiles[i].x > Level_Use[0] * TILE_SIZE ||
                projectiles[i].y < 0 || projectiles[i].y > Level_Use[1] * TILE_SIZE ||
                projectiles[i].distanceTraveled > weapon->maxDistance) {
                if (projectiles[i].type == 2) {
                    // Créer une explosion pour la grenade
                PlaySoundChan(SND_Chan, explod, 15485, 0, 1, 1, SNDFORM_PCM, 1);
                 SND_Chan = (SND_Chan < 3) ? SND_Chan + 1 : 1;
                    for (int j = 0; j < MAX_EXPLOSIONS; j++) {
                        if (!explosions[j].active) {
                            explosions[j].x = projectiles[i].x;
                            explosions[j].y = projectiles[i].y;
                            explosions[j].active = true;
                            explosions[j].timer = EXPLOSION_DURATION;
                            explosions[j].maxRadius = projectiles[i].explosionRadius;
                            break;
                        }
                    }
                }
                projectiles[i].active = false;
            }
        }
    }
}




__attribute__((always_inline)) inline void updateExplosions(float dt) {
    for (int i = 0; i < MAX_EXPLOSIONS; i++) {
        if (explosions[i].active) {
            explosions[i].timer -= dt;
            if (explosions[i].timer <= 0.0f) {
                explosions[i].active = false;
            }
        }
    }
}

__attribute__((always_inline)) inline void drawExplosions() {
    for (int i = 0; i < MAX_EXPLOSIONS; i++) {
        if (explosions[i].active) {
            s16 screenX = (s16)(explosions[i].x - cameraX);
            s16 screenY = (s16)(explosions[i].y - cameraY);
            // Calculate current radius and alpha based on timer
            float t = explosions[i].timer / EXPLOSION_DURATION;
            float radius = explosions[i].maxRadius * (1.0f - t); // Expand from 0 to maxRadius

            // Draw multiple circles for a layered effect
            DrawCircle(screenX, screenY, (s16)(radius * 0.5f), color(31,5, 0)); // Inner bright circle
            DrawCircle(screenX, screenY, (s16)radius, color(31, 40, 0)); // Outer dim circle
        }
    }
}

__attribute__((always_inline)) inline void drawBloodParticles() {
    for (int i = 0; i < MAX_BLOOD_PARTICLES; i++) {
        if (bloodParticles[i].active) {
            s16 screenX = (s16)(bloodParticles[i].x - cameraX);
            s16 screenY = (s16)(bloodParticles[i].y - cameraY);
            // Vérifier que la particule est à l'écran
            if (screenX >= 0 && screenX < SCREEN_WIDTH && screenY >= 0 && screenY < SCREEN_HEIGHT) {
                DrawFillCircle(screenX, screenY, 2, bloodParticles[i].color); // Cercle de rayon 1
            }
        }
    }
}

// Dessiner les projectiles
__attribute__((always_inline)) inline void drawProjectiles() {
    bool debugDisplayed = false;
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        if (projectiles[i].active) {
            s16 screenX = (s16)(projectiles[i].x - cameraX);
            s16 screenY = (s16)(projectiles[i].y - cameraY);
            if (projectiles[i].type == 2) {
                // Grenade: Larger, different color
                DrawFillCircle(screenX, screenY, 4, color(31, 10, 0));
            } else {
                // Regular bullet or shotgun pellet
                DrawFillCircle(screenX, screenY, 2, color(31, 31, 0));
            }

        }
    }
}

// Met à jour la position du joueur
__attribute__((always_inline)) inline void updatePlayerPosition(float dt) {
    if (playerIsDead) {
        playerDeathTimer -= dt;
        playerBlinkTimer -= dt;

        if (playerDeathTimer <= HALFDEATHTIMER) {
            if (playerBlinkTimer <= 0.0f) {
                playerBlinkState = !playerBlinkState;
                playerBlinkTimer = 0.1f;
            }
        }

        applyRecoil(&playerX, &playerY, &playerIsRecoiling, &playerRecoilTimer, playerRecoilDuration, playerRecoilDirection, playerRecoilDistance, dt, Level_Use);

        if (playerDeathTimer <= 0.0f) {
            playerAlive = false;
            playerIsDead = false;
            playerIsRecoiling = false;
        }
        return;
    }

    if (playerIsRecoiling) {
        applyRecoil(&playerX, &playerY, &playerIsRecoiling, &playerRecoilTimer, playerRecoilDuration, playerRecoilDirection, playerRecoilDistance, dt, Level_Use);
        return;
    }

    Soldier_Joy_Direction = 0;

    if (TINYJOYPAD_LEFT) {
        Soldier_Joy_Direction |= LEFT;
    }
    if (TINYJOYPAD_RIGHT) {
        Soldier_Joy_Direction |= RIGHT;
    }
    if (TINYJOYPAD_UP) {
        Soldier_Joy_Direction |= UP;
    }
    if (TINYJOYPAD_DOWN) {
        Soldier_Joy_Direction |= DOWN;
    }

    float newX = playerX;
    float newY = playerY;
    float moveStep = MOVE_STEP_PLAYER;

    // Normalisation pour les mouvements diagonaux
    if ((Soldier_Joy_Direction & (LEFT | RIGHT)) && (Soldier_Joy_Direction & (UP | DOWN))) {
        moveStep *= 0.707f; // Réduire la vitesse en diagonale (1/√2)
    }

    if (Soldier_Joy_Direction & RIGHT) newX += moveStep;
    if (Soldier_Joy_Direction & LEFT) newX -= moveStep;
    if (Soldier_Joy_Direction & DOWN) newY += moveStep;
    if (Soldier_Joy_Direction & UP) newY -= moveStep;
//check
    if (isPositionValid(newX, playerY, Level_Use)) {
        playerX = newX;
    }
    if (isPositionValid(playerX, newY, Level_Use)) {
        playerY = newY;
    }

    // Vérifier la collecte des objets après le déplacement
    RecupSPK();

    // Update fire button release state
    if (!BUTTON_B) {
        fireButtonReleased = true; // Reset when button is released
    }

    // Handle firing
    if (BUTTON_B) {
        shootProjectile();
    }

    // Gérer le verrouillage de la direction de tir
    if (BUTTON_A && !isFireDirectionLocked) {
        isFireDirectionLocked = true;
        lockedFireDirection = Soldier_Direction;
    } else if (!BUTTON_A) {
        isFireDirectionLocked = false;
    }
}

__attribute__((always_inline)) inline void Set_Soldier_Direction(void) {
    static float playerAnimTimer = 0.0f; // Timer pour l'animation du joueur
    const float PLAYER_ANIM_FRAME_TIME = WALKING_SPEED;

    Soldier_Joy_Direction = 0;

    if (playerIsDead) {
        return; // Pas d'animation si le joueur est mort
    }

    // Déterminer la direction à partir des inputs
    if (TINYJOYPAD_LEFT) Soldier_Joy_Direction |= LEFT;
    if (TINYJOYPAD_RIGHT) Soldier_Joy_Direction |= RIGHT;
    if (TINYJOYPAD_UP) Soldier_Joy_Direction |= UP;
    if (TINYJOYPAD_DOWN) Soldier_Joy_Direction |= DOWN;

    // Mettre à jour la direction du joueur
    if (!isFireDirectionLocked) {
        switch (Soldier_Joy_Direction) {
            case UP: Soldier_Direction = 2; break;
            case DOWN: Soldier_Direction = 6; break;
            case LEFT: Soldier_Direction = 4; break;
            case RIGHT: Soldier_Direction = 0; break;
            case UP | LEFT: Soldier_Direction = 3; break;
            case UP | RIGHT: Soldier_Direction = 1; break;
            case DOWN | LEFT: Soldier_Direction = 5; break;
            case DOWN | RIGHT: Soldier_Direction = 7; break;
            default: break;
        }
    }

    // Mettre à jour l'animation si le joueur bouge
    if (Soldier_Joy_Direction != 0 && !playerIsRecoiling && !playerIsDead) {
        playerAnimTimer += FRAME_TIME; // Utiliser FRAME_TIME pour la cohérence
        if (playerAnimTimer >= PLAYER_ANIM_FRAME_TIME) {
            frm_Main_Soldier = (frm_Main_Soldier < 2) ? frm_Main_Soldier + 1 : 0; // Cycle entre frames 0, 1, 2
            playerAnimTimer -= PLAYER_ANIM_FRAME_TIME; // Réinitialiser le timer
        }
    } else {
        frm_Main_Soldier = 0; // Frame par défaut si immobile
        playerAnimTimer = 0.0f; // Réinitialiser le timer
    }
}

__attribute__((always_inline)) inline void frm_Main_Soldier_Refresh(void) {
    if (playerIsDead || playerIsRecoiling) return;
    if (frm_Main_Soldier_Div < 1) {
        frm_Main_Soldier_Div = frm_Main_Soldier_Div + 1;
    } else {
        frm_Main_Soldier_Div = 0;
        frm_Main_Soldier = (frm_Main_Soldier < 3) ? frm_Main_Soldier + 1 : 0;
    }
}

// Met à jour la position de la caméra avec latence
__attribute__((always_inline)) inline void updateCamera(float dt) {
    float idealCameraX = playerX - SCREEN_WIDTH / 2;
    float idealCameraY = playerY - SCREEN_HEIGHT / 2;

    s16 mapWidth = Level_Use[0] * TILE_SIZE;
    s16 mapHeight = Level_Use[1] * TILE_SIZE;

    if (idealCameraX < 0) idealCameraX = 0;
    if (idealCameraX > mapWidth - SCREEN_WIDTH) idealCameraX = mapWidth - SCREEN_WIDTH;
    if (idealCameraY < 0) idealCameraY = 0;
    if (idealCameraY > mapHeight - SCREEN_HEIGHT) idealCameraY = mapHeight - SCREEN_HEIGHT;

    float lag = CAMERA_LAG * dt * TARGET_FPS;
    cameraX += (idealCameraX - cameraX) * lag;
    cameraY += (idealCameraY - cameraY) * lag;
}

__attribute__((always_inline)) inline void EnemieNewFRM(float dt) {
    const float ENEMY_ANIM_FRAME_TIME = WALKING_SPEED;

    for (int i = 0; i < MAX_ENEMIES; i++) {
        if (enemies[i].active && !enemies[i].isDead && !enemies[i].isRecoiling) {
            // Mettre à jour l'animation seulement si l'ennemi bouge
            if (enemies[i].frmchange) {
                enemies[i].animTimer += dt;
                if (enemies[i].animTimer >= ENEMY_ANIM_FRAME_TIME) {
                    enemies[i].frame = (enemies[i].frame < 2) ? enemies[i].frame + 1 : 0; // Cycle entre frames 0, 1, 2
                    enemies[i].animTimer -= ENEMY_ANIM_FRAME_TIME; // Réinitialiser le timer
                }
            } else {
                enemies[i].frame = 0; // Frame par défaut si immobile
                enemies[i].animTimer = 0.0f; // Réinitialiser le timer
            }
            enemies[i].frmchange = 0; // Réinitialiser le trigger
        }
    }
}

void initCollectibles(const uint8_t* level) {
    collectibleCount = 0;
    for (s16 y = 0; y < level[1]; y++) {
        for (s16 x = 0; x < level[0]; x++) {
            uint8_t tile = level[2 + (x + (y * level[0]))];
            
            if (tile==14){//Initialiser la position du Joueur
				playerX = x * TILE_SIZE;
                playerY = y * TILE_SIZE;	
			}
			
            if (SpkCollectible[tile] == 1) { // Vérifie si c'est un collectible
                if (collectibleCount < MAX_COLLECTIBLES) {
                    collectibles[collectibleCount].x = x;
                    collectibles[collectibleCount].y = y;
                    collectibles[collectibleCount].tileType = tile;
                    collectibles[collectibleCount].collected = false;
                    collectibleCount++;
                }
            }
        }
    }
}


void initPlayer(void) {
	initCollectibles(Level_Use);
    playerAlive = true;
    playerIsDead = false;
    playerDeathTimer = 0.0f;
    playerBlinkState = true;
    playerBlinkTimer = 0.0f;
    cameraX = 0.0f;
    cameraY = 0.0f;
    initProjectiles();
    initEnemyProjectiles();
    initExplosions();
    fireTimer = 0.0f;
    frm_Main_Soldier = 0;
    playerIsRecoiling = false;
    playerRecoilStartX = 0.0f;
    playerRecoilStartY = 0.0f;
    isFireDirectionLocked = false;
    lockedFireDirection = 0;
    currentWeaponIndex = 0;
    fireButtonReleased = true;

// Réinitialiser les munitions
for (int i = 0; i < MAX_WEAPONS; i++) {
    if (i == 0) {
        weapons[i].maxAmmo = 0; // Pistolet commence à 0
        weapons[i].currentAmmo = 0;
    } else {
        weapons[i].currentAmmo = 0; // Autres armes à 0
    }
}
initBloodParticles();

}

__attribute__((always_inline)) inline void updateShootingMode(float dt) {
    static bool modeButtonReleased = true;
    
    
    if (BUTTON_Y) {
        if (modeButtonReleased) {
            switchWeaponX(false); // Changer d'arme manuellement
            modeButtonReleased = false;
        }
    } 
    
    if (BUTTON_X) {
		  if (modeButtonReleased) {
            switchWeaponY(false); // Changer d'arme manuellement
            modeButtonReleased = false;
        }
		} 

    if ((!BUTTON_Y)&&(!BUTTON_X)) {
        modeButtonReleased = true;
    }

}



u16 ReturnCorectSelect(u8 Item,u8 Select){
if (Item==Select) {return color(31,63,0);}else{return color(31,63,31);}
}

void MenuIntro(void) {
    SNDUP = 0;
    #define MENU_X_MENU 12
    #define MENU_Y_MENU 165 // Bas de l'écran, ajustable
    #define MENU_SHADOW_MENU 2
    #define SCREEN_WIDTH_MENU 320 // Largeur de l'écran
    #define SCREEN_HEIGHT_MENU 240 // Hauteur de l'écran
    #define SCANLINE_SPEED_MENU 3.0f // Vitesse de déplacement
    #define SCANLINE_HEIGHT_MENU 2 // Hauteur de la ligne
    #define TRAIL_COUNT_MENU 25 // Nombre de lignes de retard
    #define TRAIL_OFFSET_MENU 2 // Distance entre les lignes
    #define CONTRAST_FACTOR_MENU 1.5f // Facteur de contraste
    #define TOTAL_LINES_MENU (1 + TRAIL_COUNT_MENU) // Ligne principale + lignes de retard
    #define TARGET_FPS_MENU 30.0f // Cible : 30 FPS
    #define FRAME_TIME_MENU (1.0f / TARGET_FPS_MENU) // 33,33 ms par frame

    // État du menu
    typedef enum { MAIN_MENU, SETUP_MENU, SOUND_MENU, BACKLIGHT_ADJUST, VOLUME_ADJUST } MenuState;
    MenuState currentMenu = MAIN_MENU; // Menu actif
    u8 SelectSwitch = 0; // Sélection dans le menu
    u8 maxSelect = 2; // Nombre max d'options (par défaut pour MAIN_MENU)
    float scanlineYs[TOTAL_LINES_MENU]; // Positions y des lignes
    u32 menuLastTime = Time(); // Temps de la dernière frame
    float menuAccumulator = 0.0f; // Temps accumulé
    bool prevDown = false; // État précédent de TINYJOYPAD_DOWN
    bool prevUp = false; // État précédent de TINYJOYPAD_UP
    bool prevButtonB = false; // État précédent de BUTTON_B
    bool prevLeft = false; // État précédent de TINYJOYPAD_LEFT
    bool prevRight = false; // État précédent de TINYJOYPAD_RIGHT
    bool bgmOn = true; // État du BGM (par défaut : activé)
    uint8_t backlightLevel; // Niveau de rétroéclairage (0-CONFIG_BACKLIGHT_MAX)
    uint8_t volumeLevel; // Niveau de volume (0-CONFIG_VOLUME_MAX)
    uint8_t backlightLevel_old; // Mem Niveau de rétroéclairage (0-CONFIG_BACKLIGHT_MAX)
    uint8_t volumeLevel_old; // Mem Niveau de volume (0-CONFIG_VOLUME_MAX)
    
    // Charger les valeurs initiales
    backlightLevel_old=backlightLevel = ConfigGetBacklight();
    volumeLevel_old=volumeLevel = ConfigGetVolume();
    VolumeSoundChan(0, SNDUP);
    PlaySoundChan(0, intro, 160210, 1, 1, 1, SNDFORM_PCM, 1);
    VolumeSoundChan(0, SNDUP);
//    ConfigSetVolume(bgmOn ? volumeLevel : 0);

    // Initialiser les positions des lignes
    for (int i = 0; i < TOTAL_LINES_MENU; i++) {
        scanlineYs[i] = -i * TRAIL_OFFSET_MENU;
    }

    DispUpdate();

    while (1) {
        // Mesurer le temps écoulé
        u32 menuCurrentTime = Time();
        float dt = (float)(menuCurrentTime - menuLastTime) / 1000000.0f;
        menuLastTime = menuCurrentTime;

        // Accumuler le temps
        menuAccumulator += dt;
        if (menuAccumulator > 0.2f) menuAccumulator = 0.2f;

        bool shouldRender = false;

        // Mettre à jour la logique
        while (menuAccumulator >= FRAME_TIME_MENU) {
            // Mettre à jour les positions des lignes
            for (int i = 0; i < TOTAL_LINES_MENU; i++) {
                scanlineYs[i] += SCANLINE_SPEED_MENU;
                if (scanlineYs[i] >= SCREEN_HEIGHT_MENU) {
                    scanlineYs[i] -= SCREEN_HEIGHT_MENU;
                }
            }

            // Gérer les entrées utilisateur
            bool currentDown = TINYJOYPAD_DOWN;
            bool currentUp = TINYJOYPAD_UP;
            bool currentButtonB = BUTTON_DOWN;
            bool currentLeft = TINYJOYPAD_LEFT;
            bool currentRight = TINYJOYPAD_RIGHT;

            // Flèche bas : item suivant
            if (currentDown && !prevDown) {
                PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                SelectSwitch = (SelectSwitch < maxSelect) ? SelectSwitch + 1 : SelectSwitch;
            }

            // Flèche haut : item précédent
            if (currentUp && !prevUp) {
                PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                SelectSwitch = (SelectSwitch > 0) ? SelectSwitch - 1 : SelectSwitch;
            }

            // Ajuster les valeurs (Backlight ou Volume) avec gauche/droite
            if (currentMenu == BACKLIGHT_ADJUST) {
                if (currentLeft && !prevLeft) {
                   if (backlightLevel>1){ ConfigDecBacklight(); // Décrémenter le rétroéclairage
                    backlightLevel = ConfigGetBacklight(); // Mettre à jour la valeur
				}
                    PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                }
                if (currentRight && !prevRight) {
                    ConfigIncBacklight(); // Incrémenter le rétroéclairage
                    backlightLevel = ConfigGetBacklight(); // Mettre à jour la valeur
                    PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                }
            } else if (currentMenu == VOLUME_ADJUST) {
                if (currentLeft && !prevLeft) {
                    ConfigDecVolume(); // Décrémenter le volume
                    volumeLevel = ConfigGetVolume(); // Mettre à jour la valeur
                    PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                    ConfigSetVolume(bgmOn ? volumeLevel : 0);
                }
                if (currentRight && !prevRight) {
                    ConfigIncVolume(); // Incrémenter le volume
                    volumeLevel = ConfigGetVolume(); // Mettre à jour la valeur
                    PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                    ConfigSetVolume(bgmOn ? volumeLevel : 0);
                }
            }

            // Bouton B : valider la sélection
            if (currentButtonB && !prevButtonB) {
                if (currentMenu == MAIN_MENU) {
                    switch (SelectSwitch) {
                        case 0: goto EXIT_; // Start Game
                        case 1: // Setup
                            currentMenu = SETUP_MENU;
                            SelectSwitch = 0;
                            maxSelect = 2; // Backlight, Sound, Return
                            break;
                            
                        case 2: // Exit
                            if ((backlightLevel_old != backlightLevel) || (volumeLevel_old != volumeLevel)) ConfigSave();
                            ResetToBootLoader();
                            break;
                            
                        default: break;
                    }
                } else if (currentMenu == SETUP_MENU) {
                    switch (SelectSwitch) {
                        case 0: // Backlight
                            backlightLevel = ConfigGetBacklight(); // Charger la valeur actuelle
                            currentMenu = BACKLIGHT_ADJUST;
                            SelectSwitch = 0;
                            maxSelect = 0; // Pas de sélection multiple
                            break;
                        case 1: // Sound
                            volumeLevel = ConfigGetVolume(); // Charger la valeur actuelle
                            currentMenu = SOUND_MENU;
                            SelectSwitch = 0;
                            maxSelect = 2; // BGM, Main Volume, Return
                            break;
                        case 2: // Return
                            currentMenu = MAIN_MENU;
                            SelectSwitch = 0;
                            maxSelect = 2; // Start Game, Setup, Exit
                            break;
                        default: break;
                    }
                } else if (currentMenu == SOUND_MENU) {
                    switch (SelectSwitch) {
                        case 0: // BGM
                            bgmOn = !bgmOn; // Basculer l'état du BGM
                            ConfigSetVolume(bgmOn ? volumeLevel : 0);
                            PlaySoundChan(SND_Chan, Button, 1281, 0, 1, 1, SNDFORM_PCM, 1);
                            break;
                        case 1: // Main Volume
                            volumeLevel = ConfigGetVolume(); // Charger la valeur actuelle
                            currentMenu = VOLUME_ADJUST;
                            SelectSwitch = 0;
                            maxSelect = 0; // Pas de sélection multiple
                            break;
                        case 2: // Return
                            currentMenu = SETUP_MENU;
                            SelectSwitch = 0;
                            maxSelect = 2; // Backlight, Sound, Return
                            break;
                        default: break;
                    }
                } else if (currentMenu == BACKLIGHT_ADJUST || currentMenu == VOLUME_ADJUST) {
                    // Retourner au menu Setup
                    currentMenu = SETUP_MENU;
                    SelectSwitch = 0;
                    maxSelect = 2; // Backlight, Sound, Return
                }
            }

            // Mettre à jour les états précédents
            prevDown = currentDown;
            prevUp = currentUp;
            prevButtonB = currentButtonB;
            prevLeft = currentLeft;
            prevRight = currentRight;

            menuAccumulator -= FRAME_TIME_MENU;
            shouldRender = true;
        }

        // Rendu
        if (shouldRender) {
            // Dessiner l'image de fond
            DrawBlitPal(menu, menu_Pal, 0, 0, 0, 0, menu_W, menu_H, menu_W_FULL, 0xFFE0);

            // Effet de balayage CRT
            for (int line = 0; line < TOTAL_LINES_MENU; line++) {
                int yPos = (int)scanlineYs[line];
                if (yPos < 0 || yPos >= SCREEN_HEIGHT_MENU) continue;
                int shadowLevel = (line == 0) ? 15 : (int)(15.0f * ((float)line / TRAIL_COUNT_MENU));
                DrawRectShadow(0, yPos, SCREEN_WIDTH_MENU, SCANLINE_HEIGHT_MENU, shadowLevel);
            }

            // Dessiner le texte du menu selon l'état
            if (currentMenu == MAIN_MENU) {
                DrawTextH("Start Game", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
                DrawTextH("Setup", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
                DrawTextH("Exit", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);

                DrawTextH("Start Game", MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
                DrawTextH("Setup", MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
                DrawTextH("Exit", MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
            } else if (currentMenu == SETUP_MENU) {
                DrawTextH("Backlight", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
                DrawTextH("Sound", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
                DrawTextH("Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);

                DrawTextH("Backlight", MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
                DrawTextH("Sound", MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
                DrawTextH("Return", MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
            } else if (currentMenu == SOUND_MENU) {
                DrawTextH(bgmOn ? "Sound: On" : "Sound: Off", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
                DrawTextH("Main Volume", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
                DrawTextH("Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);

                DrawTextH(bgmOn ? "Sound: On" : "Sound: Off", MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
                DrawTextH("Main Volume", MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
                DrawTextH("Return", MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
            } else if (currentMenu == BACKLIGHT_ADJUST) {
                char backlightText[32];
                sprintf(backlightText, "Backlight: %d", backlightLevel);
                DrawTextH(backlightText, MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
                DrawTextH("Press B to Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);

                DrawTextH(backlightText, MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
                DrawTextH("Press B to Return", MENU_X_MENU, MENU_Y_MENU + 22, color(0,0,31));
            } else if (currentMenu == VOLUME_ADJUST) {
                char volumeText[32];
                sprintf(volumeText, "Main Volume: %d", volumeLevel);
                DrawTextH(volumeText, MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
                DrawTextH("Press B to Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);

                DrawTextH(volumeText, MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
                DrawTextH("Press B to Return", MENU_X_MENU, MENU_Y_MENU + 22,  color(0,0,31));
            }

            // Rafraîchir l'écran
            DispUpdate();
            SND_Fade_Up();
        }
    }
EXIT_:;
  if ((backlightLevel_old!=backlightLevel) || (volumeLevel_old!=volumeLevel)) ConfigSave();
    FadeOutToBlack();
}


void checkRallyPointProximity() {
    if (Heli_Mode != 1) return;

    for (s16 y = 0; y < Level_Use[1]; y++) {
        for (s16 x = 0; x < Level_Use[0]; x++) {
            if (Level_Use[2 + (x + (y * Level_Use[0]))] == 13) {
                float rallyCenterX = (x * TILE_SIZE) + (SPK_W[13] / 2.0f);
                float rallyCenterY = (y * TILE_SIZE) + (SPK_H[13] / 2.0f);
                float dx = playerX + (PLAYER_W / 2.0f) - rallyCenterX;
                float dy = playerY + (PLAYER_H / 2.0f) - rallyCenterY;
                float distance = sqrtf(dx * dx + dy * dy);
                const float PROXIMITY_THRESHOLD = 50.0f;

                s16 screenX = (s16)(rallyCenterX - cameraX);
                s16 screenY = (s16)(rallyCenterY - cameraY);
                DrawCircle(screenX, screenY, (s16)PROXIMITY_THRESHOLD, color(31, 0, 0));

                if (distance <= PROXIMITY_THRESHOLD) {
                    Heli_Mode = 2;
                }
                return;
            }
        }
    }
}

void DrawMission(void) {
    DrawClearCol(color(15, 25, 7));
    DrawRectShadow(21, 16, 281, 211, 2);
    DrawFrame(20, 15, 280, 210, color(31, 63, 31));

const char *missionTexts[] = {
    "-Eliminate all enemies here.",
    "-Find enemy communication radios.",
    "-Find all necessary batteries.",
    "-Recover all fuel canisters.",
    "-Join the helicopter."
};

char Text_[16];
sprintf(Text_, "MISSION %d", LVL_Playing);
    int title_x = SCREEN_WIDTH / 2 - 35; // Approximation pour le titre
    DrawText(Text_, title_x, SCREEN_HEIGHT / 2 - 74, color(31, 63, 0));

    // Positions y pour les quatre lignes (espacement de 20 pixels)
    int y_start = SCREEN_HEIGHT / 2 - 40;
    int line_spacing = 20;
u8 Next_Line=0;
    // Afficher chaque ligne centrée
    for (int i = 0; i < 5; i++) {
		
 if ((Obj_Level[LVL_Playing][(i<4)?i:3]!=0) || (i==4)) DrawText(missionTexts[i], SCREEN_WIDTH / 2 - 126, y_start + Next_Line++ * line_spacing, color(31, 63, 31));
    }
}


void New_Mission(void) {
	const int STEPS = 8; // 8 étapes pour le fade
    const int LINE_SPACING = 8; // Une ligne sur 8
    const int SCREEN_HEIGHT = 240; // Hauteur de l'écran
    const int SCREEN_WIDTH = 320; // Largeur de l'écran

    // Boucle sur les 8 étapes
    for (int step = 0; step < STEPS; step++) {
        // Dessiner l'image complète
DrawMission();

        // Dessiner les lignes noires restantes (pour les étapes précédentes)
        for (int s = step; s < STEPS; s++) {
            for (int y = 0; y < SCREEN_HEIGHT; y++) {
                // Dessiner les lignes noires pour les étapes non encore "révélées"
                if ((y % LINE_SPACING) == s) {
                    DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // Ligne noire
                }
            }
        }

        DispUpdate(); // Rafraîchir l'écran
        sleep_ms(33); // Délai de 33ms (~30 FPS)
    }

    // Afficher l'image complète sans lignes noires à la fin
DrawMission();
    DispUpdate();
    while(1){
	if (BUTTON_DOWN) break;
    sleep_ms(33);
}
}

void Mission_Completed(void){
SNDUP=0;
VolumeSoundChan(0, 0);    
PlaySoundChan(0, helico, 119257, 1, 1, 1, SNDFORM_PCM, 1);
}

void INIT_NEW_GAME(void) {
	//Reset MetalJacket
	MetalJacket=0;
    // Game mode and level state
    Heli_Mode = 0;
    LvL_Completed = 0;
    LVL_Playing = 0; 

    Level_Use = Level_Select[LVL_Playing];
    INIT_OBJ_LVL(); // Resets OBJ_LVL.ALL_KILL to 0

    // Player state
    playerAlive = true;
    playerIsDead = false;
    playerDeathTimer = 0.0f;
    playerBlinkState = true;
    playerBlinkTimer = 0.0f;
    playerIsRecoiling = false;
    playerRecoilTimer = 0.0f;
    playerRecoilDirection = 0;
    playerRecoilStartX = 0.0f;
    playerRecoilStartY = 0.0f;
    frm_Main_Soldier = 0;
    frm_Main_Soldier_Div = 0;
    Soldier_Joy_Direction = 0;
    Soldier_Direction = 0;
    isFireDirectionLocked = false;
    lockedFireDirection = 0;

    // Weapons and shooting
    currentWeaponIndex = 0;
    for (int i = 0; i < MAX_WEAPONS; i++) {
        if (i == 0) {
            weapons[i].maxAmmo = 0;    // Pistol starts with 0 ammo (or -1 for infinite)
            weapons[i].currentAmmo = 0; // Adjust based on your design
        } else {
            weapons[i].currentAmmo = 0; // Other weapons start with 0 ammo
        }
    }
    fireTimer = 0.0f;
    fireButtonReleased = true;

    // Enemies
    enemyKillCount = 0;
    initEnemies(Level_Use); // Resets enemies array and populates based on level

    // Projectiles
    initProjectiles();       // Resets player projectiles
    initEnemyProjectiles(); // Resets enemy projectiles

    // Explosions
    initExplosions();       // Resets explosions

    // Collectibles
    initCollectibles(Level_Use); // Resets collectibles and sets collectibleCount

    // Camera
    cameraX = 0.0f;
    cameraY = 0.0f;

    // Timers and FPS
    restartDelayTimer = 0.0f;
    fpsAccumulator = 0.0f;
    currentFPS = 0.0f;
    accumulator = 0.0f;
    lastTime = Time();
    Heli_FRM_Number = 0;

    // Sound
    SNDUP = 0;
    SND_Chan = 1;
}

__attribute__((always_inline)) inline void Heli_Anim(float dt) {
    static float heliAnimTimer = 0.0f;
    const float HELI_ANIM_FRAME_TIME = 0.04f; // 40 ms par frame

    heliAnimTimer += dt;
    if (heliAnimTimer >= HELI_ANIM_FRAME_TIME) {
        if (Heli_Mode) { // Ne mettre à jour l'animation que si Heli_Mode est actif
            Heli_FRM_Number = (Heli_FRM_Number < 3) ? Heli_FRM_Number + 1 : 1;
        }
        heliAnimTimer -= HELI_ANIM_FRAME_TIME;
    }
}

u8 Check_Objectif_ID(void) {
    return (Obj_Level[LVL_Playing][0] == OBJECTIFS[0] &&
            Obj_Level[LVL_Playing][1] == OBJECTIFS[1] &&
            Obj_Level[LVL_Playing][2] == OBJECTIFS[2] &&
            Obj_Level[LVL_Playing][3] == OBJECTIFS[3]);
}


void Lvl_Completed_Check(void){
	if (Heli_Mode==0){

if (Check_Objectif_ID()) 
{
Heli_Mode=1;
Mission_Completed();
}}
return;
}

void GAME_PLAY_ADJUSTEMENT(void){
	Lvl_Completed_Check();
if (OBJECTIFS[0]==0){
if ((enemyCount)==enemyKillCount) {
OBJECTIFS[0]=1;
}
}}

bool INIT_NEXT_LVL(void){
bool ret_=1;
Heli_Mode=0;
enemyKillCount = 0;
if (LVL_Playing<(MAX_LEVEL-1)){
	LVL_Playing+=1;
	Level_Use=Level_Select[LVL_Playing];
	}else{
ret_=0;
	}

INIT_OBJ_LVL();
restartDelayTimer = 0.0f; // Réinitialiser le timer
initPlayer();
initEnemies(Level_Use);
return ret_;
}

   void Return_to_Menu(const uint8_t *PIC_,const uint16_t *PIC_PAL_,const uint8_t* SND_,int length_){         
            FadeOutToBlack();
            sleep_ms(200);
            FadeInFromBlack(PIC_,PIC_PAL_);
            PlaySoundChan(0,SND_,length_,0,1,1,SNDFORM_PCM,1);
            sleep_ms(5000);
            FadeOutToBlack();
            INIT_NEW_GAME();
			FadeInFromBlack(menu,menu_Pal);
            MenuIntro();              // Afficher le menu d'introduction
            New_Mission();
			FadeOutToBlack();
			PlaySoundChan(0, loop, 353619, 1, 1, 1, SNDFORM_PCM, 1);
}

int main() {


	VolumeSoundChan(0, SNDUP);
    PlaySoundChan(0, intro, 160210, 1, 1, 1, SNDFORM_PCM, 1);
    VolumeSoundChan(0, SNDUP);
	
    // Configurer la fréquence en fonction du microcontrôleur
#if USE_PICOPAD10
    // Overclocking sûr pour RP2040 (250 MHz sans refroidisseur)
    vreg_set_voltage(VREG_VOLTAGE_1_20); // 1,2 V
    sleep_ms(100);
    set_sys_clock_khz(250000, true);
  //  DrawClearCol(color(31, 0, 0));
    DispUpdate();
    sleep_ms(300);
#elif USE_PICOPAD20
    // Overclocking sûr pour RP2350 (300 MHz sans refroidisseur)
    vreg_set_voltage(VREG_VOLTAGE_1_30); // 1,3 V
    sleep_ms(100);
    set_sys_clock_khz(300000, true);
  //  DrawClearCol(color(0, 63, 0));
    DispUpdate();
    sleep_ms(300);
#else
//    DrawClearCol(color(0, 0, 31));
    DispUpdate();
    sleep_ms(300);
#endif

    DrawClearCol(color(0, 0, 0));
    DispUpdate();
    sleep_ms(300);
    // Initialiser les périphériques standards
    stdio_init_all(); 

PlaySoundChan(0, logo, 110336, 0, 1, 1, SNDFORM_PCM, 1);
FadeInFromBlack(splash,splash_Pal);
sleep_ms(3000);
FadeOutToBlack();
sleep_ms(1000);
FadeInFromBlack(menu,menu_Pal);
INIT_NEW_GAME();
MenuIntro();
New_Mission();
FadeOutToBlack();
SNDUP=0;
    VolumeSoundChan(0, SNDUP);
PlaySoundChan(0, loop, 353619, 1, 1, 1, SNDFORM_PCM, 1);
    VolumeSoundChan(0, SNDUP);

    // Initialiser le joueur et le jeu
    initPlayer();
    lastTime = Time();
    playerAlive = true;

    // Variables pour le calcul des FPS
    float fpsAccumulator = 0.0f; // Accumule le temps pour le calcul des FPS
    float currentFPS = 0.0f;     // FPS calculé

    while (1) {
        u32 currentTime = Time();
        float dt = (float)(currentTime - lastTime) / 1000000.0f;
        lastTime = currentTime;
    Heli_Anim(dt);
        // Mise à jour du calcul des FPS
        static u32 renderCount = 0; // Compteur de frames rendues
        fpsAccumulator += dt;
        if (fpsAccumulator >= 1.0f) { // Calculer les FPS toutes les secondes
            currentFPS = (float)renderCount / fpsAccumulator;
            renderCount = 0;
            fpsAccumulator = 0.0f;
        }

        accumulator += dt;
        if (accumulator > 0.2f) accumulator = 0.2f;

        bool shouldRender = false;

        while (accumulator >= FRAME_TIME) {
		      EnemieNewFRM(FRAME_TIME);
		      Set_Soldier_Direction();
            updateShootingMode(FRAME_TIME);
            updatePlayerPosition(FRAME_TIME);
            updateProjectiles(FRAME_TIME);
            updateEnemies(FRAME_TIME);
            updateEnemyProjectiles(FRAME_TIME);
            updateExplosions(FRAME_TIME);
            updateBloodParticles(FRAME_TIME); 
            checkPlayerProjectileCollisions();
            checkEnemyProjectileCollisions();
            checkExplosionCollisions(); 
            updateCamera(FRAME_TIME);
            GAME_PLAY_ADJUSTEMENT();
            accumulator -= FRAME_TIME;
            shouldRender = true;
        }


if (!playerAlive) {
    // Afficher "Game Over" par-dessus le jeu sans effacer l'écran
    DrawText("Game Over", SCREEN_WIDTH / 2 - 40, SCREEN_HEIGHT / 2, color(31, 63, 0)); // Rouge pour plus de visibilité
  DispUpdate();


    if (restartDelayTimer == 0.0f) {
        restartDelayTimer = 3.0f; // Démarrer le délai de 5 secondes
    }

    // Mettre à jour le timer de délai
    if (restartDelayTimer > 0.0f) {
        restartDelayTimer -= dt;
        if (restartDelayTimer <= 0.0f) {
            // Retourner au menu d'introduction après 5 secondes
           
           Return_to_Menu(gopic,gopic_Pal,go,84396);
         
        }
    }

    continue;
}else{
	
   //Levl Completed         
if ((Heli_Mode == 2) && (!playerIsDead) && (!playerIsRecoiling) ) {
    static float heliMode2Timer = 0.0f;
    heliMode2Timer += dt;
    if (heliMode2Timer >= 1.0f) { // Attendre 3 secondes
        FadeOutToBlack();
      if (INIT_NEXT_LVL()){
        New_Mission();
        FadeOutToBlack();
        PlaySoundChan(0, loop, 353619, 1, 1, 1, SNDFORM_PCM, 1);

    }else{
		Return_to_Menu(win,win_Pal,congrats,92245);
		}
		    heliMode2Timer = 0.0f; // Réinitialiser le timer
        Heli_Mode = 0; // Réinitialiser Heli_Mode
    
    }}
}	
	

        if (shouldRender) {
			SND_Fade_Up_InGame();
            renderCount++; // Incrémenter le compteur de frames rendues
            DrawClearCol(color(15, 25, 7));


            s16 startX = (s16)((cameraX - 80) / TILE_SIZE);
            s16 startY = (s16)((cameraY - 80) / TILE_SIZE);
            s16 endX = ((s16)((cameraX + SCREEN_WIDTH) / TILE_SIZE) + 1);
            s16 endY = ((s16)((cameraY + SCREEN_HEIGHT) / TILE_SIZE) + 1);

            if (startX < 0) startX = 0;
            if (startY < 0) startY = 0;
            if (endX > Level_Use[0]) endX = Level_Use[0];
            if (endY > Level_Use[1]) endY = Level_Use[1];

            s16 playerScreenX = (s16)(playerX - cameraX);
            s16 playerScreenY = (s16)(playerY - cameraY);

            // First layer
            for (s16 y = startY; y < endY; y++) {
                for (s16 x = startX; x < endX; x++) {
                    if (x >= 0 && x < Level_Use[0] && y >= 0 && y < Level_Use[1]) {
                        uint8_t tile = Level_Use[2 + (x + (y * Level_Use[0]))];
                        s16 drawX = (x * TILE_SIZE) - (s16)cameraX;
                        s16 drawY = (y * TILE_SIZE) - (s16)cameraY;
                        DrawTypeofSprite(drawX, drawY, tile);
                    }
                }
            }

            DrawMainSoldier(playerScreenX, playerScreenY, isFireDirectionLocked ? lockedFireDirection : Soldier_Direction);
            drawEnemies();
            drawProjectiles();
            drawEnemyProjectiles();
            drawExplosions();
            drawBloodParticles();
            checkRallyPointProximity(); // Ajouter la vérification de proximité
            


// Second layer
for (s16 y = startY; y < endY; y++) {
    for (s16 x = startX; x < endX; x++) {
        if (x >= 0 && x < Level_Use[0] && y >= 0 && y < Level_Use[1]) {
            uint8_t tile = Level_Use[2 + (x + (y * Level_Use[0]))];
            if ((SpkType[tile] == 3) || (SpkType[tile] == 2)) {
                // Vérifier si c'est un collectible et s'il a été ramassé
                bool skip = false;
                if (SpkCollectible[tile] == 1) {
                    for (u16 i = 0; i < collectibleCount; i++) {
                        if (collectibles[i].x == x && collectibles[i].y == y && collectibles[i].collected) {
                            skip = true;
                            break;
                        }
                    }
                }
                if (!skip) {
                    s16 drawX = (x * TILE_SIZE) - (s16)cameraX;
                    s16 drawY = (y * TILE_SIZE) - (s16)cameraY;
                    DrawSprite(Decalage_X(drawX, 1, SpkAlt[tile]), Decalage_Y(drawY, 1, SpkAlt[tile]), 1, tile);
                }
            }
        }
    }
}

           // Third layer
for (s16 y = startY; y < endY; y++) {
    for (s16 x = startX; x < endX; x++) {
        if (x >= 0 && x < Level_Use[0] && y >= 0 && y < Level_Use[1]) {
            uint8_t tile = Level_Use[2 + (x + (y * Level_Use[0]))];
            if (SpkType[tile] == 3) {
                // Vérifier si c'est un collectible et s'il a été ramassé
                bool skip = false;
                if (SpkCollectible[tile] == 1) {
                    for (u16 i = 0; i < collectibleCount; i++) {
                        if (collectibles[i].x == x && collectibles[i].y == y && collectibles[i].collected) {
                            skip = true;
                            break;
                        }
                    }
                }
                if (!skip) {
                    s16 drawX = (x * TILE_SIZE) - (s16)cameraX;
                    s16 drawY = (y * TILE_SIZE) - (s16)cameraY;
                    DrawSprite(Decalage_X(drawX, 2, SpkAlt[tile]), Decalage_Y(drawY, 2, SpkAlt[tile]), 2, tile);
                }
            }
        }
    }
}

// Afficher les FPS dans le coin inférieur gauche
#ifdef DRAW_FPS
char fpsText[16];
sprintf(fpsText, "FPS: %.1f", currentFPS);
DrawText(fpsText, 0, 225, color(31, 63, 0));
#endif

// Afficher l'arme actuelle et les munitions
    const char* weaponName;
    switch (currentWeaponIndex) {
        case 0: weaponName = "Pistol"; break;
        case 1: weaponName = "Machine Gun"; break;
        case 2: weaponName = "Shotgun"; break;
        case 3: weaponName = "Grenade"; break;
    }
    DrawText(weaponName, 28, 0, color(25, 50, 0));

// Afficher les munitions
char ammoText[32];
if (weapons[currentWeaponIndex].maxAmmo == -1) {
    sprintf(ammoText, "Ammo: infinite");
} else {
    sprintf(ammoText, "Ammo: %d/%d", weapons[currentWeaponIndex].currentAmmo, weapons[currentWeaponIndex].maxAmmo);
}
DrawText(ammoText, 28, 10, color(25, 50, 25));

// Afficher un message si aucune munition n'est disponible
if (BUTTON_B && fireTimer <= 0.0f) {
    bool hasAmmo = false;
    for (int i = 0; i < MAX_WEAPONS; i++) {
        if (weapons[i].currentAmmo > 0 || weapons[i].maxAmmo == -1) {
            hasAmmo = true;
            break;
        }
    }
    if (!hasAmmo) {
        DrawText("No Ammo!", 29, 20, color(31, 0, 0)); // Message en rouge
    }
}
Draw_Amos();
Draw_OBJ_LVL();
Draw_Metal_Jacket();
Draw_Mission(0);
DispUpdate();

  #if USE_SCREENSHOT
		switch (KeyGet())
		{
		case KEY_Y: SmallScreenShot();
		}
		#endif
        
    }}
    return 0;
}

const u16 MisCol[3]={color(31,63,0),color(31,0,0),color(31,63,31)};

void Draw_Mission(u8 Mis_){
if (Heli_Mode) 
{
 DrawText("Awaiting you!", 112, 26, MisCol[Heli_FRM_Number]); // Mission complété
	}
}

__attribute__((always_inline)) inline void Draw_OBJ_LVL(void){
if (Obj_Level[LVL_Playing][0]!=0) {Draw_Kill_Count();}
if (Obj_Level[LVL_Playing][1]!=0) {if (Obj_Level[LVL_Playing][1]!=OBJECTIFS[1]) {Draw_Shade_Ico(195,1,5);}else{Draw_Ico(195,1,5);}}
if (Obj_Level[LVL_Playing][2]!=0) {if (Obj_Level[LVL_Playing][2]!=OBJECTIFS[2]) {Draw_Shade_Ico(223,1,6);}else{Draw_Ico(223,1,6);}}
if (Obj_Level[LVL_Playing][3]!=0) {if (Obj_Level[LVL_Playing][3]!=OBJECTIFS[3]) {Draw_Shade_Ico(251,1,7);}else{Draw_Ico(251,1,7);}}
}

__attribute__((always_inline)) inline void Draw_Amos(void){
Draw_Ico(1,1,currentWeaponIndex);
}

__attribute__((always_inline)) inline void Draw_Kill_Count(void){
char KillText[8];
Draw_Ico(141,2,8);
sprintf(KillText, "%d", enemyKillCount);
DrawText(KillText, 168, 0,color(25,50,0)); // Nombre de mort
sprintf(KillText, "%d", enemyCount);
DrawText(KillText, 168, 10,color(25,50,0)); // Enemies total
}

__attribute__((always_inline)) inline void Draw_Metal_Jacket(void){
if (MetalJacket==0) return;
u8 Val_=map(MetalJacket,0,5,25,0);
if (MetalJacket) {
Draw_Ico(279,1,4);
	DrawRect(306,1,6,25,color(20,40,20));
	DrawRect(307,2,4,Val_,color(31,0,15));
	DrawFrame(306,1,6,25,color(25,50,25));
}
}

__attribute__((always_inline)) inline void Draw_Shade_Ico(u16 x_,u16 y_,u8 Pic_){
Draw_ICO_Display(x_+1,y_+1,Pic_);
DrawRectShadow(x_, y_, 25, 25, 6);
DrawFrame(x_,y_,25,25,color(20,10,0));
}

__attribute__((always_inline)) inline void Draw_Ico(u16 x_,u16 y_,u8 Pic_){
DrawRectShadow(x_, y_, 25, 25, 12);
Draw_ICO_Display(x_+1,y_+1,Pic_);
DrawFrame(x_,y_,25,25,color(20,40,20));
}

__attribute__((always_inline)) inline void Draw_ICO_Display(u16 x_,u16 y_,u8 Pic_){
    DrawBlitPal(ico, ico_Pal,
               20 * Pic_, 0,
                x_, y_,
                20, 20,
                ico_W_FULL, COL_WHITE);
			}

__attribute__((always_inline)) inline void DrawTypeofSprite(s16 X_, s16 Y_, u8 Sprite_) {
    // Vérifier si c'est un collectible et s'il a été ramassé
    if (SpkCollectible[Sprite_] == 1) {
        s16 tileX = (s16)((X_ + cameraX) / TILE_SIZE);
        s16 tileY = (s16)((Y_ + cameraY) / TILE_SIZE);
        for (u16 i = 0; i < collectibleCount; i++) {
            if (collectibles[i].x == tileX && collectibles[i].y == tileY && collectibles[i].collected) {
                return; // Ne pas dessiner si le collectible a été ramassé
            }
        }
    }

    switch (SpkType[Sprite_]) {
        case 1:
        case 2: 
        case 3: DrawSprite(X_, Y_, 0, Sprite_); break;
        default: break;
    }
}

__attribute__((always_inline)) inline void DrawMainSoldier(s16 x_, s16 y_, s8 Direction_) {
    if (Direction_ < 0 || Direction_ > 7) {
        Direction_ = 0; // Sécurité pour direction invalide
    }
    if (playerIsDead && playerDeathTimer <= HALFDEATHTIMER && !playerBlinkState) {
        return;
    }
    s8 frame = frm_Main_Soldier;
    DrawBlitPal(soldier, soldier_Pal,
                (frame * PLAYER_W), Direction_ * PLAYER_H,
                x_, y_,
                PLAYER_W, PLAYER_H,
                soldier_W_FULL, COL_WHITE);
}



const s16 Start_Alt_Mid[3]={-2,-5,-10};
const s16 Stop_Alt_Mid[3]={5,10,20};

const s16 Start_Alt_Top[3]={-5,-10,-20};
const s16 Stop_Alt_Top[3]={10,20,40};

s16 Decalage_X(s16 x_, s8 Height_,u8 Alt_) {
    switch (Height_) {
        case 1: return (s16)map(x_, 0, SCREEN_WIDTH,Start_Alt_Mid[Alt_], SCREEN_WIDTH + Stop_Alt_Mid[Alt_]); break;
        case 2: return (s16)map(x_, 0, SCREEN_WIDTH,Start_Alt_Top[Alt_], SCREEN_WIDTH + Stop_Alt_Top[Alt_]); break;
        default: return x_; break;
    }
}

s16 Decalage_Y(s16 y_, s8 Height_,u8 Alt_) {
    switch (Height_) {
        case 1: return (s16)map(y_, 0, SCREEN_HEIGHT,Start_Alt_Mid[Alt_],SCREEN_HEIGHT + Stop_Alt_Mid[Alt_]); break;
        case 2: return (s16)map(y_, 0, SCREEN_HEIGHT,Start_Alt_Top[Alt_],SCREEN_HEIGHT + Stop_Alt_Top[Alt_]); break;
        default: return y_; break;
    }
}

__attribute__((always_inline)) inline void DrawSprite(s16 x_, s16 y_, u8 frm_, u8 Sprite_) {

	switch(Sprite_){
		case 13:
		  if (Heli_Mode) { 
			    DrawBlitPal(COP[Heli_FRM_Number],COP_PAL[Heli_FRM_Number],
                SPK_W[Sprite_] * frm_, 0,
                x_, y_,
                SPK_W[Sprite_], SPK_H[Sprite_],
                Pic_W_FULL[Sprite_], COL_WHITE);}else{ 
					   DrawBlitPal(PIC[Sprite_], PIC_PAL[Sprite_],
                SPK_W[Sprite_] * frm_, 0,
                x_, y_,
                SPK_W[Sprite_], SPK_H[Sprite_],
                Pic_W_FULL[Sprite_], COL_WHITE);}
		break;
		
		default:
    DrawBlitPal(PIC[Sprite_], PIC_PAL[Sprite_],
                SPK_W[Sprite_] * frm_, 0,
                x_, y_,
                SPK_W[Sprite_], SPK_H[Sprite_],
                Pic_W_FULL[Sprite_], COL_WHITE);
                break;
			}
}

float map(float x, float in_min, float in_max, float out_min, float out_max) {
    return out_min + (x - in_min) * (out_max - out_min) / (in_max - in_min);
}

void FadeOutToBlack(void) {
//SNDUP=1.00f;
    const int STEPS = 8; // 8 étapes pour le fade
    const int LINE_SPACING = 8; // Une ligne sur 8
    const int SCREEN_HEIGHT = 240; // Hauteur de l'écran
    const int SCREEN_WIDTH = 320; // Largeur de l'écran

    // Boucle sur les 8 étapes
    for (int step = 0; step < STEPS; step++) {
        // Parcourir toutes les lignes de l'écran
        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            // Si la ligne doit être noircie (une ligne sur 8, décalée par l'étape)
            if ((y % LINE_SPACING) == step) {
                // Dessiner une ligne noire horizontale
                DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // De (0,y) à (319,y), couleur noire
            }
        }
        DispUpdate(); // Rafraîchir l'écran
        sleep_ms(33);// Délai de 100ms pour l'animation
SND_Fade_Down();
SND_Fade_Down();
    }

SNDUP=0;
    DispUpdate();
}

void FadeInFromBlack(const u8 *PIC_,const u16 *PIC_PAL_) {

    const int STEPS = 8; // 8 étapes pour le fade
    const int LINE_SPACING = 8; // Une ligne sur 8
    const int SCREEN_HEIGHT = 240; // Hauteur de l'écran
    const int SCREEN_WIDTH = 320; // Largeur de l'écran

    // Boucle sur les 8 étapes
    for (int step = 0; step < STEPS; step++) {
        // Dessiner l'image complète
        DrawBlitPal(PIC_, PIC_PAL_,
                    0, 0,              // Position source (x, y)
                    0, 0,              // Position destination (x, y)
                    menu_W, menu_H,    // Largeur et hauteur de l'image
                    menu_W_FULL,       // Largeur totale de l'image
                    COL_GREEN);        // Couleur (blanc pour aucun filtre)

        // Dessiner les lignes noires restantes (pour les étapes précédentes)
        for (int s = step; s < STEPS; s++) {
            for (int y = 0; y < SCREEN_HEIGHT; y++) {
                // Dessiner les lignes noires pour les étapes non encore "révélées"
                if ((y % LINE_SPACING) == s) {
                    DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // Ligne noire
                }
            }
        }

        DispUpdate(); // Rafraîchir l'écran
        sleep_ms(33); // Délai de 33ms (~30 FPS)
    }

    // Afficher l'image complète sans lignes noires à la fin
    DrawBlitPal(PIC_, PIC_PAL_,
                0, 0,
                0, 0,
                menu_W, menu_H,
                menu_W_FULL, COL_GREEN);
    DispUpdate();
}

void SND_Fade_Up_InGame(void){
	if (SNDUP==1) return;
		 SNDUP=(SNDUP<1)?SNDUP+0.015f:1;
         VolumeSoundChan(0, SNDUP); 
}

void SND_Fade_Up(void){
	if (SNDUP==1) return;
		 SNDUP=(SNDUP<1)?SNDUP+0.132f:1;
         VolumeSoundChan(0, SNDUP); 
}

void SND_Fade_Down(void){
	if (SNDUP==0) return;
		 SNDUP=(SNDUP>0)?SNDUP-0.132f:0;
	     VolumeSoundChan(0, SNDUP);    
}
