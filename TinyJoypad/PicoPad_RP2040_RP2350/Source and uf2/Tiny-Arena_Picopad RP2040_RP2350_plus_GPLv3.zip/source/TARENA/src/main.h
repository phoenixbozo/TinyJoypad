//  >>>>> T-I-N-Y A-R-E-N-A for PicoPad RP2040 & RP2350+ GPL v3 <<<<<
//                    Programmer: Daniel C 2026
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://WWW.TINYJOYPAD.COM
//           https://sites.google.com/view/arduino-collection

//  tiny-Arena is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
// Reference in file "COPYING.txt".
// -__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-__-


// The tiny-Arena source code include commands referencing to librairy 
// PicoLibSDK who is not include in the source code.

// A uf2 file "TARENA.UF2" is provided with the source code which includes
// compiled code from the PicoLibSDK library.
// Reference in the file "PicoLibSDK_Readme.txt".

// Please note that the TARENA.UF2 file is a compiled version with code from
// the PicoLibSDK library pack by Miroslav Nemecek. Thank you to him!
// https://github.com/Panda381/PicoLibSDK


#ifndef _MAIN_H
#define _MAIN_H

void VbufferBypass(uint8_t Y_,uint8_t X_,uint8_t Byte_,uint16_t col_);
inline void BobPosMove(void) ;
inline bool isWall(int x, int y) ;
inline bool checkCollision(float px, float py) ;
void updateTentacles(void) ;
inline void drawSprite2Bit(int8_t x0, int8_t y0, const uint8_t* sprite) ;
void drawWorldSprites() ;
inline void VBuf(int x, int y) ;
void renderRaycast() ;
void shoot() ;
static inline uint8_t SliceByte(uint8_t page, uint8_t data) ;
void Tiny_Flip(void) ;
void Direct_Flip(uint8_t (*buffer)[64],uint16_t col_) ;
void INIT_NEW_GAME_TARENA(void);
void loop_TARENA() ;

#endif // _MAIN_H
