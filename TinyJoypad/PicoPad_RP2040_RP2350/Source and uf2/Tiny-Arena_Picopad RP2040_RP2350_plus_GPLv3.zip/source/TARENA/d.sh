#!/bin/bash

# Delete...

export TARGET="TARENA"
../../../_d1.sh
