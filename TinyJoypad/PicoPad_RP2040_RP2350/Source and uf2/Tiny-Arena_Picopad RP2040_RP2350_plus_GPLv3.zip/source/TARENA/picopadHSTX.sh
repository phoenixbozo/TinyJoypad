#!/bin/bash

# Compilation...
./c.sh picopadhstx
