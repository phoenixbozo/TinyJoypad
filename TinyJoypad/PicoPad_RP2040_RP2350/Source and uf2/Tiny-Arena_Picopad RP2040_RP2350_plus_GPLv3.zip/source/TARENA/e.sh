#!/bin/bash
# Export to hardware...

export TARGET="TARENA"
../../../_e1.sh
