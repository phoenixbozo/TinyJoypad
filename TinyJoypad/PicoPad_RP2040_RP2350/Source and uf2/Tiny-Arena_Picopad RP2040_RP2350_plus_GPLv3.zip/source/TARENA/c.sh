#!/bin/bash

# Compilation...

export TARGET="TARENA"
export GRPDIR="TINYGAME"
export MEMMAP=""

../../../_c1.sh "$1"
