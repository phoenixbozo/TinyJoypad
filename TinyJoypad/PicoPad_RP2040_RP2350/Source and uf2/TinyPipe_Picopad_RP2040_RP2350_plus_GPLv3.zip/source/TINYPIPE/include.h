
// ****************************************************************************
//                                 
//                              Includes
//
// ****************************************************************************

// ----------------------------------------------------------------------------
//                                   Includes
// ----------------------------------------------------------------------------

#include INCLUDES_H		// all includes

#include "src/PICOKIT.h"
#include "src/ELECTROLIB.h"
#include "src/spritebank_TPIPE.h"
#include "src/CLASS_TPIPE.h"
#include "src/main.h"		// main code
