#!/bin/bash
# Export to hardware...

export TARGET="NOHZDYVE"
../../../_e1.sh
