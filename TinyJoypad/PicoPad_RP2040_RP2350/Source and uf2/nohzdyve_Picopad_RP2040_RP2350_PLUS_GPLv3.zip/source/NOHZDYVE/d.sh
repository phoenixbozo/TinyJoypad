#!/bin/bash

# Delete...

export TARGET="NOHZDYVE"
../../../_d1.sh
