#!/bin/bash

# Compilation...

export TARGET="NOHZDYVE"
export GRPDIR="TINYGAME"
export MEMMAP=""

../../../_c1.sh "$1"
