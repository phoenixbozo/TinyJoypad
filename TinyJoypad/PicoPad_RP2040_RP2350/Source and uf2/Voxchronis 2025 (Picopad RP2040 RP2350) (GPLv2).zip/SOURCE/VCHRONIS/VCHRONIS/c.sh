#!/bin/bash

# Compilation...

export TARGET="VCHRONIS"
export GRPDIR="VCHRONIS"
export MEMMAP=""

../../../_c1.sh "$1"
