#!/bin/bash

# Delete...

export TARGET="VCHRONIS"
../../../_d1.sh
