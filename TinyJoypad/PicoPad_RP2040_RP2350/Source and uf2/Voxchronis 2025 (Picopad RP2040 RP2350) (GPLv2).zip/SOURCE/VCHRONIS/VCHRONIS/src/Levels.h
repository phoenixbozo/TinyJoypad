//     >>>>> VOXCHRONIS for PicoPad RP2040 & RP2350+  GPLv2 <<<<<
//                    Programmer: Daniel C 2025
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection
//
// VOXCHRONIS is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2.0 as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// The full license text is available in the file "GPL-2.0.txt".
//
// This source code includes commands referencing the PicoLibSDK library,
// which is not included in this source distribution.
//
// A compiled .uf2 file "VCHRONIS.UF2" is provided, which includes code from
// the PicoLibSDK library by Miroslav Nemecek (https://github.com/Panda381/PicoLibSDK).
// PicoLibSDK includes code from the Raspberry Pi Pico SDK (under BSD 3-Clause License)
// and floating-point mathematics library by Mark Owen (under GNU General Public License version 2.0).
// See "PicoLibSDK_Readme.txt" for details on PicoLibSDK licensing and usage.
//
// Thanks to Miroslav Nemecek for PicoLibSDK, Mark Owen for the floating-point
// mathematics library, and Raspberry Pi for the Pico SDK.



#ifndef LEVELS_H
#define LEVELS_H

#define TOTAL_LVL 16

extern const uint8_t Level0[];
extern const uint8_t Level1[];
extern const uint8_t Level2[];
extern const uint8_t Level3[];
extern const uint8_t Level4[];
extern const uint8_t Level5[];
extern const uint8_t Level6[];
extern const uint8_t Level7[];
extern const uint8_t Level8[];
extern const uint8_t Level9[];
extern const uint8_t Level10[];
extern const uint8_t Level11[];
extern const uint8_t Level12[];
extern const uint8_t Level13[];
extern const uint8_t Level14[];
extern const uint8_t LevelBR[];

#endif // LEVELS_H

