//     >>>>> VOXCHRONIS for PicoPad RP2040 & RP2350+  GPLv2 <<<<<
//                    Programmer: Daniel C 2025
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection
//
// VOXCHRONIS is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2.0 as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// The full license text is available in the file "GPL-2.0.txt".
//
// This source code includes commands referencing the PicoLibSDK library,
// which is not included in this source distribution.
//
// A compiled .uf2 file "VCHRONIS.UF2" is provided, which includes code from
// the PicoLibSDK library by Miroslav Nemecek (https://github.com/Panda381/PicoLibSDK).
// PicoLibSDK includes code from the Raspberry Pi Pico SDK (under BSD 3-Clause License)
// and floating-point mathematics library by Mark Owen (under GNU General Public License version 2.0).
// See "PicoLibSDK_Readme.txt" for details on PicoLibSDK licensing and usage.
//
// Thanks to Miroslav Nemecek for PicoLibSDK, Mark Owen for the floating-point
// mathematics library, and Raspberry Pi for the Pico SDK.

#include "../include.h"

// Draw Frame by second
//#define FPS_DRAW

// Defines
// Minimum enemy distance for collision detection
#define COLLISION_DISTANCE_M 0.5f
#define MIN_ENEMY_DISTANCE 0.5f
#define MIN_ENEMY_DISTANCE_SQUARED (MIN_ENEMY_DISTANCE * MIN_ENEMY_DISTANCE)

// Collision distance for general interactions
#define COLLISION_DISTANCE 0.7f

// Damage dealt by sprites
#define SPRITE_DAMAGE 25
// Trigger distance for enemy activation
#define DIST_TRIG_ENEMY 81.0f
// Screen buffer dimensions
#define BUFFER_SCREEN_WIDTH 160
#define BUFFER_SCREEN_HEIGHT 120
#define MaxRes 3
#define BUFFER_SCREEN_WIDTH_MAX 320
// Player ammo and health limits
#define MAX_AMMO 250
#define START_AMMO 150
#define ADD_AMMO 50
#define MAX_HEALTH 200
#define START_HEALTH 100
#define ADD_HEALTH 50
// Fireball properties
#define FIREBALL_INITIAL_SIZE 0.2f
#define FIREBALL_SCALE_FACTOR 18.0f
#define FIREBALL_MAX_SIZE 50
#define FIREBALL_SPEED 12.0f
#define FIREBALL_LIFETIME 5.0f
#define FIREBALL_COLLISION_DISTANCE 0.75f
#define FIREBALL_DAMAGE 10
#define MAX_FIREBALLS 1
// Field of view and movement speeds
#define FOV (80.0 * (M_PI / 180.0))
#define MOVE_SPEED 0.1
#define ROT_SPEED 0.1
// Texture dimensions
#define HAUTEUR_TEXTURE 80
#define LARGEUR_TEXTURE 80
// Particle system parameters
#define MAX_PARTICLES 100
#define GRAVITY -0.40f
#define PARTICLE_COUNT_PER_IMPACT 10
#define PARTICLE_SPEED_XY 0.40f
#define PARTICLE_SPEED_Z_MIN 0.5f
#define PARTICLE_SPEED_Z_MAX 2.0f
#define PARTICLE_LIFETIME 0.4f
#define PARTICLE_SIZE_MIN 0.01f
#define PARTICLE_SIZE_RANGE 0.04f
#define PARTICLE_SCALE_FACTOR 0.3f
#define PARTICLE_COLOR_ENEMY 0xF800
#define PARTICLE_COLOR_WALL 0xFEF4
// Fog rendering distances
#define FOG_START 0.5f
#define FOG_END 8.0f
// Trigonometric table size
#define TRIG_TABLE_SIZE 3600
// Door animation steps
#define DOOR_OPENING_STEPS 20
// Camera bobbing points
#define BOB_POINTS 14
// Raycasting and movement steps
#define RAY_STEP 1
#define STEP_SIZE 0.01
// Map element types
#define EMPTY 0
#define WALL 1
#define ENEMY 2
#define DOOR 3
#define CARD 4
// Maximum number of sprites
#define MAX_SPRITES 100
// Shooting repetition rate
#define ShootRep 3

// Structures
// Sprite vertical position enumeration
typedef enum {
  SPRITE_POS_FLOOR = 0,
  SPRITE_POS_CENTER = 1,
  SPRITE_POS_CEILING = 2
} SpritePosition;

// Particle structure for effects
typedef struct {
  float x, y, z;
  float prevX, prevY;
  float vx, vy, vz;
  float lifetime;
  float size;
  int active;
  int type;
  u16 color;
  int hasHitGround;
} Particle;

// Fireball structure for projectiles
typedef struct {
  float x, y, z;
  float prevX, prevY;
  float vx, vy, vz;
  float lifetime;
  float size;
  int active;
  u16 color;
} Fireball;

// Sprite structure for game objects
typedef struct {
  float x, y;
  bool active;
  uint8_t Mapref;
  uint8_t Anim;
  uint8_t DeadActivate;
  bool isCollectable;
  uint8_t spriteType;
  int health;
  float scale;
  SpritePosition verticalPos;
} Sprite;

// Keycard inventory structure
typedef struct {
  bool RedCard;
  bool GreenCard;
  bool BlueCard;
  bool GoldCard;
} KEYCARD;

// Variables
// Player code string
char code[15] = "00000000000000"; //00000000000000
// Resolution arrays
const uint16_t ResWidth[4] = { 40, 80, 160, 320 };
const uint8_t ResHeight[4] = { 30, 60, 120, 240 };
const uint8_t ResMult[4] = { 8, 4, 2, 1 };
// Small screen dimensions
uint16_t SMALL_SCREEN_WIDTH = 160;
uint8_t SMALL_SCREEN_HEIGHT = 120;
// Current resolution index
uint8_t ResIndex = 2;
// Resolution multiplier
uint8_t MULTI_RES = (SCREEN_WIDTH / SMALL_SCREEN_WIDTH);
// Screen buffer
uint16_t My_buffer[BUFFER_SCREEN_HEIGHT][BUFFER_SCREEN_WIDTH];
// Texture pointers
const u8 *PIC[] = {
  NULL, &tex1[0], &enemy[0], &door1[0], &GreenCard[0], &tex2[0], &tex3[0], &tex4[0], &RedCard[0],
  &BlueCard[0], &ammo[0], &GoldCard[0], &FinalDoor[0], &sphere[0], &medic[0],
  &door2[0], &door3[0], &door4[0], &enemy2[0], &tex5[0], &tex6[0], &tex7[0],
  &tex8[0], &tex9[0], &tex10[0], &tex11[0], &Skull[0], &BR[0], NULL, &enemy3[0]
};
// Palette pointers
const u16 *PIC_PAL[] = {
  NULL, &tex1_Pal[0], &enemy_Pal[0], &door1_Pal[0], &GreenCard_Pal[0],
  &tex2_Pal[0], &tex3_Pal[0], &tex4_Pal[0], &RedCard_Pal[0], &BlueCard_Pal[0], &ammo_Pal[0],
  &GoldCard_Pal[0], &FinalDoor_Pal[0], &sphere_Pal[0], &medic_Pal[0], &door2_Pal[0],
  &door3_Pal[0], &door4_Pal[0], &enemy2_Pal[0], &tex5_Pal[0], &tex6_Pal[0], &tex7_Pal[0],
  &tex8_Pal[0], &tex9_Pal[0], &tex10_Pal[0], &tex11_Pal[0], &Skull_Pal[0], &BR_Pal[0], NULL, &enemy3_Pal[0]
};
// Texture heights
const u16 PIC_H[] = {
  0, tex1_H, enemy_H, door1_H, GreenCard_H, tex2_H, tex3_H, tex4_H,
  RedCard_H, BlueCard_H, ammo_H, GoldCard_H, FinalDoor_H, sphere_H, medic_H, door2_H,
  door3_H, door4_H, enemy2_H, tex5_H, tex6_H, tex7_H, tex8_H, tex9_H, tex10_H, tex11_H, Skull_H, BR_H, 0, enemy3_H
};
// Texture widths
const u16 PIC_W_FULL[] = {
  0, tex1_W_FULL, enemy_W_FULL, door1_W_FULL, GreenCard_W_FULL,
  tex2_W_FULL, tex3_W_FULL, tex4_W_FULL, RedCard_W_FULL, BlueCard_W_FULL, ammo_W_FULL,
  GoldCard_W_FULL, FinalDoor_W_FULL, sphere_W_FULL, medic_W_FULL, door2_W_FULL,
  door3_W_FULL, door4_W_FULL, enemy2_W_FULL, tex5_W_FULL, tex6_W_FULL, tex7_W_FULL,
  tex8_W_FULL, tex9_W_FULL, tex10_W_FULL, tex11_W_FULL, Skull_W_FULL, BR_W_FULL, 0, enemy3_W_FULL
};
// Weapon texture pointers
const u8 *GUNPIC[2] = { &Weapon[0], &fire[0] };
const u16 *GUNPIC_PAL[2] = { &Weapon_Pal[0], &fire_Pal[0] };
// Frame buffer
extern u16 FrameBuf[320 * 240];
// Trigonometric lookup tables
static float cos_table[TRIG_TABLE_SIZE];
static float sin_table[TRIG_TABLE_SIZE];
// Flash effect variables
uint16_t FlahsColor = COL_RED;
float hitFlashTime = 0.0f;
const float HIT_FLASH_DURATION = 0.5f;
const float HIT_FLASH_FREQUENCY = 10.0f;
// Particle and fireball arrays
Particle particles[MAX_PARTICLES];
Fireball fireballs[MAX_FIREBALLS];
// Player movement variables
float forwardDistance = 0.0f;
const float DISTANCE_PER_FRAME = 0.05f;
float velocityX = 0.0f;
float velocityY = 0.0f;
float angularVelocity = 0.0f;
const float ACCELERATION = 15.0f;
const float ANGULAR_ACCELERATION = 15.0f;
const float FRICTION = 0.88f;
const float ANGULAR_FRICTION = 0.88f;
const float MAX_SPEED = 30.0f;
const float MAX_ANGULAR_SPEED = 30.0f;
// Weapon firing state
int gunFiring = 0;
int gunFireDurationFrames = 2;
int gunFireCounter = 0;
uint8_t GunReady = 0;
// Door animation variables
int autoOpeningDoorX = -1;
int autoOpeningDoorY = -1;
float autoOpeningTimer = 0.0f;
const float DOOR_OPENING_DURATION = 0.4f;
// Camera bobbing positions
static const uint8_t bobPositions[][2] = {
  { 8, 2 }, { 10, 0 }, { 12, 1 }, { 13, 3 }, { 12, 5 }, { 10, 6 }, { 8, 5 },
  { 5, 2 }, { 3, 0 }, { 1, 1 }, { 0, 3 }, { 1, 5 }, { 3, 6 }, { 5, 5 }
};
int bobIndex = 0;
// Wall height array
float wallHeights[] = {
  0.0, 1.0, 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0,
  1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0
};
// Keycard inventory
KEYCARD KeyCard;

// Sprite scale factors
const float spriteScales[] = {
  0.0f, 0.0f, 1.0f, 0.0f, 0.4f, 0.0f, 0.0f, 0.0f, 0.4f, 0.4f, 0.4f, 0.4f, 0.0f,
  0.4f, 0.4f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.4f, 0.0f, 0.0f, 1.0f
};
// Game state variables
uint8_t Level_Use = 0;
uint16_t Total_Kill = 0;
uint8_t Total_Skull = 0;
// Level data pointers
const u8 *LEVELS[TOTAL_LVL] = {
  &Level0[0], &Level1[0], &Level2[0], &Level3[0], &Level4[0], &Level5[0],
  &Level6[0], &Level7[0], &Level8[0], &Level9[0], &Level10[0], &Level11[0],
  &Level12[0], &Level13[0], &Level14[0], &LevelBR[0]
};
// Map dimensions
uint8_t MAP_SIZE_X = 50;
uint8_t MAP_SIZE_Y = 50;
// Sprite array and count
Sprite sprites[MAX_SPRITES];
int NUM_SPRITES = 0;
// Sprite type array
const uint8_t TYPE_SPK[] = {
  EMPTY, WALL, ENEMY, DOOR, CARD, WALL, WALL, WALL, CARD, CARD, CARD, CARD,
  DOOR, CARD, CARD, DOOR, DOOR, DOOR, ENEMY, WALL, WALL, WALL, WALL, WALL,
  WALL, WALL, CARD, WALL, EMPTY, ENEMY
};
// Animated sprite flags
const uint8_t ANIMATED_SPK[] = {
  0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
};
// Player position and state
float playerX = 1.5, playerY = 1.5, playerAngle = 0.0;
float targetAngle = 0.0;
int playerHealth = START_HEALTH;
uint8_t playerAmmo = START_AMMO;
uint16_t score = 0;
uint8_t gameState = 0;
// Door state array
int doorStates[50][50] = { 0 };
// Z-buffer for rendering
float zBuffer[BUFFER_SCREEN_WIDTH_MAX];
// FPS tracking
static uint32_t lastTime = 0;
static int frameCount = 0;
static float fps = 0.0f;
// Trigger flags
bool Trig1 = false;
bool Trig2 = false;
bool Trig3 = false;
// Sound channel
u8 SND_Chan = 1;

// Functions
// Create RGB565 color from RGB components
__attribute__((always_inline)) inline uint16_t color(uint8_t R, uint8_t G, uint8_t B) {
  return ((R & 0x1F) << 11) | ((G & 0x3F) << 5) | (B & 0x1F);
}

// Draw pixel to frame buffer with bounds checking
__attribute__((always_inline)) inline void DrawPixel(int x, int y, u16 col) {
  if (x >= 0 && x < SCREEN_WIDTH && y >= 0 && y < SCREEN_HEIGHT) {
    FrameBuf[y * SCREEN_WIDTH + x] = col;
  }
}

// Draw pixel to small screen buffer
__attribute__((always_inline)) inline void MyBuffer_DrawPixel(int x, int y, uint16_t color) {
  if (x >= 0 && x < SMALL_SCREEN_WIDTH && y >= 0 && y < SMALL_SCREEN_HEIGHT) {
    My_buffer[y][x] = color;
  }
}

// Draw pixel directly to frame buffer
__attribute__((always_inline)) inline void Direct_DrawPixel(int x, int y, uint16_t color) {
  if (x < 0 || x + 1 > SCREEN_WIDTH || y < 0 || y + 1 > SCREEN_HEIGHT) {
    return;
  }
  FrameBuf[y * SCREEN_WIDTH + x] = color;
}

// Draw pixel based on resolution index
__attribute__((always_inline)) inline void drawPixel(int x, int y, uint16_t color) {
  switch (ResIndex) {
    case 3:
      Direct_DrawPixel(x, y, color);
      break;
    default:
      MyBuffer_DrawPixel(x, y, color);
      break;
  }
}

// Get value from current level map
__attribute__((always_inline)) inline uint8_t getLevelValue(uint8_t x, uint8_t y) {
  const uint8_t *level = LEVELS[Level_Use];
  uint8_t width = level[0];
  if (x >= width || y >= level[1]) {
    return 0;
  }
  return level[2 + y * width + x];
}

// Reduce player health and trigger flash effect
void playerHealthDown(uint8_t Remove_) {
  playerHealth -= Remove_;
  playerHealth = (playerHealth > 0) ? playerHealth : 0;
  MakeColorFlash(COL_RED);
}

// Play sound effects
void SND_PLsnd1(void) {
  PlaySoundChan(1, PLsnd1, 4707, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_PLsnd2(void) {
  PlaySoundChan(1, PLsnd2, 6421, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_PLsnd3(void) {
  PlaySoundChan(0, PLsnd3, 16745, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_ENsnd1(void) {
  PlaySoundChan(3, ENsnd1, 19349, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_ENsnd2(void) {
  PlaySoundChan(3, ENsnd2, 47562, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_DOOR(void) {
  PlaySoundChan(3, door, 14907, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_FIRE(void) {
  PlaySoundChan(2, GunFire, 6358, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_PICKUP(void) {
  PlaySoundChan(3, PICKUP, 2106, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_ENDLVL(void) {
  PlaySoundChan(1, endlvl, 74496, 0, 1, 1, SNDFORM_PCM, 1);
}

void SND_BUTTON(void) {
  PlaySoundChan(1, Button, 1127, 0, 1, 1, SNDFORM_PCM, 1);
}

// Select and play enemy sound based on sprite type
void EN_SND_SELECT(uint8_t i_) {
  switch (sprites[i_].spriteType) {
    case 2: SND_ENsnd1(); break;
    case 18: SND_ENsnd2(); break;
    case 29: SND_ENsnd1(); break;
    default: break;
  }
}

// Reset trigger flags
void ResetTriggers(void) {
  Trig1 = false;
}

__attribute__((always_inline)) inline void VarTriggerDeltaTime(float deltaTime) {
  static float timeAccumulator1 = 0.0f; // Accumulates time for sprite animation and gun readiness
  static float timeAccumulator2 = 0.0f; // Accumulates time for particle and fireball updates
  static float timeAccumulator3 = 0.0f; // Accumulates time for hand movement animation
  const float triggerInterval3 = 1.0f / 12.0f; // 12 Hz for Trig3 (hand movement)
  const float triggerInterval2 = 1.0f / 22.0f; // 22 Hz for Trig2 (particles/fireballs)
  const float triggerInterval1 = 1.0f / 14.0f; // 14 Hz for Trig1 (sprite/gun)

  // Update accumulator for sprite animation and gun readiness
  timeAccumulator1 += deltaTime;
  if (timeAccumulator1 >= triggerInterval1) {
    Trig1 = true; // Trigger sprite animation and gun readiness
    timeAccumulator1 = fmod(timeAccumulator1, triggerInterval1); // Reset with remainder
  }

  // Update accumulator for particles and fireballs
  timeAccumulator2 += deltaTime;
  if (timeAccumulator2 >= triggerInterval2) {
    Trig2 = true; // Trigger particle and fireball updates
    timeAccumulator2 = fmod(timeAccumulator2, triggerInterval2); // Reset with remainder
  }

  // Update accumulator for hand movement
  timeAccumulator3 += deltaTime;
  if (timeAccumulator3 >= triggerInterval3) {
    Trig3 = true; // Trigger hand movement animation
    timeAccumulator3 = fmod(timeAccumulator3, triggerInterval3); // Reset with remainder
  }
}

void SetDeadAnim(uint8_t Index_) {
  // Exit if death animation is already active
  if (sprites[Index_].DeadActivate) return;
  EN_SND_SELECT(Index_); // Play sound for sprite
  sprites[Index_].DeadActivate = 1; // Activate death animation
  sprites[Index_].Anim = 12; // Set initial death animation frame
}

__attribute__((always_inline)) inline void UpdateSPKAnimation(uint8_t Index_) {
  if (Trig1 == false) return; // Skip if animation trigger is not active
  switch (sprites[Index_].DeadActivate) {
    case 0: // Normal animation cycle
      sprites[Index_].Anim = (sprites[Index_].Anim < 11) ? sprites[Index_].Anim + 1 : 0; // Cycle through frames 0-11
      break;
    case 1: // Death animation
      if (sprites[Index_].Anim < 23) { sprites[Index_].Anim++; } // Increment death animation frame up to 23
      break;
  }
}

uint16_t Return_Health(uint8_t Data_) {
  // Return health value based on sprite type
  switch (Data_) {
    case 2: return 60; break;
    case 18: return 90; break;
    case 29: return 880; break;
    default: return 60; break;
  }
}

void init_sprites_from_map() {
  NUM_SPRITES = 0; // Reset sprite count
  for (int y = 0; y < MAP_SIZE_Y; y++) {
    for (int x = 0; x < MAP_SIZE_X; x++) {
      // Set player position if map value is 28
      if (getLevelValue(x, y) == 28) {
        playerX = float(x) + 0.5f; // Center player in cell
        playerY = float(y) + 0.5f;
      }
      // Initialize sprites for enemies or collectable cards
      if (TYPE_SPK[getLevelValue(x, y)] == ENEMY || TYPE_SPK[getLevelValue(x, y)] == CARD) {
        if (NUM_SPRITES < MAX_SPRITES) {
          sprites[NUM_SPRITES].x = x + 0.5f; // Center sprite in cell
          sprites[NUM_SPRITES].y = y + 0.5f;
          sprites[NUM_SPRITES].active = true; // Mark sprite as active
          sprites[NUM_SPRITES].Mapref = getLevelValue(x, y); // Store map reference
          sprites[NUM_SPRITES].Anim = 0; // Initialize animation frame
          sprites[NUM_SPRITES].DeadActivate = 0; // Initialize death animation flag
          sprites[NUM_SPRITES].isCollectable = (TYPE_SPK[getLevelValue(x, y)] == CARD); // Set collectable status
          sprites[NUM_SPRITES].spriteType = getLevelValue(x, y); // Set sprite type
          sprites[NUM_SPRITES].health = (TYPE_SPK[getLevelValue(x, y)] == ENEMY) ? Return_Health(getLevelValue(x, y)) : 0; // Assign health for enemies
          sprites[NUM_SPRITES].scale = (TYPE_SPK[getLevelValue(x, y)] == ENEMY) ? 1.0f : 0.5f; // Set scale based on type
          // Set vertical position based on sprite type
          sprites[NUM_SPRITES].verticalPos = (TYPE_SPK[getLevelValue(x, y)] == ENEMY) ? SPRITE_POS_CENTER : SPRITE_POS_FLOOR;
          NUM_SPRITES++; // Increment sprite count
        }
      }
    }
  }
}

void initNewGame(void) {
  // Initialize player variables
  playerAmmo = START_AMMO;
  gameState = 0;
  playerHealth = START_HEALTH;
  score = 0;
  playerX = 1.5;
  playerY = 1.5;
  playerAngle = 0.0;
  targetAngle = 0.0;
  bobIndex = 0;
  velocityX = 0.0f;
  velocityY = 0.0f;
  angularVelocity = 0.0f;
  forwardDistance = 0.0f;
  memset(doorStates, 0, sizeof(doorStates)); // Reset door states
  init_sprites_from_map(); // Initialize sprites from map
  // Deactivate all particles
  for (int i = 0; i < MAX_PARTICLES; i++) {
    particles[i].active = 0;
  }
  // Deactivate all fireballs
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    fireballs[i].active = 0;
  }
  lastTime = 0;
  frameCount = 0;
  fps = 0.0f; // Reset FPS counter
}

__attribute__((always_inline)) inline const u8 *getNextImageAddress(uint8_t Index_, uint8_t MapIndex_) {
  UpdateSPKAnimation(Index_); // Update sprite animation
  // Return address of sprite image based on animation frame and type
  return PIC[MapIndex_] + ANIMATED_SPK[MapIndex_] * sprites[Index_].Anim * ((TYPE_SPK[MapIndex_] == ENEMY) ? 10000 : 2400);
}

void InitKeyCard(void) {
  // Reset all key card states
  KeyCard.RedCard = 0;
  KeyCard.GreenCard = 0;
  KeyCard.BlueCard = 0;
  KeyCard.GoldCard = 0;
}

__attribute__((always_inline)) inline void DrawGradientCircle(int centerX, int centerY, int radius, uint16_t outerColor) {
  // Extract RGB565 components
  uint16_t r565 = (outerColor >> 11) & 0x1F;
  uint16_t g565 = (outerColor >> 5) & 0x3F;
  uint16_t b565 = outerColor & 0x1F;
  // Draw a gradient circle centered at (centerX, centerY)
  for (int y = -radius; y <= radius; y++) {
    for (int x = -radius; x <= radius; x++) {
      int distSq = x * x + y * y;
      int radiusSq = radius * radius;
      if (distSq <= radiusSq) {
        float dist = sqrtf(distSq);
        float t = dist / radius; // Interpolation factor
        // Interpolate color from white (center) to outerColor
        uint16_t r_pixel = (uint16_t)((1 - t) * 31 + t * r565);
        uint16_t g_pixel = (uint16_t)((1 - t) * 63 + t * g565);
        uint16_t b_pixel = (uint16_t)((1 - t) * 31 + t * b565);
        uint16_t pixelColor565 = (r_pixel << 11) | (g_pixel << 5) | b_pixel;
        drawPixel(centerX + x, centerY + y, pixelColor565); // Draw pixel
      }
    }
  }
}

__attribute__((always_inline)) inline void normalizeAngle(float *angle) {
  // Normalize angle to range [-π, π]
  while (*angle > M_PI) *angle -= 2 * M_PI;
  while (*angle < -M_PI) *angle += 2 * M_PI;
}

void init_trig_tables() {
  // Precompute cosine and sine tables for angles from 0 to 2π
  for (int i = 0; i < TRIG_TABLE_SIZE; i++) {
    float angle = (i * 2 * M_PI) / TRIG_TABLE_SIZE;
    cos_table[i] = cosf(angle);
    sin_table[i] = sinf(angle);
  }
}

__attribute__((always_inline)) inline float fast_cos(float angle) {
  // Fast cosine lookup using precomputed table
  int index = (int)(angle * (TRIG_TABLE_SIZE / (2 * M_PI))) % TRIG_TABLE_SIZE;
  if (index < 0) index += TRIG_TABLE_SIZE; // Handle negative angles
  return cos_table[index];
}

__attribute__((always_inline)) inline float fast_sin(float angle) {
  // Fast sine lookup using precomputed table
  int index = (int)(angle * (TRIG_TABLE_SIZE / (2 * M_PI))) % TRIG_TABLE_SIZE;
  if (index < 0) index += TRIG_TABLE_SIZE; // Handle negative angles
  return sin_table[index];
}

__attribute__((always_inline)) inline u16 applyFog(u16 color_, float distance) {
  // Apply fog effect based on distance
  if (distance <= FOG_START) return color_;
  if (distance >= FOG_END) return color(0, 0, 0); // Fully fogged (black)
  float fogFactor = (FOG_END - distance) / (FOG_END - FOG_START); // Fog interpolation
  int r = (color_ >> 11) & 0x1F;
  int g = (color_ >> 5) & 0x3F;
  int b = color_ & 0x1F;
  // Dim color based on fog factor
  r = (int)(r * fogFactor);
  g = (int)(g * fogFactor);
  b = (int)(b * fogFactor);
  return color(r, g, b);
}

void createFireball(float startX, float startY, float targetX, float targetY) {
  // Create a fireball at the specified position moving toward the target
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    if (!fireballs[i].active) {
      fireballs[i].x = startX;
      fireballs[i].y = startY;
      fireballs[i].prevX = startX;
      fireballs[i].prevY = startY;
      fireballs[i].z = -0.0833f; // Initial vertical position
      float dx = targetX - startX;
      float dy = targetY - startY;
      float dist = sqrt(dx * dx + dy * dy);
      if (dist < 0.1f) dist = 0.1f; // Prevent division by zero
      // Set velocity based on direction and speed
      fireballs[i].vx = (dx / dist) * FIREBALL_SPEED;
      fireballs[i].vy = (dy / dist) * FIREBALL_SPEED;
      fireballs[i].vz = 0.0f;
      fireballs[i].lifetime = FIREBALL_LIFETIME;
      fireballs[i].size = FIREBALL_INITIAL_SIZE;
      fireballs[i].color = color(31, 20, 0); // Orange color
      fireballs[i].active = 1; // Activate fireball
      break;
    }
  }
}

void createParticles(float hitX, float hitY, float hitZ, int isEnemyHit) {
  // Create particles at the specified position
  int numParticles = PARTICLE_COUNT_PER_IMPACT;
  for (int i = 0; i < MAX_PARTICLES && numParticles > 0; i++) {
    if (!particles[i].active) {
      // Randomize particle position slightly
      particles[i].x = hitX + ((float)rand() / RAND_MAX - 0.5f) * 0.06f;
      particles[i].y = hitY + ((float)rand() / RAND_MAX - 0.5f) * 0.06f;
      particles[i].z = fmin(hitZ, 0.0f); // Ensure Z is not above ground
      float angle = ((float)rand() / RAND_MAX) * 2 * M_PI; // Random direction
      float speed = ((float)rand() / RAND_MAX) * PARTICLE_SPEED_XY;
      // Set particle velocity
      particles[i].vx = cosf(angle) * speed;
      particles[i].vy = sinf(angle) * speed;
      particles[i].vz = -PARTICLE_SPEED_Z_MIN - ((float)rand() / RAND_MAX) * (PARTICLE_SPEED_Z_MAX - PARTICLE_SPEED_Z_MIN);
      particles[i].lifetime = PARTICLE_LIFETIME + ((float)rand() / RAND_MAX) * 0.2f;
      particles[i].size = PARTICLE_SIZE_MIN + ((float)rand() / RAND_MAX) * PARTICLE_SIZE_RANGE;
      particles[i].color = isEnemyHit ? PARTICLE_COLOR_ENEMY : PARTICLE_COLOR_WALL; // Color based on hit type
      particles[i].active = 1; // Activate particle
      particles[i].type = 0; // Default particle type
      particles[i].hasHitGround = 0; // Reset ground collision flag
      numParticles--;
    }
  }
}

void updateParticles(float deltaTime) {
  // Update active particles
  for (int i = 0; i < MAX_PARTICLES; i++) {
    if (particles[i].active) {
      if (particles[i].type == 0) { // Regular particles (e.g., impact effects)
        if (particles[i].z > -0.5f) { // Above ground
          // Update position with velocity
          particles[i].x += particles[i].vx * deltaTime;
          particles[i].y += particles[i].vy * deltaTime;
          particles[i].z += particles[i].vz * deltaTime;
          particles[i].vz += GRAVITY * deltaTime; // Apply gravity
          if (particles[i].z < -0.5f) { // Ground collision
            particles[i].z = -0.5f; // Snap to ground
            particles[i].vz = -particles[i].vz * 0.5f; // Bounce with damping
            particles[i].vx *= 0.7f; // Reduce horizontal velocity
            particles[i].vy *= 0.7f;
            if (fabs(particles[i].vz) < 0.1f) particles[i].vz = 0.0f; // Stop small bounces
          }
        } else {
          particles[i].lifetime -= deltaTime; // Reduce lifetime on ground
        }
        if (particles[i].lifetime <= 0) {
          particles[i].active = 0; // Deactivate expired particles
        }
      } else if (particles[i].type == 1) { // Other particle type (e.g., projectiles)
        // Update position
        particles[i].x += particles[i].vx * deltaTime;
        particles[i].y += particles[i].vy * deltaTime;
        particles[i].z += particles[i].vz * deltaTime;
        particles[i].lifetime -= deltaTime;
        float dx = particles[i].x - playerX;
        float dy = particles[i].y - playerY;
        float distance = sqrt(dx * dx + dy * dy);
        int mapX = (int)particles[i].x;
        int mapY = (int)particles[i].y;
        // Check for collision with walls or closed doors
        if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
          if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
            particles[i].active = 0; // Deactivate on collision
            createParticles(particles[i].x, particles[i].y, 0.0f, 0); // Create impact particles
          }
        }
        if (particles[i].lifetime <= 0) {
          particles[i].active = 0; // Deactivate expired particles
        }
      }
    }
  }
}

__attribute__((always_inline)) inline void MakeColorFlash(uint16_t Color_) {
  // Trigger a color flash effect
  hitFlashTime = HIT_FLASH_DURATION;
  FlahsColor = Color_; // Set flash color
}

void updateFireballs(float deltaTime) {
  if (deltaTime > 0.016f) deltaTime = 0.016f; // Cap deltaTime to prevent large jumps
  // Update active fireballs
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    if (fireballs[i].active) {
      fireballs[i].prevX = fireballs[i].x; // Store previous position
      fireballs[i].prevY = fireballs[i].y;
      // Update position
      fireballs[i].x += fireballs[i].vx * deltaTime;
      fireballs[i].y += fireballs[i].vy * deltaTime;
      fireballs[i].z += fireballs[i].vz * deltaTime;
      fireballs[i].lifetime -= deltaTime; // Reduce lifetime
      float dx = fireballs[i].x - playerX;
      float dy = fireballs[i].y - playerY;
      float distance = sqrt(dx * dx + dy * dy);
      // Check for player collision
      if (distance < FIREBALL_COLLISION_DISTANCE) {
        playerHealthDown(FIREBALL_DAMAGE); // Apply damage to player
        SND_PLsnd1(); // Play hit sound
        fireballs[i].active = 0; // Deactivate fireball
      }
      int mapX = (int)fireballs[i].x;
      int mapY = (int)fireballs[i].y;
      // Check for collision with walls or closed doors
      if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
        if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
          fireballs[i].active = 0; // Deactivate fireball
        }
      }
      if (fireballs[i].lifetime <= 0) {
        fireballs[i].active = 0; // Deactivate expired fireball
      }
    }
  }
}

__attribute__((always_inline)) inline void drawFireballs() {
  // Draw active fireballs
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    if (fireballs[i].active) {
      float spriteX = fireballs[i].x - playerX;
      float spriteY = fireballs[i].y - playerY;
      float distance = sqrt(spriteX * spriteX + spriteY * spriteY);
      if (distance < 1.0f) distance = 1.0f; // Prevent division by zero
      float spriteAngle = atan2(spriteY, spriteX) - playerAngle;
      // Normalize angle to [-π, π]
      if (spriteAngle < -M_PI) spriteAngle += 2 * M_PI;
      if (spriteAngle > M_PI) spriteAngle -= 2 * M_PI;
      if (fabs(spriteAngle) > FOV / 2.0) continue; // Skip if outside field of view
      float correctedDistance = distance * fast_cos(spriteAngle); // Correct for fish-eye effect
      if (correctedDistance < 1.0f) correctedDistance = 1.0f;
      // Calculate screen position
      float spriteScreenX = (SMALL_SCREEN_WIDTH / 2.0) + tan(spriteAngle) * (SMALL_SCREEN_WIDTH / (2.0 * tan(FOV / 2.0)));
      if (spriteScreenX < -SMALL_SCREEN_WIDTH / 2.0) spriteScreenX = -SMALL_SCREEN_WIDTH / 2.0;
      if (spriteScreenX > SMALL_SCREEN_WIDTH * 1.5) spriteScreenX = SMALL_SCREEN_WIDTH * 1.5;
      float baseSize = fireballs[i].size;
      float spriteSize = (SMALL_SCREEN_HEIGHT / correctedDistance) * (baseSize * FIREBALL_SCALE_FACTOR);
      float spriteScreenY = (SMALL_SCREEN_HEIGHT / 2.0) - (fireballs[i].z * (SMALL_SCREEN_HEIGHT / correctedDistance));
      // Clamp vertical position
      if (spriteScreenY < 0) spriteScreenY = 0;
      if (spriteScreenY > SMALL_SCREEN_HEIGHT - 1) spriteScreenY = SMALL_SCREEN_HEIGHT - 1;
      int drawX = (int)spriteScreenX;
      int drawY = (int)spriteScreenY;
      int drawSize = (int)spriteSize;
      // Clamp fireball size
      if (drawSize < 4) drawSize = 4;
      if (drawSize > FIREBALL_MAX_SIZE) drawSize = FIREBALL_MAX_SIZE;
      // Draw fireball if within screen and in front of zBuffer
      if (drawX >= 0 && drawX < SMALL_SCREEN_WIDTH && drawY >= 0 && drawY < SMALL_SCREEN_HEIGHT && correctedDistance < zBuffer[drawX]) {
        u16 fireballColor = applyFog(fireballs[i].color, correctedDistance); // Apply fog effect
        DrawGradientCircle(drawX, drawY, (int)(spriteSize / 16.0f), fireballColor); // Draw fireball
      }
    }
  }
}

__attribute__((always_inline)) inline void DrawScaledSprite(const u8 *sprite, const u16 *palette, int srcX, int srcY, int destX, int destY,
                                                            int destWidth, int destHeight, int srcWidth, int srcHeight, u16 transparentColor, float distance) {
  // Skip invalid dimensions
  if (destWidth > SMALL_SCREEN_WIDTH * 2 || destHeight > SMALL_SCREEN_HEIGHT * 2 || destWidth <= 0 || destHeight <= 0) {
    return;
  }

  // Calculate clipping boundaries
  int startX = destX < 0 ? -destX : 0;
  int endX = destX + destWidth > SMALL_SCREEN_WIDTH ? SMALL_SCREEN_WIDTH - destX : destWidth;
  int startY = destY < 0 ? -destY : 0;
  int endY = destY + destHeight > SMALL_SCREEN_HEIGHT ? SMALL_SCREEN_HEIGHT - destY : destHeight;

  // Adjust texture coordinates for visible portion
  float texStartX = (float)startX * srcWidth / destWidth;
  float texStartY = (float)startY * srcHeight / destHeight;
  float texWidth = (float)(endX - startX) * srcWidth / destWidth;
  float texHeight = (float)(endY - startY) * srcHeight / destHeight;

  // Draw sprite pixels
  for (int y = startY; y < endY; y++) {
    for (int x = startX; x < endX; x++) {
      int screenX = destX + x;
      int screenY = destY + y;
      // Check if pixel is within screen boundaries
      if (screenX >= 0 && screenX < SMALL_SCREEN_WIDTH && screenY >= 0 && screenY < SMALL_SCREEN_HEIGHT) {
        // Calculate texture coordinates
        float u = srcX + texStartX + (x - startX) * texWidth / (endX - startX);
        float v = srcY + texStartY + (y - startY) * texHeight / (endY - startY);
        int srcPixelX = (int)u;
        int srcPixelY = (int)v;
        // Check if texture coordinates are valid
        if (srcPixelX >= 0 && srcPixelX < srcWidth && srcPixelY >= 0 && srcPixelY < srcHeight) {
          int index = sprite[srcPixelY * srcWidth + srcPixelX];
          if (palette[index] != transparentColor) { // Skip transparent pixels
            if (distance < zBuffer[screenX]) { // Check zBuffer
              u16 foggedColor = applyFog(palette[index], distance); // Apply fog
              drawPixel(screenX, screenY, foggedColor); // Draw pixel
            }
          }
        }
      }
    }
  }
}

__attribute__((always_inline)) inline u16 ReturnCorectSelect(u8 Item, u8 Select) {
  // Return highlight color if item is selected, otherwise normal color
  if (Item == Select) {
    return color(31, 63, 0); // Highlighted (yellow)
  } else {
    return color(31, 63, 31); // Normal (white)
  }
}

__attribute__((always_inline)) inline void drawHUD() {
  // Display FPS on HUD
  char fpsStr[20];
  sprintf(fpsStr, "FPS: %.1f", fps);
  DrawText(fpsStr, 5, SCREEN_HEIGHT - 15, color(31, 63, 31)); // Draw FPS in bottom-left
}

__attribute__((always_inline)) inline bool CheckDoorsClose(uint8_t MapElement) {
  // Check if player has required key card to open door
  switch (MapElement) {
    case 12: return KeyCard.GoldCard != 0; // Gold key required
    case 15: return KeyCard.RedCard != 0; // Red key required
    case 16: return KeyCard.GreenCard != 0; // Green key required
    case 17: return KeyCard.BlueCard != 0; // Blue key required
    default: return true; // No key required
  }
}

void interactWithDoor() {
  static uint32_t lastInteractTime = 0; // Last interaction timestamp
  static bool lastButtonXState = false; // Previous state of BUTTON_X
  const uint32_t frameLimit = 16666; // Interaction cooldown (microseconds)

  uint32_t currentTime = time_us_32();
  bool currentButtonXState = BUTTON_X;

  // Skip if a door is already opening
  if (autoOpeningDoorX != -1 && autoOpeningDoorY != -1) {
    lastButtonXState = currentButtonXState;
    return;
  }

  // Detect new button press with cooldown
  if (currentButtonXState && !lastButtonXState && (currentTime - lastInteractTime) >= frameLimit) {
    float rayX = playerX, rayY = playerY;
    float rayAngle = playerAngle;
    float maxDistance = 1.5f; // Maximum interaction distance
    float distStep = STEP_SIZE;

    // Cast ray to detect door
    for (float dist = 0; dist < maxDistance; dist += distStep) {
      float cosA = fast_cos(rayAngle);
      float sinA = fast_sin(rayAngle);
      rayX += cosA * distStep;
      rayY += sinA * distStep;
      int mapX = (int)rayX;
      int mapY = (int)rayY;

      // Check if within map bounds
      if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
        if (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10) {
          if (CheckDoorsClose(getLevelValue(mapX, mapY))) { // Verify key requirements
            // Trigger door opening
            autoOpeningDoorX = mapX;
            autoOpeningDoorY = mapY;
            autoOpeningTimer = 0.0f;
            SND_DOOR(); // Play door sound
          }
          break;
        }
      } else {
        break; // Out of map bounds
      }
    }
    lastInteractTime = currentTime; // Update last interaction time
  }

  lastButtonXState = currentButtonXState; // Update button state
}

__attribute__((always_inline)) inline void fillWallWithTexture(int x, int top, int bottom, float distance, int mapX, int mapY, int side, float hitX, float hitY, const u8 *texture, const u16 *palette) {
  // Skip if invalid parameters
  if (top >= bottom || x < 0 || x >= SMALL_SCREEN_WIDTH) return;
  if (distance < 0.1f) distance = 0.1f;

  // Calculate texture X coordinate
  float texX_frac = (side == 0) ? hitY - floor(hitY) : hitX - floor(hitX);
  if (texX_frac < 0) texX_frac += 1.0f;
  int textureX = (int)(texX_frac * LARGEUR_TEXTURE) % LARGEUR_TEXTURE;

  // Handle door texture offset
  bool isDoor = (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] > 0);
  int shift = 0;
  if (isDoor) {
    shift = doorStates[mapY][mapX] * (LARGEUR_TEXTURE / DOOR_OPENING_STEPS);
    textureX = (textureX + shift) % LARGEUR_TEXTURE;
  }

  // Calculate wall height and texture scaling
  float wallHeight = (SMALL_SCREEN_HEIGHT / distance) * wallHeights[getLevelValue(mapX, mapY)];
  if (wallHeight < 1.0f) wallHeight = 1.0f;
  float texYScale = HAUTEUR_TEXTURE / wallHeight;
  float texYOffset = (top < 0) ? -top * texYScale : 0.0f;

  // Optimize pixel rendering
  int startY = top;
  int lastY = top;
  int lastIndex = -1;

  for (int y = top; y <= bottom; y++) {
    float texY = texYOffset + (y - (SMALL_SCREEN_HEIGHT - wallHeight) / 2.0f) * texYScale;
    int textureY = (int)texY;
    if (textureY < 0) textureY = 0;
    if (textureY >= HAUTEUR_TEXTURE) textureY = HAUTEUR_TEXTURE - 1;
    int index = texture[textureY * LARGEUR_TEXTURE + textureX];

    // Skip pixels in open door region
    if (isDoor && doorStates[mapY][mapX] > 0 && textureX < shift) {
      continue;
    }

    // Draw column segment when texture index changes or at end
    if (y == bottom || index != lastIndex) {
      if (lastIndex != -1 && palette[lastIndex] != color(0, 63, 0)) {
        u16 foggedColor = applyFog(palette[lastIndex], distance);
        for (int fillY = startY; fillY <= lastY; fillY++) {
          drawPixel(x, fillY, foggedColor); // Draw column segment
        }
      }
      startY = y;
      lastIndex = index;
    }
    lastY = y;
  }

  // Draw final column segment
  if (lastIndex != -1 && palette[lastIndex] != color(0, 63, 0)) {
    u16 foggedColor = applyFog(palette[lastIndex], distance);
    for (int fillY = startY; fillY <= bottom; fillY++) {
      drawPixel(x, fillY, foggedColor);
    }
  }
}

__attribute__((always_inline)) inline void drawWeapon(void) {
  // Calculate weapon position with bobbing effect
  int bobOffsetX = (int)(bobPositions[bobIndex][0]);
  int bobOffsetY = (int)(bobPositions[bobIndex][1]);
  int weaponX = 108 + bobOffsetX;
  int weaponY = 171 + bobOffsetY;
  // Draw weapon sprite
  DrawBlitPal(GUNPIC[gunFiring], GUNPIC_PAL[gunFiring], 0, 0, weaponX, weaponY, Weapon_W, Weapon_H, Weapon_W_FULL, COL_GREEN);
}

__attribute__((always_inline)) inline void drawParticles() {
  // Cache global variables for performance
  float playerXLoc = playerX;
  float playerYLoc = playerY;
  float playerAngleLoc = playerAngle;
  float fovHalf = FOV / 2.0f;
  float screenWidthHalf = SMALL_SCREEN_WIDTH / 2.0f;
  float screenHeightHalf = SMALL_SCREEN_HEIGHT / 2.0f;

  // Draw active particles
  for (int i = 0; i < MAX_PARTICLES; i++) {
    if (particles[i].active) {
      float spriteX = particles[i].x - playerXLoc;
      float spriteY = particles[i].y - playerYLoc;
      float distance = sqrtf(spriteX * spriteX + spriteY * spriteY);
      if (distance < 1.0f) distance = 1.0f; // Prevent division by zero
      float spriteAngle = atan2f(spriteY, spriteX) - playerAngleLoc;
      // Normalize angle to [-π, π]
      if (spriteAngle < -M_PI) spriteAngle += 2 * M_PI;
      if (spriteAngle > M_PI) spriteAngle -= 2 * M_PI;
      if (fabsf(spriteAngle) > fovHalf) continue; // Skip if outside field of view
      float correctedDistance = distance * fast_cos(spriteAngle); // Correct for fish-eye effect
      if (correctedDistance < 1.0f) correctedDistance = 1.0f;
      // Calculate screen position
      float tanSpriteAngle = tanf(spriteAngle);
      float spriteScreenX = screenWidthHalf + tanSpriteAngle * (SMALL_SCREEN_WIDTH / (2.0f * tanf(FOV / 2.0f)));
      float baseSize = particles[i].size;
      float spriteSize = (SMALL_SCREEN_HEIGHT / correctedDistance) * (baseSize * PARTICLE_SCALE_FACTOR);
      float spriteScreenY = screenHeightHalf - (particles[i].z * (SMALL_SCREEN_HEIGHT / correctedDistance));
      // Clamp vertical position
      if (spriteScreenY < 0) spriteScreenY = 0;
      if (spriteScreenY > SMALL_SCREEN_HEIGHT - 1) spriteScreenY = SMALL_SCREEN_HEIGHT - 1;
      int drawX = (int)spriteScreenX;
      int drawY = (int)spriteScreenY;
      int drawSize = (int)spriteSize;
      // Clamp particle size
      if (drawSize < 2) drawSize = 2;
      if (drawSize > 8) drawSize = 8;
      // Draw particle if within screen and in front of zBuffer
      if (drawX >= 0 && drawX < SMALL_SCREEN_WIDTH && drawY >= 0 && drawY < SMALL_SCREEN_HEIGHT && correctedDistance < zBuffer[drawX] * 1.5f) {
        u16 particleColor = applyFog(particles[i].color, correctedDistance); // Apply fog effect
        drawPixel(drawX, drawY, particleColor); // Draw particle
      }
    }
  }
}

__attribute__((always_inline)) inline void BypassScaleBuffer(void) {
  // Apply flash effect to frame buffer
  float flashIntensity = 0.0f;
  if (hitFlashTime > 0.0f) {
    const float kFlashFreq = HIT_FLASH_FREQUENCY * 2.0f * M_PI;
    flashIntensity = (sinf(kFlashFreq * (HIT_FLASH_DURATION - hitFlashTime)) + 1.0f) * 0.5f;
    flashIntensity *= (hitFlashTime / HIT_FLASH_DURATION);
    const float oneMinusFlash = 1.0f - flashIntensity;
    const uint8_t flashMax = (uint8_t)(31 * flashIntensity);

    // Process each pixel in FrameBuf
    for (uint32_t i = 0; i < 320 * 240; i++) {
      uint16_t pixel = FrameBuf[i];
      // Extract RGB565 components
      uint8_t r = (pixel >> 11) & 0x1F;
      uint8_t g = (pixel >> 5) & 0x3F;
      uint8_t b = pixel & 0x1F;
      if (FlahsColor == COL_RED) {
        // Apply red flash effect
        r = r + ((31 - r) * flashIntensity); // Increase red
        g = (uint8_t)(g * oneMinusFlash); // Reduce green
        b = (uint8_t)(b * oneMinusFlash); // Reduce blue
      } else {
        // Apply blue flash effect
        b = b + ((31 - b) * flashIntensity); // Increase blue
        g = (uint8_t)(g * oneMinusFlash); // Reduce green
        r = (uint8_t)(r * oneMinusFlash); // Reduce red
      }
      FrameBuf[i] = (r << 11) | (g << 5) | b; // Recompose pixel
    }
  }
  // Mark entire screen for refresh
  DispDirtyRect(0, 0, 320, 240);
}

__attribute__((always_inline)) inline void My_ScaleBuffer2DToLinear(void) {
  // Apply flash effect and scale 2D buffer to linear frame buffer
  float flashIntensity = 0.0f;
  if (hitFlashTime > 0.0f) {
    const float kFlashFreq = HIT_FLASH_FREQUENCY * 2.0f * M_PI;
    flashIntensity = (sinf(kFlashFreq * (HIT_FLASH_DURATION - hitFlashTime)) + 1.0f) * 0.5f;
    flashIntensity *= (hitFlashTime / HIT_FLASH_DURATION);
  }

  const uint32_t kRowStride = MULTI_RES * 320; // Stride for y increment
  const uint32_t kBlockStride = MULTI_RES; // Stride for x increment

  if (flashIntensity > 0.0f) {
    const float oneMinusFlash = 1.0f - flashIntensity;
    const uint8_t flashMax = (uint8_t)(31 * flashIntensity);

    // Apply flash effect to each pixel
    for (uint16_t y = 0; y < SMALL_SCREEN_HEIGHT; y++) {
      uint32_t rowOffset = y * kRowStride;
      for (uint16_t x = 0; x < SMALL_SCREEN_WIDTH; x++) {
        uint16_t pixel = My_buffer[y][x];
        // Extract RGB565 components
        uint8_t r = (pixel >> 11) & 0x1F;
        uint8_t g = (pixel >> 5) & 0x3F;
        uint8_t b = pixel & 0x1F;
        // Apply flash effect
        if (FlahsColor == COL_RED) {
          r = r + ((31 - r) * flashIntensity); // Increase red
          g = (uint8_t)(g * oneMinusFlash); // Reduce green
          b = (uint8_t)(b * oneMinusFlash); // Reduce blue
        } else {
          b = b + ((31 - b) * flashIntensity); // Increase blue
          g = (uint8_t)(g * oneMinusFlash); // Reduce green
          r = (uint8_t)(r * oneMinusFlash); // Reduce red
        }
        pixel = (r << 11) | (g << 5) | b; // Recompose pixel
        // Fill MULTI_RES x MULTI_RES block
        uint32_t baseIndex = rowOffset + x * kBlockStride;
        for (uint16_t dy = 0; dy < MULTI_RES; dy++) {
          uint16_t *bufPtr = &FrameBuf[baseIndex + dy * 320];
#if MULTI_RES == 2
          bufPtr[0] = pixel;
          bufPtr[1] = pixel;
#else
          for (uint16_t dx = 0; dx < MULTI_RES; dx++) {
            bufPtr[dx] = pixel;
          }
#endif
        }
      }
    }
  } else {
    // No flash effect, just scale buffer
    for (uint16_t y = 0; y < SMALL_SCREEN_HEIGHT; y++) {
      uint32_t rowOffset = y * kRowStride;
      for (uint16_t x = 0; x < SMALL_SCREEN_WIDTH; x++) {
        uint16_t pixel = My_buffer[y][x];
        uint32_t baseIndex = rowOffset + x * kBlockStride;
        for (uint16_t dy = 0; dy < MULTI_RES; dy++) {
          uint16_t *bufPtr = &FrameBuf[baseIndex + dy * 320];
#if MULTI_RES == 2
          bufPtr[0] = pixel;
          bufPtr[1] = pixel;
#else
          for (uint16_t dx = 0; dx < MULTI_RES; dx++) {
            bufPtr[dx] = pixel;
          }
#endif
        }
      }
    }
  }
  // Mark entire screen for refresh
  DispDirtyRect(0, 0, 320, 240);
}

__attribute__((always_inline)) inline void drawCeilingAndFloor(int width, int height, uint16_t colorTop, uint16_t colorBottom) {
  int centerY = height / 2;
  // Extract RGB565 components for ceiling and floor
  uint8_t rTop = (colorTop >> 11) & 0x1F;
  uint8_t gTop = (colorTop >> 5) & 0x3F;
  uint8_t bTop = colorTop & 0x1F;
  uint8_t rBottom = (colorBottom >> 11) & 0x1F;
  uint8_t gBottom = (colorBottom >> 5) & 0x3F;
  uint8_t bBottom = colorBottom & 0x1F;

  // Draw ceiling and floor line by line
  for (int y = 0; y < centerY; y++) {
    // Interpolate ceiling color
    uint32_t ratioCeiling = ((centerY - y) << 8) / centerY; // Fixed-point precision
    uint8_t rCeiling = (rTop * ratioCeiling) >> 8;
    uint8_t gCeiling = (gTop * ratioCeiling) >> 8;
    uint8_t bCeiling = (bTop * ratioCeiling) >> 8;
    // Interpolate floor color
    uint32_t ratioFloor = ((y) << 8) / centerY;
    uint8_t rFloor = (rBottom * ratioFloor) >> 8;
    uint8_t gFloor = (gBottom * ratioFloor) >> 8;
    uint8_t bFloor = (bBottom * ratioFloor) >> 8;
    // Draw full line for ceiling and floor
    for (int x = 0; x < width; x++) {
      drawPixel(x, y, color(rCeiling, gCeiling, bCeiling)); // Ceiling pixel
      drawPixel(x, y + centerY, color(rFloor, gFloor, bFloor)); // Floor pixel
    }
  }
}

__attribute__((always_inline)) inline void DrawICO(int x_, int y_, s8 ico_) {
  // Draw icon sprite at specified position
  DrawBlitPal(ico, ico_Pal, ico_ * ico_W, 0, x_, y_, ico_W, ico_H, ico_W_FULL, COL_GREEN);
}

__attribute__((always_inline)) inline void drawOSD(void) {
  // Draw on-screen display (HUD elements)
  char TxT_[20];
  DrawICO(1, 1, 4); // Draw ammo icon
  sprintf(TxT_, "x%d", playerAmmo);
  DrawText(TxT_, 20, 4, color(31, 63, 0)); // Draw ammo count
  DrawICO(63, 1, 3); // Draw health icon
  sprintf(TxT_, "x%d", playerHealth);
  DrawText(TxT_, 87, 4, color(31, 63, 0)); // Draw health count
  // Draw key card icons if collected
  if (KeyCard.RedCard) DrawICO(278, 1, 2);
  if (KeyCard.GreenCard) DrawICO(299, 1, 1);
  if (KeyCard.BlueCard) DrawICO(278, 22, 0);
  if (KeyCard.GoldCard) DrawICO(299, 22, 5);
}

__attribute__((always_inline)) inline void RefreshBuf(void) {
  // Refresh display buffer based on resolution preset
  switch (ResIndex) {
    case 3: BypassScaleBuffer(); break; // High-resolution mode
    default: My_ScaleBuffer2DToLinear(); break; // Scaled resolution mode
  }
}

void SetNewResolution(uint8_t Preset_) {
  // Set new screen resolution
  ResIndex = Preset_;
  SMALL_SCREEN_WIDTH = ResWidth[Preset_];
  SMALL_SCREEN_HEIGHT = ResHeight[Preset_];
  MULTI_RES = (SCREEN_WIDTH / SMALL_SCREEN_WIDTH); // Calculate scaling factor
}

uint8_t ConfigGetResolution(void) {
  // Return current resolution index
  return ResIndex;
}

void InitNewLevel(void) {
  // Reset player variables
  playerX = 1.5f;
  playerY = 1.5f;
  playerAngle = 0.0f;
  playerHealth = START_HEALTH;
  playerAmmo = START_AMMO;
  targetAngle = 0.0f;
  velocityX = 0.0f;
  velocityY = 0.0f;
  angularVelocity = 0.0f;
  forwardDistance = 0.0f;
  bobIndex = 0;

  // Reset game state
  gameState = 0;
  hitFlashTime = 0.0f;
  gunFiring = 0;
  gunFireCounter = 0;
  GunReady = 0;

  // Reset doors
  autoOpeningDoorX = -1;
  autoOpeningDoorY = -1;
  autoOpeningTimer = 0.0f;
  memset(doorStates, 0, sizeof(doorStates));

  // Reset sprites
  NUM_SPRITES = 0;
  init_sprites_from_map(); // Reinitialize sprites from map

  // Reset particles
  for (int i = 0; i < MAX_PARTICLES; i++) {
    particles[i].active = 0;
    particles[i].type = 0;
    particles[i].x = 0.0f;
    particles[i].y = 0.0f;
    particles[i].prevX = 0.0f;
    particles[i].prevY = 0.0f;
    particles[i].z = 0.0f;
    particles[i].vx = 0.0f;
    particles[i].vy = 0.0f;
    particles[i].vz = 0.0f;
    particles[i].lifetime = 0.0f;
    particles[i].size = 0.0f;
    particles[i].color = 0;
    particles[i].hasHitGround = 0;
  }

  // Reset fireballs
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    fireballs[i].active = 0;
    fireballs[i].x = 0.0f;
    fireballs[i].y = 0.0f;
    fireballs[i].prevX = 0.0f;
    fireballs[i].prevY = 0.0f;
    fireballs[i].z = 0.0f;
    fireballs[i].vx = 0.0f;
    fireballs[i].vy = 0.0f;
    fireballs[i].vz = 0.0f;
    fireballs[i].lifetime = 0.0f;
    fireballs[i].size = 0.0f;
    fireballs[i].color = 0;
  }

  // Reset key cards
  InitKeyCard();

  // Reset FPS and timing
  lastTime = 0;
  frameCount = 0;
  fps = 0.0f;

  // Reset triggers
  Trig1 = false;
  Trig2 = false;
  Trig3 = false;

  // Reset buffers
  memset(My_buffer, 0, sizeof(My_buffer));
  for (int i = 0; i < BUFFER_SCREEN_WIDTH; i++) {
    zBuffer[i] = 100.0f; // Initialize zBuffer with far distance
  }
}

void Init_New_game(void) {
  // Reset game-wide variables
  Level_Use = 0;
  Total_Kill = 0;
  Total_Skull = 0;
  playerX = 1.5f;
  playerY = 1.5f;
  playerAngle = 0.0f;
  playerHealth = START_HEALTH;
  playerAmmo = START_AMMO;
  score = 0;
  targetAngle = 0.0f;
  velocityX = 0.0f;
  velocityY = 0.0f;
  angularVelocity = 0.0f;
  forwardDistance = 0.0f;
  bobIndex = 0;

  // Reset game state
  gameState = 0;
  hitFlashTime = 0.0f;
  gunFiring = 0;
  gunFireCounter = 0;
  GunReady = 0;

  // Reset doors
  autoOpeningDoorX = -1;
  autoOpeningDoorY = -1;
  autoOpeningTimer = 0.0f;
  memset(doorStates, 0, sizeof(doorStates));

  // Reset sprites
  NUM_SPRITES = 0;
  init_sprites_from_map(); // Reinitialize sprites from map

  // Reset particles
  for (int i = 0; i < MAX_PARTICLES; i++) {
    particles[i].active = 0;
    particles[i].type = 0;
    particles[i].x = 0.0f;
    particles[i].y = 0.0f;
    particles[i].prevX = 0.0f;
    particles[i].prevY = 0.0f;
    particles[i].z = 0.0f;
    particles[i].vx = 0.0f;
    particles[i].vy = 0.0f;
    particles[i].vz = 0.0f;
    particles[i].lifetime = 0.0f;
    particles[i].size = 0.0f;
    particles[i].color = 0;
    particles[i].hasHitGround = 0;
  }

  // Reset fireballs
  for (int i = 0; i < MAX_FIREBALLS; i++) {
    fireballs[i].active = 0;
    fireballs[i].x = 0.0f;
    fireballs[i].y = 0.0f;
    fireballs[i].prevX = 0.0f;
    fireballs[i].prevY = 0.0f;
    fireballs[i].z = 0.0f;
    fireballs[i].vx = 0.0f;
    fireballs[i].vy = 0.0f;
    fireballs[i].vz = 0.0f;
    fireballs[i].lifetime = 0.0f;
    fireballs[i].size = 0.0f;
    fireballs[i].color = 0;
  }

  // Reset key cards
  InitKeyCard();

  // Reset FPS and timing
  lastTime = 0;
  frameCount = 0;
  fps = 0.0f;

  // Reset triggers
  Trig1 = false;
  Trig2 = false;
  Trig3 = false;

  // Reset buffers
  memset(My_buffer, 0, sizeof(My_buffer));
  for (int i = 0; i < BUFFER_SCREEN_WIDTH; i++) {
    zBuffer[i] = 100.0f; // Initialize zBuffer with far distance
  }
}

void display_TTEXT_(const char *TTEXT_, int x, int y, uint16_t color) {
#define TTEXT__X 118
#define TTEXT__Y 190
#define TTEXT__SHADOW 2
  // Display text with shadow
  char bufferText[50];
  snprintf(bufferText, sizeof(bufferText), "%s", TTEXT_);
  DrawTextH(bufferText, x + TTEXT__SHADOW, y + TTEXT__SHADOW, COL_BLACK); // Draw shadow
  DrawTextH(bufferText, x, y, color); // Draw main text
}

char indexToHex(int index) {
  // Convert index (0-15) to hexadecimal character (0-9, A-F)
  if (index < 10) return '0' + index;
  return 'A' + (index - 10);
}

#define SECRET_KEY 0xA7 // Secret key for checksum calculation

void CreateVcode(uint8_t Level_, uint8_t Total_Skull_, uint16_t Total_Kill_, uint16_t Score_, char *Code_) {
  // Create a 14-character verification code from game data
  uint8_t data[7];
  // Encode game variables
  data[0] = Level_;
  data[1] = Total_Skull_;
  data[2] = (Total_Kill_ >> 8) & 0xFF;
  data[3] = Total_Kill_ & 0xFF;
  data[4] = (Score_ >> 8) & 0xFF;
  data[5] = Score_ & 0xFF;
  // Calculate checksum
  uint16_t checksum = SECRET_KEY;
  for (int i = 0; i < 6; i++) {
    checksum += (data[i] * (i + 1)) ^ (checksum >> 3);
  }
  data[6] = checksum & 0xFF; // Store lower 8 bits
  // Convert to hex code
  for (int i = 0; i < 7; i++) {
    Code_[i * 2] = indexToHex((data[i] >> 4) & 0x0F); // High nibble
    Code_[i * 2 + 1] = indexToHex(data[i] & 0x0F); // Low nibble
  }
  Code_[14] = '\0'; // Null-terminate
}

bool VerifyVcode(const char *Code_) {
  // Verify a 14-character code
  if (strlen(Code_) != 14) return false;
  // Validate hex characters
  for (int i = 0; i < 14; i++) {
    if (!((Code_[i] >= '0' && Code_[i] <= '9') || (Code_[i] >= 'A' && Code_[i] <= 'F'))) {
      return false;
    }
  }
  // Decode code
  uint8_t data[7];
  for (int i = 0; i < 7; i++) {
    char high = Code_[i * 2];
    char low = Code_[i * 2 + 1];
    uint8_t high_val = (high <= '9') ? (high - '0') : (high - 'A' + 10);
    uint8_t low_val = (low <= '9') ? (low - '0') : (low - 'A' + 10);
    data[i] = (high_val << 4) | low_val;
  }
  // Verify checksum
  uint16_t expected_checksum = SECRET_KEY;
  for (int i = 0; i < 6; i++) {
    expected_checksum += (data[i] * (i + 1)) ^ (expected_checksum >> 3);
  }
  return (data[6] == (expected_checksum & 0xFF));
}

void RecupeDataFromVcode(const char *Code_, uint8_t *Level_, uint8_t *Total_Skull_, uint16_t *Total_Kill_, uint16_t *Score_) {
  // Recover game data from a 14-character code
  uint8_t data[7];
  for (int i = 0; i < 7; i++) {
    char high = Code_[i * 2];
    char low = Code_[i * 2 + 1];
    uint8_t high_val = (high <= '9') ? (high - '0') : (high - 'A' + 10);
    uint8_t low_val = (low <= '9') ? (low - '0') : (low - 'A' + 10);
    data[i] = (high_val << 4) | low_val;
  }
  // Extract data
  *Level_ = data[0] + 1; // Increment level for display
  *Total_Skull_ = data[1];
  *Total_Kill_ = (data[2] << 8) | data[3];
  *Score_ = (data[4] << 8) | data[5];
}

bool inputCode(char *inputCode) {
#define SLEEPTIME 125
  // Handle user input for a 14-character code
  strncpy(inputCode, code, 15);
  int cursorPos = 0; // Current cursor position
  int currentValue = 0; // Current character value (0-15)
  bool codeEntered = false;

  while (!codeEntered) {
    // Increment character value (0-9, A-F)
    if (TINYJOYPAD_UP) {
      SND_BUTTON();
      currentValue = (currentValue + 1) % 16;
      inputCode[cursorPos] = indexToHex(currentValue);
      sleep_ms(SLEEPTIME); // Debounce
    }
    // Decrement character value
    if (TINYJOYPAD_DOWN) {
      SND_BUTTON();
      currentValue = (currentValue - 1 + 16) % 16;
      inputCode[cursorPos] = indexToHex(currentValue);
      sleep_ms(SLEEPTIME); // Debounce
    }
    // Move to next character
    if (TINYJOYPAD_RIGHT) {
      SND_BUTTON();
      cursorPos = (cursorPos + 1) % 14;
      currentValue = (inputCode[cursorPos] <= '9') ? (inputCode[cursorPos] - '0') : (inputCode[cursorPos] - 'A' + 10);
      sleep_ms(SLEEPTIME); // Debounce
    }
    // Move to previous character
    if (TINYJOYPAD_LEFT) {
      SND_BUTTON();
      cursorPos = (cursorPos - 1 + 14) % 14;
      currentValue = (inputCode[cursorPos] <= '9') ? (inputCode[cursorPos] - '0') : (inputCode[cursorPos] - 'A' + 10);
      sleep_ms(SLEEPTIME); // Debounce
    }
    // Validate code
    if (BUTTON_DOWN) {
      SND_BUTTON();
      codeEntered = true;
      sleep_ms(SLEEPTIME); // Debounce
    }

    // Display code input interface
    DrawBlitPal(ScorePic, ScorePic_Pal, 0, 0, 0, 0, menu_W, menu_H, menu_W_FULL, COL_RED);
    display_TTEXT_("Enter Vcode:", TTEXT__X, TTEXT__Y, COL_YELLOW);
    for (int i = 0; i < 14; i++) {
      char charStr[2] = {inputCode[i], '\0'};
      uint16_t color = (i == cursorPos) ? COL_WHITE : COL_YELLOW; // Highlight active character
      display_TTEXT_(charStr, (TTEXT__X - 22) + i * 10, TTEXT__Y + 20, color);
    }
    DispUpdate();
    sleep_ms(10); // Light refresh
  }

  return codeEntered;
}

bool EnterVcode_ResumeGame(void) {
  // Handle resuming game with verification code
  FadeOutToBlack();
  while (BUTTON_DOWN); // Wait for button release
  FadeInFromBlack(ScorePic, ScorePic_Pal);
  if (!inputCode(code)) {
    FadeOutToBlack();
    FadeInFromBlack(menu, menu_Pal);
    return false; // Code input cancelled
  }
  if (!VerifyVcode(code)) {
    FadeOutToBlack();
    FadeInFromBlack(menu, menu_Pal);
    return false; // Invalid code
  }
  FadeOutToBlack();
  initNewGame(); // Initialize game state
  RecupeDataFromVcode(code, &Level_Use, &Total_Skull, &Total_Kill, &score); // Restore game data
  InitNewLevel(); // Initialize level
  enteringNewLevel();
  return true;
}


void MenuIntro(uint8_t GameStat_) {
  // Constants for menu positioning and rendering
  #define MENU_X_MENU 118         // X position for menu text
  #define MENU_Y_MENU 145         // Y position at bottom of screen, adjustable
  #define MENU_SHADOW_MENU 2      // Shadow offset for text
  #define SCREEN_WIDTH_MENU 320   // Screen width
  #define SCREEN_HEIGHT_MENU 240  // Screen height
  #define SCANLINE_SPEED_MENU 3.0f // Speed of scanline effect
  #define SCANLINE_HEIGHT_MENU 2  // Height of scanline
  #define TRAIL_COUNT_MENU 25     // Number of trailing scanlines
  #define TRAIL_OFFSET_MENU 2     // Distance between trailing scanlines
  #define CONTRAST_FACTOR_MENU 1.5f // Contrast adjustment factor
  #define TOTAL_LINES_MENU (1 + TRAIL_COUNT_MENU) // Main scanline + trailing lines
  #define TARGET_FPS_MENU 30.0f   // Target frame rate (30 FPS)
  #define FRAME_TIME_MENU (1.0f / TARGET_FPS_MENU) // Time per frame (33.33 ms)

  // Enum for menu states
  typedef enum { 
    MAIN_MENU, 
    SETUP_MENU, 
    SOUND_MENU, 
    BACKLIGHT_ADJUST, 
    VOLUME_ADJUST 
  } MenuState;

  // Variables for menu state and navigation
  MenuState currentMenu = MAIN_MENU; // Current active menu
  u8 SelectSwitch = (GameStat_ != 2) ? 1 : 0; // Menu selection index, adjusted based on game state
  u8 maxSelect = 3; // Maximum number of menu options (includes "Resume Game")
  float scanlineYs[TOTAL_LINES_MENU]; // Y positions of scanlines
  u32 menuLastTime = Time(); // Time of the last frame
  float menuAccumulator = 0.0f; // Accumulated time for frame updates
  bool prevDown = false; // Previous state of down button
  bool prevUp = false; // Previous state of up button
  bool prevButtonB = false; // Previous state of B button
  bool prevLeft = false; // Previous state of left button
  bool prevRight = false; // Previous state of right button
  bool bgmOn = true; // Background music state (default: on)
  uint8_t backlightLevel; // Current backlight level (0 to CONFIG_BACKLIGHT_MAX)
  uint8_t volumeLevel; // Current volume level (0 to CONFIG_VOLUME_MAX)
  uint8_t backlightLevel_old; // Previous backlight level for saving changes
  uint8_t volumeLevel_old; // Previous volume level for saving changes

  // Load initial configuration values
  backlightLevel_old = backlightLevel = ConfigGetBacklight();
  volumeLevel_old = volumeLevel = ConfigGetVolume();
  uint8_t currentRes = ConfigGetResolution(); // Current screen resolution
  // Initialize scanline positions
  for (int i = 0; i < TOTAL_LINES_MENU; i++) {
    scanlineYs[i] = -i * TRAIL_OFFSET_MENU;
  }

  DispUpdate(); // Refresh display

  while (1) {
    // Measure elapsed time since last frame
    u32 menuCurrentTime = Time();
    float dt = (float)(menuCurrentTime - menuLastTime) / 1000000.0f;
    menuLastTime = menuCurrentTime;

    // Accumulate time, cap at 0.2 seconds to prevent large jumps
    menuAccumulator += dt;
    if (menuAccumulator > 0.2f) menuAccumulator = 0.2f;

    bool shouldRender = false;

    // Update logic when enough time has accumulated
    while (menuAccumulator >= FRAME_TIME_MENU) {
      // Update scanline positions
      for (int i = 0; i < TOTAL_LINES_MENU; i++) {
        scanlineYs[i] += SCANLINE_SPEED_MENU;
        if (scanlineYs[i] >= SCREEN_HEIGHT_MENU) {
          scanlineYs[i] -= SCREEN_HEIGHT_MENU; // Wrap around to top
        }
      }

      // Handle user input
      bool currentDown = TINYJOYPAD_DOWN;
      bool currentUp = TINYJOYPAD_UP;
      bool currentButtonB = BUTTON_DOWN;
      bool currentLeft = TINYJOYPAD_LEFT;
      bool currentRight = TINYJOYPAD_RIGHT;

      // Navigate down: select next menu item
      if (currentDown && !prevDown) {
        SND_BUTTON(); // Play button sound
        SelectSwitch = (SelectSwitch < maxSelect) ? SelectSwitch + 1 : SelectSwitch;
      }

      // Navigate up: select previous menu item
      if (currentUp && !prevUp) {
        SND_BUTTON();
        SelectSwitch = (SelectSwitch > 0) ? SelectSwitch - 1 : SelectSwitch;
      }

      // Adjust backlight, volume, or resolution with left/right inputs
      if (currentMenu == BACKLIGHT_ADJUST) {
        if (currentLeft && !prevLeft) {
          if (backlightLevel > 1) {
            ConfigDecBacklight(); // Decrease backlight
            backlightLevel = ConfigGetBacklight(); // Update value
          }
          SND_BUTTON();
        }
        if (currentRight && !prevRight) {
          ConfigIncBacklight(); // Increase backlight
          backlightLevel = ConfigGetBacklight();
          SND_BUTTON();
        }
      } else if (currentMenu == VOLUME_ADJUST) {
        if (currentLeft && !prevLeft) {
          ConfigDecVolume(); // Decrease volume
          volumeLevel = ConfigGetVolume();
          SND_BUTTON();
          ConfigSetVolume(bgmOn ? volumeLevel : 0); // Apply volume (muted if BGM off)
        }
        if (currentRight && !prevRight) {
          ConfigIncVolume(); // Increase volume
          volumeLevel = ConfigGetVolume();
          SND_BUTTON();
          ConfigSetVolume(bgmOn ? volumeLevel : 0);
        }
      } else if (currentMenu == SETUP_MENU && SelectSwitch == 0) {
        if (currentLeft && !prevLeft) {
          // Decrease resolution
          currentRes = ConfigGetResolution();
          if (currentRes > 0) {
            SetNewResolution(currentRes - 1);
            SND_BUTTON();
          }
        }
        if (currentRight && !prevRight) {
          // Increase resolution
          currentRes = ConfigGetResolution();
          if (currentRes < MaxRes) {
            SetNewResolution(currentRes + 1);
            SND_BUTTON();
          }
        }
      }

      // Confirm selection with B button
      if (currentButtonB && !prevButtonB) {
        if (currentMenu == MAIN_MENU) {
          switch (SelectSwitch) {
            case 0: // Resume Game
              if (GameStat_ == 2) { goto EXIT_; } 
              else if (GameStat_ == 1) { 
                if (EnterVcode_ResumeGame()) { goto EXIT_; }
              }
              break;
            case 1: // Start Game
              Init_New_game();
              FadeOutToBlack();
              sleep_ms(500);
              enteringNewLevel();
              goto EXIT_;
            case 2: // Setup
              currentMenu = SETUP_MENU;
              SelectSwitch = 0;
              maxSelect = 3; // Resolution, Backlight, Sound, Return
              break;
            case 3: // Exit
              if ((backlightLevel_old != backlightLevel) || (volumeLevel_old != volumeLevel)) ConfigSave();
              ResetToBootLoader();
              break;
            default: break;
          }
        } else if (currentMenu == SETUP_MENU) {
          switch (SelectSwitch) {
            case 1: // Backlight
              backlightLevel = ConfigGetBacklight();
              currentMenu = BACKLIGHT_ADJUST;
              SelectSwitch = 0;
              maxSelect = 0; // No multiple selections
              break;
            case 2: // Sound
              volumeLevel = ConfigGetVolume();
              currentMenu = SOUND_MENU;
              SelectSwitch = 0;
              maxSelect = 2; // BGM, Main Volume, Return
              break;
            case 3: // Return
              currentMenu = MAIN_MENU;
              SelectSwitch = 0;
              maxSelect = 3; // Resume Game, Start Game, Setup, Exit
              break;
            default: break;
          }
        } else if (currentMenu == SOUND_MENU) {
          switch (SelectSwitch) {
            case 0: // Toggle BGM
              bgmOn = !bgmOn;
              ConfigSetVolume(bgmOn ? volumeLevel : 0);
              SND_BUTTON();
              break;
            case 1: // Main Volume
              volumeLevel = ConfigGetVolume();
              currentMenu = VOLUME_ADJUST;
              SelectSwitch = 0;
              maxSelect = 0; // No multiple selections
              break;
            case 2: // Return
              currentMenu = SETUP_MENU;
              SelectSwitch = 0;
              maxSelect = 3; // Resolution, Backlight, Sound, Return
              break;
            default: break;
          }
        } else if (currentMenu == BACKLIGHT_ADJUST || currentMenu == VOLUME_ADJUST) {
          // Return to Setup menu
          currentMenu = SETUP_MENU;
          SelectSwitch = 0;
          maxSelect = 3; // Resolution, Backlight, Sound, Return
        }
      }

      // Update previous input states
      prevDown = currentDown;
      prevUp = currentUp;
      prevButtonB = currentButtonB;
      prevLeft = currentLeft;
      prevRight = currentRight;

      menuAccumulator -= FRAME_TIME_MENU;
      shouldRender = true;
    }

    // Render the menu if needed
    if (shouldRender) {
      // Draw background image
      DrawBlitPal(menu, menu_Pal, 0, 0, 0, 0, menu_W, menu_H, menu_W_FULL, COL_RED);

      // Render CRT scanline effect
      for (int line = 0; line < TOTAL_LINES_MENU; line++) {
        int yPos = (int)scanlineYs[line];
        if (yPos < 0 || yPos >= SCREEN_HEIGHT_MENU) continue;
        int shadowLevel = (line == 0) ? 15 : (int)(15.0f * ((float)line / TRAIL_COUNT_MENU));
        DrawRectShadow(0, yPos, SCREEN_WIDTH_MENU, SCANLINE_HEIGHT_MENU, shadowLevel);
      }

      // Draw menu text based on current menu state
      if (currentMenu == MAIN_MENU) {
        // Draw "Resume Game" and other items with shadow
        DrawTextH("Resume Game", -2 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
        DrawTextH(" New Game", 2 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
        DrawTextH("  Setup", 5 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);
        DrawTextH("  Exit", 8 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 66 + MENU_SHADOW_MENU, 0);

        DrawTextH("Resume Game", -2 + MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
        DrawTextH(" New Game", 2 + MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
        DrawTextH("  Setup", 5 + MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
        DrawTextH("  Exit", 8 + MENU_X_MENU, MENU_Y_MENU + 66, ReturnCorectSelect(3, SelectSwitch));
      } else if (currentMenu == SETUP_MENU) {
        char resolutionText[32];
        uint8_t currentRes = ConfigGetResolution();
        switch (currentRes) {
          case 0: sprintf(resolutionText, "Resolution: 40x30"); break;
          case 1: sprintf(resolutionText, "Resolution: 80x60"); break;
          case 2: sprintf(resolutionText, "Resolution: 160x120"); break;
          case 3: sprintf(resolutionText, "Resolution: 320x240"); break;
          default: sprintf(resolutionText, "Resolution: Unknown"); break;
        }
        DrawTextH(resolutionText, MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
        DrawTextH("Backlight", 6 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
        DrawTextH(" Sound", 12 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);
        DrawTextH(" Return", 9 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 66 + MENU_SHADOW_MENU, 0);

        DrawTextH(resolutionText, MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
        DrawTextH("Backlight", 6 + MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
        DrawTextH(" Sound", 12 + MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
        DrawTextH(" Return", 9 + MENU_X_MENU, MENU_Y_MENU + 66, ReturnCorectSelect(3, SelectSwitch));
      } else if (currentMenu == SOUND_MENU) {
        DrawTextH(bgmOn ? "Sound: On" : "Sound: Off", 4 + MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
        DrawTextH("Main Volume", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);
        DrawTextH("  Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 44 + MENU_SHADOW_MENU, 0);

        DrawTextH(bgmOn ? "Sound: On" : "Sound: Off", 4 + MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
        DrawTextH("Main Volume", MENU_X_MENU, MENU_Y_MENU + 22, ReturnCorectSelect(1, SelectSwitch));
        DrawTextH("  Return", MENU_X_MENU, MENU_Y_MENU + 44, ReturnCorectSelect(2, SelectSwitch));
      } else if (currentMenu == BACKLIGHT_ADJUST) {
        char backlightText[32];
        sprintf(backlightText, "Backlight: %d", backlightLevel);
        DrawTextH(backlightText, MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
        DrawTextH("Press B to Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);

        DrawTextH(backlightText, MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
        DrawTextH("Press B to Return", MENU_X_MENU, MENU_Y_MENU + 22, color(0, 0, 31));
      } else if (currentMenu == VOLUME_ADJUST) {
        char volumeText[32];
        sprintf(volumeText, "Main Volume: %d", volumeLevel);
        DrawTextH(volumeText, MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + MENU_SHADOW_MENU, 0);
        DrawTextH("Press B to Return", MENU_X_MENU + MENU_SHADOW_MENU, MENU_Y_MENU + 22 + MENU_SHADOW_MENU, 0);

        DrawTextH(volumeText, MENU_X_MENU, MENU_Y_MENU, ReturnCorectSelect(0, SelectSwitch));
        DrawTextH("Press B to Return", MENU_X_MENU, MENU_Y_MENU + 22, color(0, 0, 31));
      }

      // Refresh the display
      DispUpdate();
    }
  }
EXIT_:
  // Save configuration if backlight or volume has changed
  if ((backlightLevel_old != backlightLevel) || (volumeLevel_old != volumeLevel)) ConfigSave();
}

void render() {
  // Initialize zBuffer with infinite distance
  for (int i = 0; i < SMALL_SCREEN_WIDTH; i++) {
    zBuffer[i] = 100.0f;
  }

  // Draw ceiling and floor
  drawCeilingAndFloor(SMALL_SCREEN_WIDTH, SMALL_SCREEN_HEIGHT, color(0, 15, 20), color(5, 30, 5));

  // Precompute angles for each screen column
  float rayAngleStep = FOV / SMALL_SCREEN_WIDTH;
  float sinTable[SMALL_SCREEN_WIDTH];
  float cosTable[SMALL_SCREEN_WIDTH];

  for (int x = 0; x < SMALL_SCREEN_WIDTH; x++) {
    float rayAngle = playerAngle + (x - SMALL_SCREEN_WIDTH / 2.0f) * rayAngleStep;
    sinTable[x] = fast_sin(rayAngle);
    cosTable[x] = fast_cos(rayAngle);
  }

  // Main loop for raycasting each column
  for (int x = 0; x < SMALL_SCREEN_WIDTH; x += RAY_STEP) {
    float rayX = playerX;
    float rayY = playerY;
    float rayCos = cosTable[x];
    float raySin = sinTable[x];
    float rayAngle = playerAngle + (x - SMALL_SCREEN_WIDTH / 2.0f) * rayAngleStep;

    // Calculate delta distances for DDA algorithm
    float deltaDistX = fabs(1.0f / rayCos);
    float deltaDistY = fabs(1.0f / raySin);

    int mapX = (int)rayX;
    int mapY = (int)rayY;

    // Determine step direction and initial side distances
    int stepX, stepY;
    float sideDistX, sideDistY;

    if (rayCos < 0) {
      stepX = -1;
      sideDistX = (rayX - mapX) * deltaDistX;
    } else {
      stepX = 1;
      sideDistX = (mapX + 1.0f - rayX) * deltaDistX;
    }

    if (raySin < 0) {
      stepY = -1;
      sideDistY = (rayY - mapY) * deltaDistY;
    } else {
      stepY = 1;
      sideDistY = (mapY + 1.0 - rayY) * deltaDistY;
    }

    bool hit = false;
    float distance = 0.0f;
    int side = 0;
    float hitX, hitY;

    // Perform DDA raycasting
    while (!hit) {
      if (sideDistX < sideDistY) {
        sideDistX += deltaDistX;
        mapX += stepX;
        side = 0;
        distance = (mapX - rayX + (1 - stepX) / 2.0f) / rayCos;
      } else {
        sideDistY += deltaDistY;
        mapY += stepY;
        side = 1;
        distance = (mapY - rayY + (1 - stepY) / 2.0f) / raySin;
      }

      hitX = rayX + distance * rayCos;
      hitY = rayY + distance * raySin;

      // Check map boundaries
      if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
        int cellType = getLevelValue(mapX, mapY);
        int doorState = doorStates[mapY][mapX];

        // Handle walls and closed doors
        if (TYPE_SPK[cellType] == WALL || (TYPE_SPK[cellType] == DOOR && doorState == 0)) {
          distance *= fast_cos(rayAngle - playerAngle); // Correct fisheye effect
          if (distance < 0.1f) distance = 0.1f;

          float wallHeight = (SMALL_SCREEN_HEIGHT / distance) * wallHeights[cellType];
          if (wallHeight > SMALL_SCREEN_HEIGHT * 2) wallHeight = SMALL_SCREEN_HEIGHT * 2;

          int top = (SMALL_SCREEN_HEIGHT - (int)wallHeight) / 2;
          int bottom = top + (int)wallHeight;

          if (top < 0) top = 0;
          if (bottom > SMALL_SCREEN_HEIGHT - 1) bottom = SMALL_SCREEN_HEIGHT - 1;

          for (int dx = 0; dx < RAY_STEP; dx++) {
            if (x + dx < SMALL_SCREEN_WIDTH)
              zBuffer[x + dx] = distance;
          }

          if (cellType > 0 && cellType < sizeof(PIC) / sizeof(PIC[0])) {
            fillWallWithTexture(x, top, bottom, distance, mapX, mapY, side, hitX, hitY, PIC[cellType], PIC_PAL[cellType]);
          }
          hit = true;
        } else if (TYPE_SPK[cellType] == DOOR && doorState > 0) {
          if (doorState < DOOR_OPENING_STEPS) {
            float texX = (side == 0) ? hitY - floor(hitY) : hitX - floor(hitX);
            if (texX < 0) texX += 1.0f;
            int textureX = (int)(texX * PIC_W_FULL[cellType]) % PIC_W_FULL[cellType];
            int shift = doorState * (PIC_W_FULL[cellType] / DOOR_OPENING_STEPS);
            textureX = (textureX + shift) % PIC_W_FULL[cellType];

            if (textureX >= shift) {
              distance *= fast_cos(rayAngle - playerAngle);
              if (distance < 0.1f) distance = 0.1f;

              float wallHeight = (SMALL_SCREEN_HEIGHT / distance) * wallHeights[cellType];
              if (wallHeight > SMALL_SCREEN_HEIGHT * 2) wallHeight = SMALL_SCREEN_HEIGHT * 2;

              int top = (SMALL_SCREEN_HEIGHT - (int)wallHeight) / 2;
              int bottom = top + (int)wallHeight;
              if (top < 0) top = 0;
              if (bottom > SMALL_SCREEN_HEIGHT - 1) bottom = SMALL_SCREEN_HEIGHT - 1;

              for (int dx = 0; dx < RAY_STEP; dx++) {
                if (x + dx < SMALL_SCREEN_WIDTH)
                  zBuffer[x + dx] = distance;
              }

              if (cellType > 0 && cellType < sizeof(PIC) / sizeof(PIC[0])) {
                fillWallWithTexture(x, top, bottom, distance, mapX, mapY, side, hitX, hitY, PIC[cellType], PIC_PAL[cellType]);
              }
              hit = true;
            }
          }
        }
      } else {
        hit = true; // Stop at map boundaries
      }
    }
  }

  // Render sprites sorted by distance
  typedef struct {
    int index;
    float distance;
  } SpriteDistance;

  // Array for active sprites
  SpriteDistance spriteDistances[MAX_SPRITES];
  int numActiveSprites = 0;

  // Calculate distances for active sprites
  for (int i = 0; i < NUM_SPRITES; i++) {
    if (sprites[i].active) {
      float spriteX = sprites[i].x - playerX;
      float spriteY = sprites[i].y - playerY;
      float dist = sqrtf(spriteX * spriteX + spriteY * spriteY);
      if (dist < 0.1f) dist = 0.1f;
      spriteDistances[numActiveSprites].index = i;
      spriteDistances[numActiveSprites].distance = dist;
      numActiveSprites++;
    }
  }

  // Sort sprites by distance (bubble sort)
  for (int i = 0; i < numActiveSprites - 1; i++) {
    for (int j = 0; j < numActiveSprites - i - 1; j++) {
      if (spriteDistances[j].distance < spriteDistances[j + 1].distance) {
        SpriteDistance tmp = spriteDistances[j];
        spriteDistances[j] = spriteDistances[j + 1];
        spriteDistances[j + 1] = tmp;
      }
    }
  }

  // Draw sprites in sorted order
  for (int i = 0; i < numActiveSprites; i++) {
    int index = spriteDistances[i].index;
    float dist = spriteDistances[i].distance;
    if (!sprites[index].active) continue;

    float spriteX = sprites[index].x - playerX;
    float spriteY = sprites[index].y - playerY;
    float spriteAngle = atan2f(spriteY, spriteX) - playerAngle;
    if (spriteAngle < -M_PI) spriteAngle += 2 * M_PI;
    if (spriteAngle > M_PI) spriteAngle -= 2 * M_PI;

    // Include partially visible sprites with overscan
    float overscanFactor = 1.8f; // Adjust for overscan
    float maxAngle = (FOV / 2.0f) * overscanFactor;

    if (fabsf(spriteAngle) > maxAngle) continue;

    float correctedDistance = dist * fast_cos(spriteAngle);
    if (correctedDistance < 0.1f) correctedDistance = 0.1f;

    float spriteScreenX = (SMALL_SCREEN_WIDTH / 2.0f) + tanf(spriteAngle) * (SMALL_SCREEN_WIDTH / (2.0f * tanf(FOV / 2.0f)));
    int spriteType = sprites[index].spriteType;

    float spriteHeight = (SMALL_SCREEN_HEIGHT / correctedDistance) * spriteScales[spriteType];
    float spriteWidth = spriteHeight * ((float)PIC_W_FULL[spriteType] / PIC_H[spriteType]);

    int drawStartX = (int)(spriteScreenX - spriteWidth / 2);
    int drawEndX = (int)(spriteScreenX + spriteWidth / 2);

    // Adjust vertical position based on sprite alignment
    float spriteScreenY;
    switch (sprites[index].verticalPos) {
      case SPRITE_POS_FLOOR:
        {
          float playerHeight = 0.5f; // Camera height at half wall height
          float floorY = SMALL_SCREEN_HEIGHT / 2.0f + (SMALL_SCREEN_HEIGHT / 2.0f) * (playerHeight / correctedDistance);
          spriteScreenY = floorY - spriteHeight;
          break;
        }
      case SPRITE_POS_CENTER:
        spriteScreenY = (SMALL_SCREEN_HEIGHT - spriteHeight) / 2.0f;
        break;
      case SPRITE_POS_CEILING:
        spriteScreenY = 0;
        break;
      default:
        spriteScreenY = (SMALL_SCREEN_HEIGHT - spriteHeight) / 2.0f;
    }

    int drawStartY = (int)spriteScreenY;
    int drawEndY = drawStartY + (int)spriteHeight;

    if (drawEndX >= 0 && drawStartX < SMALL_SCREEN_WIDTH && drawEndY >= 0 && drawStartY < SMALL_SCREEN_HEIGHT && correctedDistance < 10) {
      if (spriteType > 0 && spriteType < sizeof(PIC) / sizeof(PIC[0])) {
        DrawScaledSprite(
          getNextImageAddress(index, spriteType), PIC_PAL[spriteType],
          0, 0, // Source position
          drawStartX, drawStartY,
          (int)spriteWidth, (int)spriteHeight,
          PIC_W_FULL[spriteType], PIC_H[spriteType],
          color(0, 63, 0), correctedDistance);
      }
    }
  }

  // Render additional elements
  drawParticles();
  drawFireballs();
  RefreshBuf();
  
#ifdef FPS_DRAW
 drawHUD();
 #endif
 
  drawWeapon();
  drawOSD();

  // Calculate and update FPS
  frameCount++;
  uint32_t currentTime = time_us_32();
  if (currentTime - lastTime >= 1000000) {
    fps = (float)frameCount * 1000000.0f / (currentTime - lastTime);
    frameCount = 0;
    lastTime = currentTime;
  }

  gunFiring = 0; // Reset gun firing state
}

#define PLAYER_RADIUS 0.1f // Player collision radius

void update() {
    // Calculate delta time for smooth updates
    static uint32_t lastUpdateTime = 0;
    uint32_t currentTime = time_us_32();
    float deltaTime = (currentTime - lastUpdateTime) / 1000000.0f;
    if (deltaTime > 0.1f) deltaTime = 0.1f;  // Cap delta time to prevent large jumps
    lastUpdateTime = currentTime;

    // Update game triggers with delta time
    VarTriggerDeltaTime(deltaTime);

    // Update hit flash effect
    if (hitFlashTime > 0.0f) {
        hitFlashTime -= deltaTime;
        if (hitFlashTime < 0.0f) hitFlashTime = 0.0f;
    }

    // Handle automatic door opening
    if (autoOpeningDoorX != -1 && autoOpeningDoorY != -1) {
        if (autoOpeningDoorX >= 0 && autoOpeningDoorX < MAP_SIZE_X && autoOpeningDoorY >= 0 && autoOpeningDoorY < MAP_SIZE_Y && TYPE_SPK[getLevelValue(autoOpeningDoorX, autoOpeningDoorY)] == DOOR && doorStates[autoOpeningDoorY][autoOpeningDoorX] < DOOR_OPENING_STEPS) {
            autoOpeningTimer += deltaTime;
            float progress = autoOpeningTimer / DOOR_OPENING_DURATION;
            if (progress > 1.0f) progress = 1.0f;
            doorStates[autoOpeningDoorY][autoOpeningDoorX] = (int)(progress * DOOR_OPENING_STEPS);
            if (doorStates[autoOpeningDoorY][autoOpeningDoorX] >= DOOR_OPENING_STEPS) {
                autoOpeningDoorX = -1;
                autoOpeningDoorY = -1;
                autoOpeningTimer = 0.0f;
            }
        } else {
            autoOpeningDoorX = -1;
            autoOpeningDoorY = -1;
            autoOpeningTimer = 0.0f;
        }
    }

    // Handle player shooting
    static uint32_t lastDamageTime = 0;
    uint32_t currentTimeSec = currentTime / 1000000;
    if ((BUTTON_A) && (GunReady == ShootRep)) {
        float rayX = playerX, rayY = playerY;
        float rayAngle = playerAngle;
        float distance = 0;
        int mapX, mapY;
        float hitX, hitY;
        int hitSomething = 0;
        playerAmmo = (playerAmmo > 0) ? playerAmmo - 1 : playerAmmo;

        // Raycast to detect hits
        while (distance < 10.0f && !hitSomething) {
            rayX += fast_cos(rayAngle) * STEP_SIZE;
            rayY += fast_sin(rayAngle) * STEP_SIZE;
            distance += STEP_SIZE;
            mapX = (int)rayX;
            mapY = (int)rayY;

            if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
                // Check for sprite hits
                for (int i = 0; i < NUM_SPRITES; i++) {
                    if (!sprites[i].DeadActivate && !sprites[i].isCollectable) {
                        float dx = sprites[i].x - rayX;
                        float dy = sprites[i].y - rayY;
                        float distSquared = dx * dx + dy * dy;
                        if (distSquared < 0.09f) {
                            sprites[i].health -= 10;
                            if (sprites[i].health <= 0) {
                                SetDeadAnim(i);
                                score += 10;
                            }
                            createParticles(sprites[i].x, sprites[i].y, 0.0f, 1);
                            hitSomething = 1;
                            break;
                        }
                    }
                }
                // Check for wall or door hits
                if (!hitSomething && (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10))) {
                    hitX = rayX;
                    hitY = rayY;
                    createParticles(hitX, hitY, 0.0f, 0);
                    hitSomething = 1;
                }
            } else {
                hitSomething = 1;
            }
        }
        SND_FIRE();
        gunFiring = 1;
        GunReady = 0;
    }

    // Update gun firing animation
    if (gunFiring) {
        gunFireCounter++;
        if (gunFireCounter >= gunFireDurationFrames) {
            gunFireCounter = 0;
        }
    }

    // Update player movement and rotation
    float prevPlayerX = playerX;
    float prevPlayerY = playerY;
    float angularInput = 0.0f;
    float inputX = 0.0f, inputY = 0.0f;

    if (BUTTON_B) {
        // Strafing mode: left/right moves player laterally
        if (TINYJOYPAD_LEFT && !TINYJOYPAD_RIGHT) {
            inputX -= fast_cos(playerAngle + M_PI / 2.0f) * ACCELERATION * deltaTime;
            inputY -= fast_sin(playerAngle + M_PI / 2.0f) * ACCELERATION * deltaTime;
        } else if (TINYJOYPAD_RIGHT && !TINYJOYPAD_LEFT) {
            inputX += fast_cos(playerAngle + M_PI / 2.0f) * ACCELERATION * deltaTime;
            inputY += fast_sin(playerAngle + M_PI / 2.0f) * ACCELERATION * deltaTime;
        }
    } else {
        // Normal rotation mode
        if (TINYJOYPAD_LEFT && !TINYJOYPAD_RIGHT) {
            angularInput = -ANGULAR_ACCELERATION * deltaTime;
        } else if (TINYJOYPAD_RIGHT && !TINYJOYPAD_LEFT) {
            angularInput = ANGULAR_ACCELERATION * deltaTime;
        }
    }

    // Apply angular velocity and friction
    angularVelocity += angularInput;
    angularVelocity *= pow(ANGULAR_FRICTION, deltaTime * 60.0f);
    if (fabs(angularVelocity) > MAX_ANGULAR_SPEED) {
        angularVelocity = (angularVelocity > 0) ? MAX_ANGULAR_SPEED : -MAX_ANGULAR_SPEED;
    }
    playerAngle += angularVelocity * deltaTime;
    normalizeAngle(&playerAngle);

    // Handle forward/backward movement
    if (TINYJOYPAD_UP && !TINYJOYPAD_DOWN) {
        inputX += fast_cos(playerAngle) * ACCELERATION * deltaTime;
        inputY += fast_sin(playerAngle) * ACCELERATION * deltaTime;
    } else if (TINYJOYPAD_DOWN && !TINYJOYPAD_UP) {
        inputX -= fast_cos(playerAngle) * ACCELERATION * deltaTime;
        inputY -= fast_sin(playerAngle) * ACCELERATION * deltaTime;
    }

    // Apply velocity and friction
    velocityX += inputX;
    velocityY += inputY;
    velocityX *= pow(FRICTION, deltaTime * 60.0f);
    velocityY *= pow(FRICTION, deltaTime * 60.0f);
    float speedSquared = velocityX * velocityX + velocityY * velocityY;
    if (speedSquared > MAX_SPEED * MAX_SPEED) {
        float scale = MAX_SPEED / sqrt(speedSquared);
        velocityX *= scale;
        velocityY *= scale;
    }

    // Check collisions with walls and doors (circular detection)
    float nextX = playerX + velocityX * deltaTime;
    float nextY = playerY + velocityY * deltaTime;
    bool canMove = true;
    float normalX = 0.0f, normalY = 0.0f;
    float closestDistSquared = PLAYER_RADIUS * PLAYER_RADIUS;

    // Define cells to check around player
    int minX = (int)(nextX - PLAYER_RADIUS - 0.2f);
    int maxX = (int)(nextX + PLAYER_RADIUS + 0.2f);
    int minY = (int)(nextY - PLAYER_RADIUS - 0.2f);
    int maxY = (int)(nextY + PLAYER_RADIUS + 0.2f);

    // Check collisions with walls and doors
    for (int mapY = minY; mapY <= maxY; mapY++) {
        for (int mapX = minX; mapX <= maxX; mapX++) {
            bool isWall = false;
            if (mapX < 0 || mapX >= MAP_SIZE_X || mapY < 0 || mapY >= MAP_SIZE_Y) {
                isWall = true; // Map edges treated as walls
            } else if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || 
                       (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
                isWall = true;
            }
            if (isWall) {
                float closestX = fmax(mapX, fmin(nextX, mapX + 1.0f));
                float closestY = fmax(mapY, fmin(nextY, mapY + 1.0f));
                float dx = nextX - closestX;
                float dy = nextY - closestY;
                float distSquared = dx * dx + dy * dy;

                if (distSquared < closestDistSquared) {
                    canMove = false;
                    closestDistSquared = distSquared;
                    float dist = sqrt(distSquared);
                    if (dist < 0.001f) dist = 0.001f;
                    normalX = dx / dist;
                    normalY = dy / dist;
                }
            }
        }
    }

    // Check collisions with enemies
    for (int i = 0; i < NUM_SPRITES; i++) {
        if (!sprites[i].DeadActivate && !sprites[i].isCollectable) {
            float dx = nextX - sprites[i].x;
            float dy = nextY - sprites[i].y;
            float distSquared = dx * dx + dy * dy;
            if (distSquared < (COLLISION_DISTANCE ) * (COLLISION_DISTANCE)) {
                float moveX = nextX - playerX;
                float moveY = nextY - playerY;
                float dist = sqrt(distSquared);
                if (dist < 0.001f) dist = 0.001f;
                float enemyNormalX = dx / dist;
                float enemyNormalY = dy / dist;
                float dotProduct = moveX * enemyNormalX + moveY * enemyNormalY;
                if (dotProduct < 0) {
                    canMove = false;
                    if (distSquared < closestDistSquared) {
                        closestDistSquared = distSquared;
                        normalX = enemyNormalX;
                        normalY = enemyNormalY;
                    }
                }
            }
        }
    }

    // Smooth collision normal to prevent abrupt transitions
    static float smoothedNormalX = 0.0f, smoothedNormalY = 0.0f;
    if (canMove) {
        smoothedNormalX = 0.0f;
        smoothedNormalY = 0.0f;
    } else {
        smoothedNormalX = 0.9f * normalX + 0.1f * smoothedNormalX;
        smoothedNormalY = 0.9f * normalY + 0.1f * smoothedNormalY;
        float normalLength = sqrt(smoothedNormalX * smoothedNormalX + smoothedNormalY * smoothedNormalY);
        if (normalLength > 0.001f) {
            smoothedNormalX /= normalLength;
            smoothedNormalY /= normalLength;
        } else {
            smoothedNormalX = 0.0f;
            smoothedNormalY = 0.0f;
        }
    }

    if (canMove) {
        playerX = nextX;
        playerY = nextY;
    } else {
        // Calculate sliding movement
        float dotProduct = velocityX * smoothedNormalX + velocityY * smoothedNormalY;
        float slideX = velocityX - dotProduct * smoothedNormalX;
        float slideY = velocityY - dotProduct * smoothedNormalY;
        nextX = playerX + slideX * deltaTime;
        nextY = playerY + slideY * deltaTime;

        // Validate sliding movement
        bool canSlide = true;
        minX = (int)(nextX - PLAYER_RADIUS - 0.2f);
        maxX = (int)(nextX + PLAYER_RADIUS + 0.2f);
        minY = (int)(nextY - PLAYER_RADIUS - 0.2f);
        maxY = (int)(nextY + PLAYER_RADIUS + 0.2f);

        for (int mapY = minY; mapY <= maxY; mapY++) {
            for (int mapX = minX; mapX <= maxX; mapX++) {
                bool isWall = false;
                if (mapX < 0 || mapX >= MAP_SIZE_X || mapY < 0 || mapY >= MAP_SIZE_Y) {
                    isWall = true;
                } else if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || 
                           (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
                    isWall = true;
                }
                if (isWall) {
                    float closestX = fmax(mapX, fmin(nextX, mapX + 1.0f));
                    float closestY = fmax(mapY, fmin(nextY, mapY + 1.0f));
                    float dx = nextX - closestX;
                    float dy = nextY - closestY;
                    float distSquared = dx * dx + dy * dy;
                    if (distSquared < PLAYER_RADIUS * PLAYER_RADIUS) {
                        canSlide = false;
                        break;
                    }
                }
            }
            if (!canSlide) break;
        }

        for (int i = 0; i < NUM_SPRITES; i++) {
            if (!sprites[i].DeadActivate && !sprites[i].isCollectable) {
                float dx = nextX - sprites[i].x;
                float dy = nextY - sprites[i].y;
                float distSquared = dx * dx + dy * dy;
                if (distSquared < (COLLISION_DISTANCE + PLAYER_RADIUS) * (COLLISION_DISTANCE + PLAYER_RADIUS)) {
                    float moveX = nextX - playerX;
                    float moveY = nextY - playerY;
                    float dist = sqrt(distSquared);
                    if (dist < 0.001f) dist = 0.001f;
                    float enemyNormalX = dx / dist;
                    float enemyNormalY = dy / dist;
                    float dotProductEnemy = moveX * enemyNormalX + moveY * enemyNormalY;
                    if (dotProductEnemy < 0) {
                        canSlide = false;
                        break;
                    }
                }
            }
        }

        if (canSlide) {
            playerX = nextX;
            playerY = nextY;
        } else {
            // Try partial movement along X or Y
            float partialNextX = playerX + slideX * deltaTime;
            float partialNextY = playerY;
            bool canMovePartialX = true;

            minX = (int)(partialNextX - PLAYER_RADIUS - 0.2f);
            maxX = (int)(partialNextX + PLAYER_RADIUS + 0.2f);
            minY = (int)(partialNextY - PLAYER_RADIUS - 0.2f);
            maxY = (int)(partialNextY + PLAYER_RADIUS + 0.2f);

            for (int mapY = minY; mapY <= maxY; mapY++) {
                for (int mapX = minX; mapX <= maxX; mapX++) {
                    bool isWall = false;
                    if (mapX < 0 || mapX >= MAP_SIZE_X || mapY < 0 || mapY >= MAP_SIZE_Y) {
                        isWall = true;
                    } else if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || 
                               (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
                        isWall = true;
                    }
                    if (isWall) {
                        float closestX = fmax(mapX, fmin(partialNextX, mapX + 1.0f));
                        float closestY = fmax(mapY, fmin(partialNextY, mapY + 1.0f));
                        float dx = partialNextX - closestX;
                        float dy = partialNextY - closestY;
                        float distSquared = dx * dx + dy * dy;
                        if (distSquared < PLAYER_RADIUS * PLAYER_RADIUS) {
                            canMovePartialX = false;
                            break;
                        }
                    }
                }
                if (!canMovePartialX) break;
            }

            for (int i = 0; i < NUM_SPRITES; i++) {
                if (!sprites[i].DeadActivate && !sprites[i].isCollectable) {
                    float dx = partialNextX - sprites[i].x;
                    float dy = partialNextY - sprites[i].y;
                    float distSquared = dx * dx + dy * dy;
                    if (distSquared < (COLLISION_DISTANCE + PLAYER_RADIUS) * (COLLISION_DISTANCE + PLAYER_RADIUS)) {
                        canMovePartialX = false;
                        break;
                    }
                }
            }

            if (canMovePartialX) {
                playerX = partialNextX;
                playerY = partialNextY;
            } else {
                // Try partial movement along Y
                partialNextX = playerX;
                partialNextY = playerY + slideY * deltaTime;
                bool canMovePartialY = true;

                minX = (int)(partialNextX - PLAYER_RADIUS - 0.2f);
                maxX = (int)(partialNextX + PLAYER_RADIUS + 0.2f);
                minY = (int)(partialNextY - PLAYER_RADIUS - 0.2f);
                maxY = (int)(partialNextY + PLAYER_RADIUS + 0.2f);

                for (int mapY = minY; mapY <= maxY; mapY++) {
                    for (int mapX = minX; mapX <= maxX; mapX++) {
                        bool isWall = false;
                        if (mapX < 0 || mapX >= MAP_SIZE_X || mapY < 0 || mapY >= MAP_SIZE_Y) {
                            isWall = true;
                        } else if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || 
                                   (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
                            isWall = true;
                        }
                        if (isWall) {
                            float closestX = fmax(mapX, fmin(partialNextX, mapX + 1.0f));
                            float closestY = fmax(mapY, fmin(partialNextY, mapY + 1.0f));
                            float dx = partialNextX - closestX;
                            float dy = partialNextY - closestY;
                            float distSquared = dx * dx + dy * dy;
                            if (distSquared < PLAYER_RADIUS * PLAYER_RADIUS) {
                                canMovePartialY = false;
                                break;
                            }
                        }
                    }
                    if (!canMovePartialY) break;
                }

                for (int i = 0; i < NUM_SPRITES; i++) {
                    if (!sprites[i].DeadActivate && !sprites[i].isCollectable) {
                        float dx = partialNextX - sprites[i].x;
                        float dy = partialNextY - sprites[i].y;
                        float distSquared = dx * dx + dy * dy;
                        if (distSquared < (COLLISION_DISTANCE + PLAYER_RADIUS) * (COLLISION_DISTANCE + PLAYER_RADIUS)) {
                            canMovePartialY = false;
                            break;
                        }
                    }
                }

                if (canMovePartialY) {
                    playerX = partialNextX;
                    playerY = partialNextY;
                } else {
                    // Stop velocity if no movement is possible
                    velocityX = 0.0f;
                    velocityY = 0.0f;
                }
            }
        }
    }

    // Update bobbing effect
    float dx = playerX - prevPlayerX;
    float dy = playerY - prevPlayerY;
    float forwardComponent = dx * fast_cos(playerAngle) + dy * fast_sin(playerAngle);
    forwardDistance += fabs(forwardComponent);
    if (forwardDistance >= DISTANCE_PER_FRAME) {
        if (Trig3) {
            bobIndex = (bobIndex + 1) % BOB_POINTS;     
            Trig3 = 0;  
            forwardDistance = 0.0f;
        }
    }
    if (Trig1) {
        GunReady = playerAmmo ? ((GunReady < ShootRep) ? GunReady + 1 : GunReady) : 0;
    }
    
    // Update sprites (enemies)
    static uint32_t lastFireTime = 0;
    for (int i = 0; i < NUM_SPRITES; i++) {
        if (sprites[i].active && sprites[i].DeadActivate == 0) {
            float dx = playerX - sprites[i].x;
            float dy = playerY - sprites[i].y;
            float distSquared = dx * dx + dy * dy;

            // Handle collectable items
            if (sprites[i].isCollectable && distSquared < (COLLISION_DISTANCE ) * (COLLISION_DISTANCE )) {
                sprites[i].active = 0;
                score += 50;
                switch (sprites[i].Mapref) {
                    case 4: KeyCard.GreenCard = 1; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 8: KeyCard.RedCard = 1; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 9: KeyCard.BlueCard = 1; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 10: playerAmmo = (playerAmmo + ADD_AMMO < MAX_AMMO) ? playerAmmo + ADD_AMMO : MAX_AMMO; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 11: KeyCard.GoldCard = 1; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 13: gameState = 3; SND_ENDLVL(); break;
                    case 14: playerHealth = (playerHealth + ADD_HEALTH < MAX_HEALTH) ? playerHealth + ADD_HEALTH : MAX_HEALTH; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                    case 26: Total_Skull++; MakeColorFlash(COL_BLUE); SND_PICKUP(); break;
                }
                continue;
            }

            // Handle enemy behavior
            if (!sprites[i].isCollectable && distSquared < DIST_TRIG_ENEMY) {
                bool hasLineOfSight = true;
                float rayX = sprites[i].x;
                float rayY = sprites[i].y;
                float rayAngle = atan2(dy, dx);
                float rayDistance = 0.0f;
                while (rayDistance < sqrt(distSquared)) {
                    rayX += fast_cos(rayAngle) * STEP_SIZE * 2.0f;
                    rayY += fast_sin(rayAngle) * STEP_SIZE * 2.0f;
                    rayDistance += STEP_SIZE * 2.0f;
                    int mapX = (int)rayX;
                    int mapY = (int)rayY;
                    if (mapX >= 0 && mapX < MAP_SIZE_X && mapY >= 0 && mapY < MAP_SIZE_Y) {
                        if (TYPE_SPK[getLevelValue(mapX, mapY)] == WALL || (TYPE_SPK[getLevelValue(mapX, mapY)] == DOOR && doorStates[mapY][mapX] < 10)) {
                            hasLineOfSight = false;
                            break;
                        }
                    } else {
                        hasLineOfSight = false;
                        break;
                    }
                }
                if (hasLineOfSight) {
                    // Move enemy towards player
                    if (distSquared > MIN_ENEMY_DISTANCE_SQUARED) {
                        float speed = 0.5f;
                        float moveX = (dx / sqrt(distSquared)) * speed * deltaTime;
                        float moveY = (dy / sqrt(distSquared)) * speed * deltaTime;
                        float nextSpriteX = sprites[i].x + moveX;
                        float nextSpriteY = sprites[i].y + moveY;
                        int spriteMapX = (int)nextSpriteX;
                        int spriteMapY = (int)nextSpriteY;
                        bool spriteCanMove = true;
                        if (spriteMapX >= 0 && spriteMapX < MAP_SIZE_X && spriteMapY >= 0 && spriteMapY < MAP_SIZE_Y && 
                            (TYPE_SPK[getLevelValue(spriteMapX, spriteMapY)] == WALL || 
                             (TYPE_SPK[getLevelValue(spriteMapX, spriteMapY)] == DOOR && doorStates[spriteMapY][spriteMapX] < 10))) {
                            spriteCanMove = false;
                        }
                        float nextDx = nextSpriteX - playerX;
                        float nextDy = nextSpriteY - playerY;
                        if (nextDx * nextDx + nextDy * nextDy < (COLLISION_DISTANCE_M + PLAYER_RADIUS) * (COLLISION_DISTANCE_M + PLAYER_RADIUS)) {
                            spriteCanMove = false;
                        }
                        for (int j = 0; j < NUM_SPRITES; j++) {
                            if (i != j && sprites[j].active && !sprites[j].DeadActivate && !sprites[j].isCollectable) {
                                float dxOther = nextSpriteX - sprites[j].x;
                                float dyOther = nextSpriteY - sprites[j].y;
                                if (dxOther * dxOther + dyOther * dyOther < COLLISION_DISTANCE_M * COLLISION_DISTANCE_M) {
                                    spriteCanMove = false;
                                    break;
                                }
                            }
                        }
                        if (spriteCanMove) {
                            sprites[i].x = nextSpriteX;
                            sprites[i].y = nextSpriteY;
                        }
                    }
                    // Enemy attacks player
                    if (distSquared < (COLLISION_DISTANCE + PLAYER_RADIUS) * (COLLISION_DISTANCE + PLAYER_RADIUS) && currentTimeSec - lastDamageTime >= 1) {
                        playerHealthDown(SPRITE_DAMAGE);
                        SND_PLsnd2();
                        lastDamageTime = currentTimeSec;
                    }
                    // Enemy fires fireball
                    if (currentTimeSec - lastFireTime >= 2 && distSquared < 54.0f) {
                        createFireball(sprites[i].x, sprites[i].y, playerX, playerY);
                        lastFireTime = currentTimeSec;
                    }
                }
            }
        }
    }

    // Handle door interaction
    interactWithDoor();

    // Check for player death (game over)
    if (playerHealth <= 0) {
        gameState = 4;
        sleep_ms(100);
        SND_PLsnd3();
    }

    // Update particles and fireballs
    if (Trig2) {
        updateParticles(deltaTime);
        updateFireballs(deltaTime);
        Trig2 = false;
    }
}

void FadeOutToBlack(void) {
  const int STEPS = 8;         // Number of steps for the fade effect
  const int LINE_SPACING = 8;  // Process one out of every 8 lines per step

  // Iterate through each fade step
  for (int step = 0; step < STEPS; step++) {
    // Loop through all screen lines
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
      // Draw a black horizontal line for the current step's designated lines
      if ((y % LINE_SPACING) == step) {
        DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // Black line from (0,y) to (SCREEN_WIDTH-1,y)
      }
    }
    DispUpdate();  // Refresh the display
    sleep_ms(33);  // Delay for 33ms to control animation speed (~30 FPS)
  }

  DispUpdate();  // Final display refresh
}

void FadeInFromBlack(const u8 *PIC_, const u16 *PIC_PAL_) {
  const int STEPS = 8;         // Number of steps for the fade-in effect
  const int LINE_SPACING = 8;  // Process one out of every 8 lines per step

  // Iterate through each fade step
  for (int step = 0; step < STEPS; step++) {
    // Draw the full image
    DrawBlitPal(PIC_, PIC_PAL_,
                0, 0,            // Source position (x, y)
                0, 0,            // Destination position (x, y)
                menu_W, menu_H,  // Image width and height
                menu_W_FULL,     // Full image width
                COL_RED);        // Color (no filter, using red as placeholder)

    // Draw remaining black lines for previous steps
    for (int s = step; s < STEPS; s++) {
      for (int y = 0; y < SCREEN_HEIGHT; y++) {
        // Draw black lines for steps not yet revealed
        if ((y % LINE_SPACING) == s) {
          DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // Black horizontal line
        }
      }
    }

    DispUpdate();  // Refresh the display
    sleep_ms(33);  // Delay for 33ms (~30 FPS)
  }

  // Display the final image without black lines
  DrawBlitPal(PIC_, PIC_PAL_,
              0, 0,
              0, 0,
              menu_W, menu_H,
              menu_W_FULL, COL_RED);
  DispUpdate();  // Final display refresh
}

void FadeInGame(void) {
  const int STEPS = 8;         // Number of steps for the game fade-in effect
  const int LINE_SPACING = 8;  // Process one out of every 8 lines per step

  update();  // Update game state before fade-in

  // Iterate through each fade step
  for (int step = 0; step < STEPS; step++) {
    render();  // Render the game scene

    // Draw remaining black lines for previous steps
    for (int s = step; s < STEPS; s++) {
      for (int y = 0; y < SCREEN_HEIGHT; y++) {
        // Draw black lines for steps not yet revealed
        if ((y % LINE_SPACING) == s) {
          DrawLine(0, y, SCREEN_WIDTH - 1, y, 0); // Black horizontal line
        }
      }
    }

    DispUpdate();  // Refresh the display
    sleep_ms(33);  // Delay for 33ms (~30 FPS)
  }

  DispUpdate();  // Final display refresh
}

int main() {
  gameState = 1;  // Initialize game state
  int button_y_hold_counter = 0;  // Counter for holding the Y button
  const int HOLD_FRAMES = 10;    // Frames to hold Y button (e.g., 10 frames at 60 FPS ≈ 0.17s)

  // Configure hardware based on platform
  #if USE_PICOPAD10
    vreg_set_voltage(VREG_VOLTAGE_1_20); // Set voltage for PicoPad10
    sleep_ms(100);
    set_sys_clock_khz(250000, true);    // Set clock speed
    DispUpdate();
    sleep_ms(300);
  #elif USE_PICOPAD20
    vreg_set_voltage(VREG_VOLTAGE_1_30); // Set voltage for PicoPad20
    sleep_ms(100);
    set_sys_clock_khz(300000, true);    // Set clock speed
    DispUpdate();
    sleep_ms(300);
  #else
    DispUpdate();
    sleep_ms(300);
  #endif
  init_trig_tables();  // Initialize trigonometric tables

  // Set resolution based on platform
  #if USE_PICOPAD10
    SetNewResolution(1);
  #else
    SetNewResolution(2);
  #endif
  
  sleep_ms(500);  // Brief delay
  PlaySoundChan(0, logo, 110336, 0, 1, 1, SNDFORM_PCM, 1); // Play logo sound
  FadeInFromBlack(splash, splash_Pal);  // Display first splash screen
  sleep_ms(3000);                       // Wait 3 seconds
  FadeOutToBlack();                     // Fade to black
  sleep_ms(500);                        // Brief delay
  FadeInFromBlack(splash2, splash2_Pal); // Display second splash screen
  sleep_ms(3000);                        // Wait 3 seconds
  FadeOutToBlack();                      // Fade to black

  while (1) {
    switch (gameState) {
      case 0:  // Game running state
        update();  // Update game logic

        // Handle Y button hold to transition to menu
        button_y_hold_counter = BUTTON_Y ? (button_y_hold_counter + 1 >= HOLD_FRAMES ? (gameState = 2, 0) : button_y_hold_counter + 1) : 0;

        render();  // Render game scene
        DispUpdate(); // Refresh display
        ResetTriggers(); // Reset input triggers

        #if USE_SCREENSHOT
          switch (KeyGet()) {
            case KEY_Y: SmallScreenShot(); // Take screenshot if Y key pressed
          }
        #endif
        break;
      case 1:  // Initial state (fall-through to case 2)
      case 2:  // Menu state
        FadeOutToBlack();               // Fade to black
        sleep_ms(1000);                 // Wait 1 second
        FadeInFromBlack(menu, menu_Pal); // Display menu
        MenuIntro(gameState);           // Show menu intro
        FadeOutToBlack();               // Fade to black
        sleep_ms(500);                  // Brief delay
        gameState = 0;                  // Return to game state
        FadeInGame();                   // Fade into game
        break;
      case 3:  // Display score screen
        DisplayScore();
        break;
      case 4:  // Game over state
        FadeOutToBlack();
        GameOverSplash();  // Show game over screen
        gameState = 1;     // Return to initial state
        break;
      default:
        break;
    }
  }
  return 0;
}

uint16_t getEnemiesKilled(void) {
  uint16_t enemiesKilled = 0;

  // Loop through all sprites
  for (int i = 0; i < NUM_SPRITES; i++) {
    // Count enemies that are not collectables and are either dead or inactive
    if (!sprites[i].isCollectable && (sprites[i].DeadActivate || !sprites[i].active)) {
      enemiesKilled++;
    }
  }

  return enemiesKilled; // Return total enemies killed
}

uint8_t Total_Skull_In_All_Level(void) {
  uint8_t totalSkull_ = 0;

  // Iterate through all levels
  for (int level_ = 0; level_ < TOTAL_LVL; level_++) {
    const uint8_t *currentLevel = LEVELS[level_];
    uint8_t width_ = currentLevel[0];  // Map width
    uint8_t height_ = currentLevel[1]; // Map height

    // Scan the map grid for skulls (cell value 26)
    for (int y = 0; y < height_; y++) {
      for (int x = 0; x < width_; x++) {
        if (currentLevel[2 + y * width_ + x] == 26) {
          totalSkull_++;
        }
      }
    }
  }

  return totalSkull_; // Return total number of skulls
}

uint8_t Next_Level(void) {
  // Advance to next level if not at the second-to-last level
  if (Level_Use < TOTAL_LVL - 2) {
    Level_Use++;
    return 1;
  } else {
    // If at second-to-last level, check if all skulls collected
    if (Total_Skull == Total_Skull_In_All_Level()) {
      if (Level_Use < TOTAL_LVL - 1) {
        Level_Use++;
        return 1;
      }
      return 0; // No more levels
    }
  }
  return 0; // Cannot advance
}

void DisplayScore(void) {
  FadeOutToBlack(); // Fade to black
  sleep_ms(500);    // Brief delay

  // Display score page with level, enemies killed, health, ammo, and score
  DisplayScorePage(Level_Use, getEnemiesKilled(), playerHealth, playerAmmo, &score);
  FadeOutToBlack(); // Fade to black

  // Check if there's a next level
  if (Next_Level()) {
    enteringNewLevel(); // Show new level intro
    FadeOutToBlack();   // Fade to black
    InitNewLevel();     // Initialize new level
    FadeInGame();       // Fade into game
    gameState = 0;      // Set to game running state
  } else {
    FadeInFromBlack(Congrat, Congrat_Pal); // Show congratulations screen
    sleep_ms(3000);                        // Wait 3 seconds
    FadeOutToBlack();                      // Fade to black
    gameState = 1;                         // Return to initial state
  }
}

void DisplayScorePage(uint8_t level, uint16_t enemiesKilled, uint8_t health, uint8_t ammo, uint16_t *score_) {
  #define TEXT_X 90        // Starting X position for text
  #define TEXT_Y 4         // Starting Y position for text
  #define LINE_SPACING 25  // Spacing between text lines
  #define FRAME_TIME_MS 33 // Frame time for ~30 FPS
  #define TEXT_SHADOW 2    // Pixel offset for text shadow

  char bufferText[64];
  uint16_t baseScore = *score_; // Initial score
  uint16_t tempEnemies = 0;     // Temporary enemies killed counter
  uint16_t tempHealth = 0;      // Temporary health counter
  uint16_t tempAmmo = 0;        // Temporary ammo counter
  uint16_t tempScore = baseScore; // Temporary score
  uint8_t step = 0;             // Animation step
  uint16_t frameDelay = 1;      // Frames per increment (controls animation speed)

  Total_Kill += enemiesKilled;  // Update total kills

  FadeInFromBlack(ScorePic, ScorePic_Pal); // Fade in score screen

  // Main animation loop
  while (step <= 4) {
    absolute_time_t frameStart = get_absolute_time(); // Record frame start time

    // Draw background image
    DrawBlitPal(ScorePic, ScorePic_Pal, 0, 0, 0, 0, menu_W, menu_H, menu_W_FULL, COL_RED);

    // Display "Level X Completed" with shadow
    snprintf(bufferText, sizeof(bufferText), "Level %d Completed", (level + 1));
    DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + TEXT_SHADOW, COL_BLACK); // Shadow
    DrawTextH(bufferText, TEXT_X, TEXT_Y, COL_YELLOW); // Main text

    // Display score at the bottom with shadow
    snprintf(bufferText, sizeof(bufferText), "Score: %ld", tempScore);
    DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 7 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
    DrawTextH(bufferText, TEXT_X, TEXT_Y + 7 * LINE_SPACING, COL_WHITE); // Main text

    // Step 1: Animate enemies killed
    if (step == 1) {
      if (tempEnemies < enemiesKilled) {
        tempEnemies++; // Increment until target reached
        tempScore += 15; // Add 15 points per enemy
      }
      snprintf(bufferText, sizeof(bufferText), "Enemies Killed: %d", tempEnemies);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 2 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 2 * LINE_SPACING, COL_WHITE); // Main text
    } else if (step >= 2) {
      // Display final enemies killed value with shadow
      snprintf(bufferText, sizeof(bufferText), "Enemies Killed: %d", enemiesKilled);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 2 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 2 * LINE_SPACING, COL_WHITE); // Main text

    }

    // Step 3: Animate health
    if (step == 3) {
      if (tempHealth < health) {
        tempHealth++; // Increment until target reached
        tempScore += 10; // Add 10 points per health point
      }
      snprintf(bufferText, sizeof(bufferText), "Health: %d", tempHealth);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 3 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 3 * LINE_SPACING, COL_WHITE); // Main text
    } else if (step >= 4) {
      // Display final health value with shadow
      snprintf(bufferText, sizeof(bufferText), "Health: %d", health);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 3 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 3 * LINE_SPACING, COL_WHITE); // Main text
    }

    // Step 4: Animate ammo
    if (step == 4) {
      if (tempAmmo < ammo) {
        tempAmmo++; // Increment until target reached
        tempScore += 5; // Add 5 points per ammo
      }
      snprintf(bufferText, sizeof(bufferText), "Ammo: %d", tempAmmo);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 4 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 4 * LINE_SPACING, COL_WHITE); // Main text
    } else if (step >= 5) {
      // Display final ammo value with shadow
      snprintf(bufferText, sizeof(bufferText), "Ammo: %d", ammo);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 4 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 4 * LINE_SPACING, COL_WHITE); // Main text
    }

    DispUpdate(); // Refresh display

    // Handle step transitions
    if (step == 0) {
      step = 1; // Start enemies killed animation
    } else if (step == 1 && tempEnemies >= enemiesKilled) {
      // Ensure final value is displayed
      snprintf(bufferText, sizeof(bufferText), "Enemies Killed: %d", enemiesKilled);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 2 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 2 * LINE_SPACING, COL_WHITE); // Main text
      DispUpdate(); // Refresh immediately
      sleep_ms(500); // Pause to mark end
      step = 2; // Move to next step
      SND_BUTTON();
    } else if (step == 2) {
      sleep_ms(500); // Pause for transition
      step = 3; // Start health animation
      SND_BUTTON();
    } else if (step == 3 && tempHealth >= health) {
      // Ensure final value is displayed
      snprintf(bufferText, sizeof(bufferText), "Health: %d", health);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 3 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 3 * LINE_SPACING, COL_WHITE); // Main text
      DispUpdate(); // Refresh immediately
      sleep_ms(500); // Pause to mark end
      step = 4; // Start ammo animation
      SND_BUTTON();
    } else if (step == 4 && tempAmmo >= ammo) {
      // Ensure final value is displayed
      snprintf(bufferText, sizeof(bufferText), "Ammo: %d", ammo);
      DrawTextH(bufferText, TEXT_X + TEXT_SHADOW, TEXT_Y + 4 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
      DrawTextH(bufferText, TEXT_X, TEXT_Y + 4 * LINE_SPACING, COL_WHITE); // Main text
      DispUpdate(); // Refresh immediately
      sleep_ms(500); // Pause to mark end
      step = 5; // End animation
      SND_BUTTON();
    } else if (step == 5) {
      break; // Exit loop
    }

    // Control animation speed
    static uint16_t frameCounter = 0;
    if (step == 1 || step == 3 || step == 4) {
      frameCounter++;
      if (frameCounter < frameDelay) {
        // Undo increment to slow animation
        if (step == 1) tempEnemies--;
        else if (step == 3) tempHealth--;
        else if (step == 4) tempAmmo--;
        tempScore -= (step == 1 ? 15 : step == 3 ? 10 : 5); // Undo score increment
      } else {
        frameCounter = 0; // Reset for next increment
      }
    }

    // Maintain ~30 FPS
    int64_t frameTime = absolute_time_diff_us(frameStart, get_absolute_time()) / 1000;
    if (frameTime < FRAME_TIME_MS) {
      sleep_ms(FRAME_TIME_MS - frameTime);
    }

    // Display skull count with icon
    DrawICO(TEXT_X, TEXT_Y + (5 * LINE_SPACING) + 5, 6);
    snprintf(bufferText, sizeof(bufferText), "         %d / %d", Total_Skull, Total_Skull_In_All_Level());
    DrawTextH(bufferText, TEXT_X - 40 + TEXT_SHADOW, TEXT_Y + 5 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
    DrawTextH(bufferText, TEXT_X - 40, TEXT_Y + 5 * LINE_SPACING, COL_WHITE); // Main text
  }

  // Update final score
  *score_ = tempScore;

  // Display verification code if not at final level or all skulls collected
  if ((Level_Use < TOTAL_LVL - 2) || (Level_Use == TOTAL_LVL - 2 && Total_Skull == Total_Skull_In_All_Level())) {
    CreateVcode(Level_Use, Total_Skull, Total_Kill, *score_, code);
    snprintf(bufferText, sizeof(bufferText), "Vcode: %s", code);
    DrawTextH(bufferText, TEXT_X - 20 + TEXT_SHADOW,( TEXT_Y + 8 * LINE_SPACING + TEXT_SHADOW)+8, COL_BLACK); // Shadow
    DrawTextH(bufferText, TEXT_X - 20, (TEXT_Y + 8 * LINE_SPACING)+8, COL_YELLOW); // Main text
  }
SND_PICKUP();
  DispUpdate(); // Final display refresh
  while (!BUTTON_DOWN); // Wait for button press
  STOP:;
}

void enteringNewLevel(void) {
  char bufferText[64];
  #define TEXT2_X 80        // Starting X position for text
  #define TEXT2_Y 210       // Starting Y position for text

  FadeInFromBlack(ScorePic, ScorePic_Pal); // Fade in score screen

  // Display level entry message
  if (Level_Use == TOTAL_LVL - 1) {
    DrawTextH("Backrooms Entrance!", TEXT2_X + 2, TEXT2_Y + 2, COL_BLACK); // Shadow
    DrawTextH("Backrooms Entrance!", TEXT2_X, TEXT2_Y, COL_YELLOW); // Main text
  } else {
    snprintf(bufferText, sizeof(bufferText), "Now entering Level %d", Level_Use + 1);
    DrawTextH(bufferText, TEXT2_X + 2, TEXT2_Y + 2, COL_BLACK); // Shadow
    DrawTextH(bufferText, TEXT2_X, TEXT2_Y, COL_YELLOW); // Main text
  }
  DispUpdate(); // Refresh display
  sleep_ms(2000); // Wait 2 seconds
}

uint16_t Total_Monster_In_All_Level(void) {
  uint16_t totalEnemies = 0;

  // Iterate through all levels
  for (int level = 0; level < TOTAL_LVL; level++) {
    const uint8_t *currentLevel = LEVELS[level];
    uint8_t width = currentLevel[0];  // Map width
    uint8_t height = currentLevel[1]; // Map height

    // Scan map grid for enemies
    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        uint8_t cellValue = currentLevel[2 + y * width + x];
        if (TYPE_SPK[cellValue] == ENEMY) {
          totalEnemies++;
        }
      }
    }
  }

  return totalEnemies; // Return total number of enemies
}

void GameOverSplash(void) {
  #define TEXT3_X 65        // Starting X position for text
  #define TEXT3_Y 0         // Starting Y position for text
  char bufferText[50];

  Total_Kill += getEnemiesKilled(); // Update total kills

  FadeOutToBlack(); // Fade to black
  FadeInFromBlack(go, go_Pal); // Fade in game over screen

  // Display "Level not completed" message
  snprintf(bufferText, sizeof(bufferText), " Level %d not completed.", Level_Use + 1);
  DrawTextH(bufferText, TEXT3_X + TEXT_SHADOW, TEXT3_Y + TEXT_SHADOW, COL_BLACK); // Shadow
  DrawTextH(bufferText, TEXT3_X, TEXT3_Y, COL_RED); // Main text

  // Display total kills
  snprintf(bufferText, sizeof(bufferText), "  Total kill: %d / %d", Total_Kill, Total_Monster_In_All_Level());
  DrawTextH(bufferText, TEXT3_X + TEXT_SHADOW, TEXT3_Y + 4 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
  DrawTextH(bufferText, TEXT3_X, TEXT3_Y + 4 * LINE_SPACING, COL_WHITE); // Main text

  // Display skull count with icon
  DrawICO(TEXT3_X + 40, TEXT3_Y + (5 * LINE_SPACING) + 5, 6);
  snprintf(bufferText, sizeof(bufferText), "         %d / %d", Total_Skull, Total_Skull_In_All_Level());
  DrawTextH(bufferText, TEXT3_X + TEXT_SHADOW, TEXT3_Y + 5 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
  DrawTextH(bufferText, TEXT3_X, TEXT3_Y + 5 * LINE_SPACING, COL_WHITE); // Main text

  // Display final score
  snprintf(bufferText, sizeof(bufferText), "      Score: %ld", score);
  DrawTextH(bufferText, TEXT3_X + TEXT_SHADOW, TEXT3_Y + 6 * LINE_SPACING + TEXT_SHADOW, COL_BLACK); // Shadow
  DrawTextH(bufferText, TEXT3_X, TEXT3_Y + 6 * LINE_SPACING, COL_YELLOW); // Main text

  DispUpdate(); // Refresh display
  while (1) {
    if (BUTTON_DOWN) break; // Wait for button press
    sleep_ms(33); // Delay to prevent busy loop
  }
  FadeOutToBlack(); // Fade to black
}
