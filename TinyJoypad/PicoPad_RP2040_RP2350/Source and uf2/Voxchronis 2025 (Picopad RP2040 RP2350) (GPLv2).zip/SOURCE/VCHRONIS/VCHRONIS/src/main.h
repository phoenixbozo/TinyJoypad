//     >>>>> VOXCHRONIS for PicoPad RP2040 & RP2350+  GPLv2 <<<<<
//                    Programmer: Daniel C 2025
//               Contact EMAIL: electro_l.i.b@tinyjoypad.com
//                      https://www.tinyjoypad.com
//           https://sites.google.com/view/arduino-collection
//
// VOXCHRONIS is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2.0 as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program. If not, see <https://www.gnu.org/licenses/>.
// The full license text is available in the file "GPL-2.0.txt".
//
// This source code includes commands referencing the PicoLibSDK library,
// which is not included in this source distribution.
//
// A compiled .uf2 file "VCHRONIS.UF2" is provided, which includes code from
// the PicoLibSDK library by Miroslav Nemecek (https://github.com/Panda381/PicoLibSDK).
// PicoLibSDK includes code from the Raspberry Pi Pico SDK (under BSD 3-Clause License)
// and floating-point mathematics library by Mark Owen (under GNU General Public License version 2.0).
// See "PicoLibSDK_Readme.txt" for details on PicoLibSDK licensing and usage.
//
// Thanks to Miroslav Nemecek for PicoLibSDK, Mark Owen for the floating-point
// mathematics library, and Raspberry Pi for the Pico SDK.


#ifndef _MAIN_H
#define _MAIN_H

#define TINYJOYPAD_LEFT   (KeyPressed(KEY_LEFT))
#define TINYJOYPAD_RIGHT (KeyPressed(KEY_RIGHT))
#define TINYJOYPAD_DOWN (KeyPressed(KEY_DOWN))
#define TINYJOYPAD_UP (KeyPressed(KEY_UP))
#define BUTTON_A  (KeyPressed(KEY_A))
#define BUTTON_B  (KeyPressed(KEY_B))
#define BUTTON_X  (KeyPressed(KEY_X))
#define BUTTON_Y  (KeyPressed(KEY_Y))
#define BUTTON_DOWN ( (KeyPressed(KEY_A))||(KeyPressed(KEY_B)) )
#define BUTTON_UP ( (!KeyPressed(KEY_A)) && (!KeyPressed(KEY_B)) )

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 240

//SND
extern const u8 PICKUP[2106];
extern const u8 Button[1127]; //Menu Button sound
extern const u8 logo[110336]; //logo sound
extern const u8 GunFire[6358]; // gun fire
extern const u8 door[14907]; // door
extern const u8 PLsnd1[4707]; //PLsnd1
extern const u8 PLsnd2[6421]; //PLsnd2
extern const u8 PLsnd3[16745]; //PLsnd3
extern const u8 ENsnd1[19349]; //ENsnd1
extern const u8 ENsnd2[47562]; //ENsnd2
extern const u8 endlvl[74496];//end lvl

//menu
#define menu_W 320
#define menu_W_FULL 320
#define menu_H 240
extern const u16 menu_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 menu[76800]/* __attribute__ ((aligned(4)))*/;

//splash
#define splash_W 320
#define splash_W_FULL 320
#define splash_H 240
extern const u16 splash_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 splash[76800]/* __attribute__ ((aligned(4)))*/;

//splash2
#define splash2_W 320
#define splash2_W_FULL 320
#define splash2_H 240
extern const u16 splash2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 splash2[76800]/* __attribute__ ((aligned(4)))*/;

//scorepic
#define ScorePic_W 320
#define ScorePic_W_FULL 320
#define ScorePic_H 240
extern const u16 ScorePic_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 ScorePic[76800]/* __attribute__ ((aligned(4)))*/;

//gameover pic
#define go_W 320
#define go_W_FULL 320
#define go_H 240
extern const u16 go_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 go[76800]/* __attribute__ ((aligned(4)))*/;


//Congrat pic
#define Congrat_W 320
#define Congrat_W_FULL 320
#define Congrat_H 240
extern const u16 Congrat_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 Congrat[76800]/* __attribute__ ((aligned(4)))*/;


//ico
#define ico_W 20
#define ico_W_FULL 140
#define ico_H 20
extern const u16 ico_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 ico[2800]/* __attribute__ ((aligned(4)))*/;


//enemy
#define enemy_W 99
#define enemy_W_FULL 100
#define enemy_H 100
extern const u16 enemy_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 enemy[240000]/* __attribute__ ((aligned(4)))*/;

//enemy2
#define enemy2_W 99
#define enemy2_W_FULL 100
#define enemy2_H 100
extern const u16 enemy2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 enemy2[240000]/* __attribute__ ((aligned(4)))*/;

//enemy3
#define enemy3_W 99
#define enemy3_W_FULL 100
#define enemy3_H 100
extern const u16 enemy3_Pal[2]/* __attribute__ ((aligned(4)))*/;
extern const u8 enemy3[240000]/* __attribute__ ((aligned(4)))*/;


//redcard
#define RedCard_W 39
#define RedCard_W_FULL 40
#define RedCard_H 60
extern const u16 RedCard_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 RedCard[28800]/* __attribute__ ((aligned(4)))*/;


//greencard
#define GreenCard_W 39
#define GreenCard_W_FULL 40
#define GreenCard_H 60
extern const u16 GreenCard_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 GreenCard[28800]/* __attribute__ ((aligned(4)))*/;

//Bluecard
#define BlueCard_W 39
#define BlueCard_W_FULL 40
#define BlueCard_H 60
extern const u16 BlueCard_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 BlueCard[28800]/* __attribute__ ((aligned(4)))*/;

//Goldcard
#define GoldCard_W 39
#define GoldCard_W_FULL 40
#define GoldCard_H 60
extern const u16 GoldCard_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 GoldCard[28800]/* __attribute__ ((aligned(4)))*/;


//sphere
#define sphere_W 39
#define sphere_W_FULL 40
#define sphere_H 60
extern const u16 sphere_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 sphere[28800]/* __attribute__ ((aligned(4)))*/;

//Medic
#define medic_W 39
#define medic_W_FULL 40
#define medic_H 60
extern const u16 medic_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 medic[28800]/* __attribute__ ((aligned(4)))*/;


//ammo
#define ammo_W 39
#define ammo_W_FULL 40
#define ammo_H 60
extern const u16 ammo_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 ammo[28800]/* __attribute__ ((aligned(4)))*/;

//skull
#define Skull_W 39
#define Skull_W_FULL 40
#define Skull_H 60
extern const u16 Skull_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 Skull[28800]/* __attribute__ ((aligned(4)))*/;


#define Weapon_W 66
#define Weapon_W_FULL 68
#define Weapon_H 70
extern const u16 Weapon_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 Weapon[4760]/* __attribute__ ((aligned(4)))*/;

#define fire_W 66
#define fire_W_FULL 68
#define fire_H 70
extern const u16 fire_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 fire[4760]/* __attribute__ ((aligned(4)))*/;


//texture
#define tex1_W 79
#define tex1_W_FULL 80
#define tex1_H 80
extern const u16 tex1_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex1[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex2_W 79
#define tex2_W_FULL 80
#define tex2_H 80
extern const u16 tex2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex2[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex3_W 79
#define tex3_W_FULL 80
#define tex3_H 80
extern const u16 tex3_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex3[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex4_W 79
#define tex4_W_FULL 80
#define tex4_H 80
extern const u16 tex4_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex4[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex5_W 79
#define tex5_W_FULL 80
#define tex5_H 80
extern const u16 tex5_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex5[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex6_W 79
#define tex6_W_FULL 80
#define tex6_H 80
extern const u16 tex6_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex6[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex7_W 79
#define tex7_W_FULL 80
#define tex7_H 80
extern const u16 tex7_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex7[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex8_W 79
#define tex8_W_FULL 80
#define tex8_H 80
extern const u16 tex8_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex8[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex9_W 79
#define tex9_W_FULL 80
#define tex9_H 80
extern const u16 tex9_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex9[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define tex10_W 79
#define tex10_W_FULL 80
#define tex10_H 80
extern const u16 tex10_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex10[6400]/* __attribute__ ((aligned(4)))*/;

//texture
#define BR_W 79
#define BR_W_FULL 80
#define BR_H 80
extern const u16 BR_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 BR[6400]/* __attribute__ ((aligned(4)))*/;


//texture
#define tex11_W 79
#define tex11_W_FULL 80
#define tex11_H 80
extern const u16 tex11_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 tex11[6400]/* __attribute__ ((aligned(4)))*/;


//door
#define door1_W 79
#define door1_W_FULL 80
#define door1_H 80
extern const u16 door1_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 door1[6400]/* __attribute__ ((aligned(4)))*/;

//door2
#define door2_W 79
#define door2_W_FULL 80
#define door2_H 80
extern const u16 door2_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 door2[6400]/* __attribute__ ((aligned(4)))*/;

//door3
#define door3_W 79
#define door3_W_FULL 80
#define door3_H 80
extern const u16 door3_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 door3[6400]/* __attribute__ ((aligned(4)))*/;

//door4
#define door4_W 79
#define door4_W_FULL 80
#define door4_H 80
extern const u16 door4_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 door4[6400]/* __attribute__ ((aligned(4)))*/;

//FinalDoor
#define FinalDoor_W 79
#define FinalDoor_W_FULL 80
#define FinalDoor_H 80
extern const u16 FinalDoor_Pal[256]/* __attribute__ ((aligned(4)))*/;
extern const u8 FinalDoor[6400]/* __attribute__ ((aligned(4)))*/;


//prototype
void FadeInFromBlack(const u8 *PIC_,const u16 *PIC_PAL_);
void FadeOutToBlack(void);
void Init_NewGame(void);
void InitKeyCard(void);
void Init_New_game(void);
void FadeInGame(void);
void DisplayScore(void);
void enteringNewLevel(void);
void GameOverSplash(void);
void MakeColorFlash(uint16_t Color_);
void DisplayScorePage(uint8_t level, uint16_t enemiesKilled, uint8_t health, uint8_t ammo, uint16_t *score_);



#endif // _MAIN_H
