#!/bin/bash
# Export to hardware...

export TARGET="VCHRONIS"
../../../_e1.sh
