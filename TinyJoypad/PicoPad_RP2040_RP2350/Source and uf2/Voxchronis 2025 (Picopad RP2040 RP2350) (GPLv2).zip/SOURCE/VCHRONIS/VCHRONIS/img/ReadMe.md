  * # VOXCHRONIS

Voxchronis is a game developed for the PicoPad platform, supporting both RP2040 and RP2350+ microcontrollers, including the Raspberry Pi Pico.

## About
This game was created by Daniel C. (Électro L.I.B) and uses the PicoLibSDK library to interact with PicoPad hardware. For more information about the project or to explore other creations, visit [tinyjoypad.com](https://www.tinyjoypad.com/) or [arduino-collection](https://sites.google.com/view/arduino-collection).

  * ## Installation
To build and run Voxchronis:
1. Ensure you have the [PicoLibSDK](https://github.com/Panda381/PicoLibSDK) installed.
2. Follow the build instructions provided in the PicoLibSDK documentation (see `PicoLibSDK_Readme.txt`).
3. Flash the compiled firmware (`VCHRONIS.UF2`) onto your PicoPad device using a compatible tool (e.g., RP2040 or RP2350+ bootloader).

## License
**Voxchronis** is distributed under the GNU General Public License version 2.0 (GPLv2). See the GPL-2.0.txt file for the full license text.

  * This project uses:
- **PicoLibSDK** by Miroslav Nemecek ([https://github.com/Panda381/PicoLibSDK](https://github.com/Panda381/PicoLibSDK)):
  - Most of PicoLibSDK is provided under a permissive license, allowing free use, modification, and distribution for any purpose.
  - Exceptions:
    - The single- and double-floating-point mathematics libraries include code by Mark Owen, licensed under the GNU General Public License version 2.0.
    - The single- and double-floating-point mathematics libraries include code from the Raspberry Pi Pico SDK, licensed under the BSD 3-Clause License (see `LICENSE_pico-sdk.txt`).
- **Raspberry Pi Pico SDK** by Raspberry Pi (Trading) Ltd. ([https://github.com/raspberrypi/pico-sdk](https://github.com/raspberrypi/pico-sdk)), licensed under the BSD 3-Clause License (see `LICENSE_pico-sdk.txt`).

The compiled `.uf2` file (`VCHRONIS.UF2`) includes code from PicoLibSDK. 
For more details, see `LICENSE.txt` , `PicoLibSDK_Readme.txt` and `GPL-2.0.txt`.

## Credits
- **VOXCHRONIS**: Developed by Daniel C. (Électro L.I.B) ([https://www.tinyjoypad.com/](https://www.tinyjoypad.com/))
- **PicoLibSDK**: Miroslav Nemecek ([https://github.com/Panda381/PicoLibSDK](https://github.com/Panda381/PicoLibSDK))
- **Floating-point mathematics library**: Mark Owen (GNU General Public License version 2.0)
- **Raspberry Pi Pico SDK**: Raspberry Pi (Trading) Ltd. ([https://github.com/raspberrypi/pico-sdk](https://github.com/raspberrypi/pico-sdk))

## Contact
For questions or contributions, contact Daniel C.:
- Email: [electro_l.i.b@tinyjoypad.com](mailto:electro_l.i.b@tinyjoypad.com)
- Website: [https://www.tinyjoypad.com/](https://www.tinyjoypad.com/)
- Additional resources: [https://sites.google.com/view/arduino-collection](https://sites.google.com/view/arduino-collection)

